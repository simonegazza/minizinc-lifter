import random, argparse

def generate(n, probability = 0.3):
    width = len(str(n))
    return f"n = {n};\n" + "initial_grid = [|\n" + "|\n".join(
        ", ".join(
            f"{(random.randint(1, n) if random.random() < probability else 0):>{width}}"
            for _ in range(n)
        )
        for _ in range(n)
    ) + "\n|];"


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(
        description="Generate a random partially-filled Latin square instance."
    )
    parser.add_argument("n", type=int, metavar="n", help="Size (n x n)")
    parser.add_argument(
        "-p", "--probability",
        type=float,
        default=0.2,
        help="Probability of filling each cell (default: 0.2).",
    )
    parser.add_argument(
        "-o", "--output",
        help="Write the generated instance to file",
    )
    args = parser.parse_args()

    if not (0 <= args.probability <= 1):
        parser.error("probability must be between 0 and 1")

    result = generate(args.n, args.probability)

    if args.output:
        with open(args.output, "w") as f:
            f.write(result)
    else:
        print(result)
