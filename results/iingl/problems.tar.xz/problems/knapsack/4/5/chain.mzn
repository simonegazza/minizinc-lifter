predicate global_cardinality(
    array [$X] of var $$E: x,
    array [int] of var $$E: cover,
    array [int] of var int: lbound,
    array [int] of var int: ubound
) = forall(i in 1..length(cover))(
    sum([e = cover[i] | e in x]) in lbound[i]..ubound[i]
);

predicate cumulative(
    array[$$E] of var opt int: s,
    array[$$E] of var opt int: d,
    array[$$E] of var opt int: r,
    var int: b
) = assert(
    % They all must have same length
    index_set(s) == index_set(d) /\ index_set(s) == index_set(r),
    "cumulative redefinition: arrays must have identical index sets",

    let {
        array[index_set(s)] of var 0..ub(max(d)): d_deopt;
        array[index_set(s)] of var 0..ub(max(r)): r_deopt;
    } in
    % If s occurs than also d and r must occur, and viceversa
    forall(i in index_set(s))(occurs(s[i]) = occurs(d[i]) /\ occurs(s[i]) = occurs(r[i]))
    /\
    % "channeling" from d to define d_deopt
    d_deopt = [
        if occurs(d[i]) then d_deopt[i] = deopt(d[i]) else d_deopt[i] = 0 endif
        | i in index_set(s)]
    /\
    % "channeling" from r to define r_deopt
    r_deopt = [
        if occurs(r[i]) then r_deopt[i] = deopt(r[i]) else r_deopt[i] = 0 endif
        | i in index_set(s)]
    /\
    % Nonnegativity only when present
    forall(i in index_set(s))(occurs(d[i]) -> d[i] >= 0 /\ occurs(r[i]) -> r[i] >= 0)
    /\
    cumulative(s, d_deopt, r_deopt, b)
);


int: n;                          % The number of items.
int: k;                          % The size of the knapsack.

array[1..n] of var min(size)..max(size): size_lifted :: doc_comment("size_lifted");       % size[i] is the size of item i.

array[1..n] of var min(value)..max(value): value_lifted :: doc_comment("value_lifted");      % value[i] is the value of item i.

array [1..n] of var 0..1: x;
                                % x[i] = 1 iff item i is included.
var 0..10000: v;

constraint sum (i in 1..n) (size_lifted[i] * x[i]) <= k;
constraint sum (i in 1..n) (value_lifted[i] * x[i]) >= v;

solve :: int_search(x, input_order, indomain_max, complete) maximize v;

n = 30;
k = 100;







include "experimental/assume/fzn_assume.mzn";

int: max_instances = 20;
set of int: instances = 1..max_instances;
var instances: current_instance;

array[int] of array[int] of int: params_int = [
	[size[i, i0] | i0 in 1..n]
	 ++ [value[i, i0] | i0 in 1..n]
	| i in instances];

array[int] of var int: params_int_lifted = 
	[size_lifted[i0] | i0 in 1..n]
	 ++ [value_lifted[i0] | i0 in 1..n];

array[int] of array[int] of var bool: assumed = [
	[params_int_lifted[i0] = params_int[i][i0] | i0 in index_set(params_int_lifted)]
	| i in instances];

constraint nogood_learning(
	[assumed[i][i0] | i in instances, i0 in index_set(assumed[i])],
	length(instances),
	current_instance
);

array[instances] of var int: objective_lifted :: output_var = [
	sum([abs(size_lifted[i0] - size[i, i0]) | i0 in 1..n])
	+ sum([abs(value_lifted[i0] - value[i, i0]) | i0 in 1..n])
	| i in instances
];



output ["current_instance = \(current_instance)"] ++ ["\noriginal size = \(size[fix(current_instance), ..])\nlifted   size = \(size_lifted)\n\n"] ++ ["\noriginal value = \(value[fix(current_instance), ..])\nlifted   value = \(value_lifted)\n\n"];


array[instances, 1..30,] of 1..10: size = array2d(instances, 1..30, [4, 2, 8, 10, 2, 3, 9, 7, 9, 6, 8, 9, 8, 3, 6, 6, 9, 8, 8, 8, 5, 10, 7, 10, 1, 4, 4, 4, 8, 4] ++  [4, 2, 8, 10, 2, 3, 9, 7, 9, 6, 8, 9, 8, 3, 6, 6, 9, 8, 8, 8, 1, 10, 7, 10, 1, 4, 4, 4, 8, 4] ++  [4, 2, 8, 10, 2, 3, 9, 7, 9, 6, 8, 5, 8, 3, 7, 6, 9, 8, 8, 8, 1, 10, 7, 10, 1, 4, 4, 4, 2, 4] ++  [4, 2, 8, 10, 2, 10, 9, 7, 9, 6, 8, 5, 8, 3, 7, 6, 9, 8, 10, 8, 1, 10, 7, 10, 1, 4, 4, 4, 2, 4] ++  [4, 2, 8, 10, 2, 4, 9, 7, 9, 6, 8, 5, 8, 3, 7, 6, 9, 8, 10, 8, 1, 10, 7, 10, 1, 4, 4, 4, 2, 4] ++  [4, 2, 8, 10, 10, 4, 9, 1, 9, 6, 8, 5, 8, 3, 7, 6, 9, 8, 10, 8, 1, 10, 7, 4, 1, 4, 4, 4, 2, 4] ++  [4, 2, 8, 10, 10, 4, 9, 1, 9, 6, 8, 5, 5, 3, 7, 6, 9, 8, 10, 8, 1, 6, 7, 4, 1, 4, 4, 4, 2, 4] ++  [4, 2, 8, 10, 10, 4, 9, 1, 9, 6, 8, 5, 5, 3, 7, 6, 9, 8, 10, 8, 1, 6, 7, 4, 1, 4, 4, 4, 2, 4] ++  [4, 2, 8, 10, 10, 4, 9, 1, 9, 6, 8, 5, 5, 3, 7, 6, 9, 8, 10, 8, 1, 6, 7, 4, 1, 4, 4, 4, 2, 4] ++  [4, 2, 8, 10, 10, 4, 9, 1, 9, 6, 8, 5, 5, 3, 7, 6, 9, 8, 7, 7, 1, 6, 7, 4, 1, 4, 4, 4, 2, 4] ++  [4, 2, 8, 10, 10, 4, 9, 1, 9, 6, 8, 5, 5, 3, 7, 6, 9, 8, 7, 7, 1, 6, 7, 4, 1, 4, 4, 4, 2, 4] ++  [4, 2, 8, 10, 10, 4, 9, 1, 9, 4, 8, 5, 5, 3, 7, 6, 9, 8, 7, 7, 1, 6, 7, 4, 1, 4, 4, 4, 2, 4] ++  [4, 2, 8, 10, 10, 4, 9, 1, 9, 4, 8, 5, 5, 10, 7, 6, 9, 8, 7, 7, 1, 6, 7, 4, 1, 4, 4, 4, 2, 4] ++  [4, 2, 8, 10, 10, 4, 9, 1, 9, 4, 8, 5, 5, 10, 7, 6, 9, 8, 7, 7, 1, 6, 7, 4, 1, 4, 4, 4, 2, 4] ++  [4, 2, 8, 10, 10, 8, 9, 1, 9, 4, 8, 5, 5, 10, 7, 6, 9, 8, 7, 7, 8, 6, 7, 4, 1, 4, 4, 4, 2, 4] ++  [4, 2, 8, 10, 10, 8, 9, 1, 9, 4, 8, 5, 5, 9, 7, 6, 9, 8, 7, 7, 8, 6, 7, 4, 1, 4, 4, 4, 1, 4] ++  [4, 2, 8, 10, 10, 8, 9, 1, 3, 4, 8, 5, 5, 9, 7, 6, 9, 8, 7, 7, 8, 6, 7, 4, 1, 4, 4, 4, 1, 4] ++  [4, 2, 8, 10, 10, 8, 9, 1, 3, 4, 8, 5, 5, 9, 7, 6, 9, 8, 7, 7, 8, 6, 7, 4, 1, 4, 4, 4, 1, 4] ++  [4, 2, 8, 10, 10, 8, 9, 1, 3, 4, 8, 5, 5, 9, 7, 6, 9, 8, 7, 7, 8, 6, 7, 4, 1, 4, 8, 10, 1, 4] ++  [4, 4, 8, 10, 10, 8, 9, 1, 3, 4, 8, 5, 5, 9, 7, 6, 9, 8, 7, 7, 1, 6, 7, 4, 1, 4, 8, 10, 1, 4]
);

array[instances, 1..30,] of 1..10: value = array2d(instances, 1..30, [7, 4, 5, 7, 7, 10, 3, 6, 5, 9, 2, 3, 2, 5, 8, 9, 6, 4, 10, 1, 8, 9, 10, 6, 7, 8, 8, 7, 7, 6] ++  [7, 8, 5, 7, 7, 10, 3, 6, 5, 9, 2, 3, 2, 5, 8, 9, 6, 4, 10, 1, 8, 5, 10, 6, 7, 8, 8, 7, 7, 6] ++  [7, 8, 5, 7, 7, 10, 3, 6, 5, 9, 2, 3, 2, 5, 8, 9, 6, 4, 10, 1, 8, 5, 10, 6, 7, 8, 8, 7, 7, 6] ++  [7, 8, 5, 7, 7, 10, 3, 6, 5, 9, 2, 3, 2, 5, 8, 9, 6, 4, 10, 1, 8, 5, 10, 6, 7, 8, 8, 10, 7, 6] ++  [7, 8, 5, 7, 7, 10, 3, 6, 5, 9, 2, 6, 2, 5, 8, 9, 6, 4, 10, 1, 2, 5, 10, 6, 7, 8, 8, 10, 7, 6] ++  [7, 8, 5, 7, 7, 10, 3, 6, 5, 9, 2, 6, 2, 5, 8, 9, 6, 4, 10, 1, 2, 5, 10, 6, 7, 8, 8, 10, 7, 6] ++  [7, 8, 5, 7, 7, 10, 3, 6, 5, 9, 2, 6, 2, 6, 8, 9, 6, 4, 10, 1, 2, 5, 10, 6, 7, 8, 8, 10, 7, 6] ++  [7, 8, 5, 7, 7, 10, 3, 6, 5, 9, 2, 6, 2, 6, 8, 9, 6, 6, 10, 4, 2, 5, 4, 6, 7, 8, 8, 10, 7, 6] ++  [7, 8, 5, 7, 7, 10, 3, 6, 5, 9, 2, 6, 2, 6, 8, 1, 6, 6, 5, 4, 2, 5, 4, 6, 10, 8, 8, 10, 7, 6] ++  [7, 8, 5, 7, 7, 10, 3, 6, 5, 9, 2, 6, 2, 6, 8, 1, 6, 6, 5, 7, 2, 5, 4, 6, 10, 8, 8, 10, 7, 6] ++  [7, 8, 5, 7, 7, 10, 3, 9, 5, 9, 2, 6, 2, 6, 8, 1, 6, 6, 10, 7, 2, 5, 1, 6, 10, 8, 8, 10, 7, 6] ++  [7, 8, 5, 7, 7, 10, 3, 9, 5, 9, 2, 6, 2, 6, 8, 1, 6, 6, 7, 7, 2, 5, 1, 6, 10, 4, 8, 10, 7, 6] ++  [7, 8, 5, 7, 7, 10, 3, 9, 5, 9, 2, 6, 2, 6, 8, 1, 9, 4, 7, 7, 2, 5, 1, 6, 10, 4, 8, 10, 7, 6] ++  [7, 8, 5, 7, 7, 6, 3, 8, 5, 9, 2, 6, 2, 6, 8, 1, 9, 4, 7, 7, 9, 5, 1, 6, 10, 4, 8, 10, 7, 6] ++  [7, 8, 5, 7, 7, 6, 3, 8, 5, 9, 2, 6, 2, 6, 8, 1, 9, 4, 7, 7, 4, 5, 1, 6, 10, 4, 8, 10, 7, 6] ++  [7, 8, 5, 7, 7, 6, 3, 8, 5, 9, 2, 6, 2, 6, 8, 1, 9, 4, 7, 7, 4, 5, 1, 6, 6, 4, 8, 10, 7, 6] ++  [7, 8, 5, 7, 7, 6, 6, 8, 5, 9, 2, 6, 2, 6, 8, 1, 9, 4, 7, 7, 4, 5, 1, 6, 6, 1, 8, 10, 7, 6] ++  [7, 6, 5, 7, 7, 6, 6, 8, 5, 9, 2, 6, 5, 6, 8, 1, 9, 4, 7, 7, 4, 7, 1, 6, 6, 1, 8, 10, 7, 6] ++  [7, 6, 5, 7, 7, 6, 6, 8, 5, 9, 2, 6, 5, 5, 8, 1, 9, 4, 7, 7, 4, 7, 1, 6, 6, 1, 8, 10, 7, 6] ++  [7, 6, 5, 7, 7, 6, 6, 3, 5, 9, 2, 6, 5, 5, 8, 1, 9, 4, 7, 7, 4, 7, 1, 6, 6, 1, 8, 10, 7, 6]
);