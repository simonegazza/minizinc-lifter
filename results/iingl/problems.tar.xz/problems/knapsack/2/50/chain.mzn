predicate global_cardinality(
    array [$X] of var $$E: x,
    array [int] of var $$E: cover,
    array [int] of var int: lbound,
    array [int] of var int: ubound
) = forall(i in 1..length(cover))(
    sum([e = cover[i] | e in x]) in lbound[i]..ubound[i]
);

predicate cumulative(
    array[$$E] of var opt int: s,
    array[$$E] of var opt int: d,
    array[$$E] of var opt int: r,
    var int: b
) = assert(
    % They all must have same length
    index_set(s) == index_set(d) /\ index_set(s) == index_set(r),
    "cumulative redefinition: arrays must have identical index sets",

    let {
        array[index_set(s)] of var 0..ub(max(d)): d_deopt;
        array[index_set(s)] of var 0..ub(max(r)): r_deopt;
    } in
    % If s occurs than also d and r must occur, and viceversa
    forall(i in index_set(s))(occurs(s[i]) = occurs(d[i]) /\ occurs(s[i]) = occurs(r[i]))
    /\
    % "channeling" from d to define d_deopt
    d_deopt = [
        if occurs(d[i]) then d_deopt[i] = deopt(d[i]) else d_deopt[i] = 0 endif
        | i in index_set(s)]
    /\
    % "channeling" from r to define r_deopt
    r_deopt = [
        if occurs(r[i]) then r_deopt[i] = deopt(r[i]) else r_deopt[i] = 0 endif
        | i in index_set(s)]
    /\
    % Nonnegativity only when present
    forall(i in index_set(s))(occurs(d[i]) -> d[i] >= 0 /\ occurs(r[i]) -> r[i] >= 0)
    /\
    cumulative(s, d_deopt, r_deopt, b)
);


int: n;                          % The number of items.
int: k;                          % The size of the knapsack.

array[1..n] of var min(size)..max(size): size_lifted :: doc_comment("size_lifted");       % size[i] is the size of item i.

array[1..n] of var min(value)..max(value): value_lifted :: doc_comment("value_lifted");      % value[i] is the value of item i.

array [1..n] of var 0..1: x;
                                % x[i] = 1 iff item i is included.
var 0..10000: v;

constraint sum (i in 1..n) (size_lifted[i] * x[i]) <= k;
constraint sum (i in 1..n) (value_lifted[i] * x[i]) >= v;

solve :: int_search(x, input_order, indomain_max, complete) maximize v;

n = 30;
k = 100;







include "experimental/assume/fzn_assume.mzn";

int: max_instances = 20;
set of int: instances = 1..max_instances;
var instances: current_instance;

array[int] of array[int] of int: params_int = [
	[size[i, i0] | i0 in 1..n]
	 ++ [value[i, i0] | i0 in 1..n]
	| i in instances];

array[int] of var int: params_int_lifted = 
	[size_lifted[i0] | i0 in 1..n]
	 ++ [value_lifted[i0] | i0 in 1..n];

array[int] of array[int] of var bool: assumed = [
	[params_int_lifted[i0] = params_int[i][i0] | i0 in index_set(params_int_lifted)]
	| i in instances];

constraint nogood_learning(
	[assumed[i][i0] | i in instances, i0 in index_set(assumed[i])],
	length(instances),
	current_instance
);

array[instances] of var int: objective_lifted :: output_var = [
	sum([abs(size_lifted[i0] - size[i, i0]) | i0 in 1..n])
	+ sum([abs(value_lifted[i0] - value[i, i0]) | i0 in 1..n])
	| i in instances
];



output ["current_instance = \(current_instance)"] ++ ["\noriginal size = \(size[fix(current_instance), ..])\nlifted   size = \(size_lifted)\n\n"] ++ ["\noriginal value = \(value[fix(current_instance), ..])\nlifted   value = \(value_lifted)\n\n"];


array[instances, 1..30,] of 1..10: size = array2d(instances, 1..30, [4, 10, 2, 1, 4, 8, 2, 8, 1, 6, 9, 7, 6, 1, 10, 5, 9, 1, 2, 5, 2, 4, 9, 2, 2, 4, 9, 7, 4, 4] ++  [6, 4, 6, 1, 4, 8, 2, 8, 7, 6, 9, 7, 6, 3, 2, 10, 3, 1, 3, 9, 6, 4, 9, 6, 1, 5, 9, 1, 7, 4] ++  [8, 4, 3, 8, 5, 2, 2, 2, 7, 4, 9, 7, 6, 3, 9, 10, 3, 1, 3, 7, 9, 8, 3, 6, 10, 5, 6, 4, 7, 4] ++  [8, 10, 3, 8, 2, 3, 2, 6, 7, 3, 5, 7, 10, 3, 1, 3, 3, 2, 3, 10, 5, 8, 5, 7, 10, 5, 9, 3, 9, 4] ++  [3, 4, 5, 10, 1, 3, 6, 6, 7, 3, 9, 7, 1, 3, 2, 3, 10, 6, 1, 10, 5, 8, 5, 6, 6, 5, 9, 3, 1, 9] ++  [3, 4, 5, 10, 1, 4, 6, 6, 3, 6, 9, 7, 1, 4, 4, 7, 10, 4, 2, 8, 5, 10, 5, 6, 2, 3, 1, 6, 4, 9] ++  [3, 7, 5, 10, 1, 5, 6, 4, 1, 6, 8, 10, 2, 4, 5, 7, 10, 6, 2, 8, 5, 10, 9, 10, 1, 3, 1, 6, 4, 9] ++  [3, 7, 7, 8, 1, 10, 6, 1, 1, 10, 9, 10, 3, 4, 5, 7, 10, 6, 6, 2, 5, 10, 9, 10, 2, 8, 1, 7, 7, 2] ++  [6, 7, 7, 5, 1, 10, 6, 2, 4, 7, 8, 1, 1, 4, 5, 7, 6, 6, 3, 5, 5, 4, 9, 10, 2, 8, 10, 7, 3, 1] ++  [6, 7, 5, 5, 9, 9, 6, 3, 1, 7, 8, 3, 1, 4, 5, 7, 6, 6, 7, 7, 3, 4, 1, 6, 10, 8, 10, 9, 3, 9] ++  [9, 7, 3, 5, 6, 9, 6, 1, 1, 7, 8, 3, 2, 7, 5, 7, 5, 6, 10, 10, 5, 9, 4, 6, 10, 8, 8, 9, 3, 6] ++  [9, 2, 2, 2, 6, 4, 6, 6, 1, 6, 10, 9, 2, 1, 5, 9, 5, 1, 10, 6, 3, 8, 4, 8, 9, 8, 3, 9, 10, 6] ++  [3, 6, 5, 2, 6, 4, 10, 2, 1, 1, 2, 9, 10, 6, 5, 9, 5, 4, 1, 3, 7, 10, 4, 8, 9, 8, 3, 9, 1, 10] ++  [3, 6, 5, 2, 6, 3, 7, 2, 4, 1, 2, 9, 2, 6, 6, 9, 5, 4, 1, 2, 7, 8, 1, 8, 9, 8, 3, 9, 9, 5] ++  [3, 6, 5, 2, 4, 3, 2, 6, 4, 1, 9, 4, 2, 1, 6, 2, 5, 4, 1, 2, 6, 3, 1, 8, 2, 3, 8, 8, 9, 9] ++  [2, 2, 5, 6, 4, 3, 2, 8, 7, 1, 9, 8, 2, 9, 6, 4, 5, 4, 4, 2, 3, 3, 9, 3, 9, 10, 8, 7, 9, 9] ++  [9, 2, 7, 6, 4, 6, 2, 3, 7, 2, 9, 10, 2, 9, 2, 1, 6, 1, 4, 2, 3, 3, 9, 9, 9, 10, 9, 2, 9, 1] ++  [1, 3, 7, 6, 5, 9, 2, 4, 8, 6, 9, 7, 2, 9, 2, 8, 3, 9, 3, 2, 3, 3, 9, 10, 9, 10, 9, 2, 8, 1] ++  [7, 3, 2, 6, 5, 9, 9, 4, 8, 4, 9, 7, 2, 9, 2, 3, 2, 1, 10, 2, 8, 1, 5, 7, 2, 2, 9, 4, 1, 3] ++  [7, 3, 2, 9, 2, 9, 9, 3, 5, 4, 5, 8, 2, 9, 2, 3, 4, 3, 9, 2, 2, 2, 5, 7, 4, 2, 9, 1, 1, 8]
);

array[instances, 1..30,] of 1..10: value = array2d(instances, 1..30, [9, 4, 10, 3, 9, 9, 7, 2, 10, 6, 8, 7, 2, 3, 3, 9, 7, 9, 6, 3, 9, 10, 8, 6, 6, 9, 6, 6, 7, 7] ++  [9, 4, 10, 2, 3, 6, 10, 2, 9, 6, 8, 7, 4, 3, 3, 4, 1, 3, 6, 9, 8, 10, 6, 6, 6, 9, 8, 6, 7, 5] ++  [9, 4, 10, 4, 10, 9, 8, 2, 10, 6, 5, 1, 2, 3, 3, 4, 2, 3, 6, 4, 8, 7, 6, 10, 5, 9, 7, 6, 7, 8] ++  [9, 4, 10, 7, 10, 1, 6, 10, 10, 4, 4, 1, 9, 1, 3, 4, 2, 5, 6, 5, 1, 4, 6, 10, 5, 2, 7, 6, 7, 8] ++  [9, 4, 10, 3, 5, 1, 6, 8, 10, 10, 6, 8, 2, 1, 5, 4, 7, 5, 6, 5, 10, 7, 6, 10, 5, 2, 7, 10, 8, 6] ++  [9, 4, 10, 10, 4, 10, 8, 8, 10, 2, 3, 8, 8, 10, 5, 4, 6, 7, 3, 5, 10, 7, 2, 10, 5, 6, 8, 3, 8, 6] ++  [7, 10, 7, 10, 4, 10, 4, 8, 7, 8, 3, 8, 9, 8, 8, 4, 6, 7, 1, 5, 8, 6, 4, 2, 5, 2, 8, 5, 1, 8] ++  [7, 10, 8, 9, 3, 8, 4, 3, 7, 8, 5, 8, 3, 2, 8, 4, 8, 8, 9, 10, 8, 6, 8, 2, 5, 2, 2, 3, 1, 3] ++  [7, 2, 8, 7, 3, 3, 5, 2, 7, 8, 1, 8, 9, 2, 8, 10, 1, 8, 9, 4, 3, 7, 8, 2, 2, 9, 2, 3, 9, 3] ++  [4, 2, 8, 7, 3, 10, 1, 8, 4, 10, 1, 8, 7, 6, 10, 8, 1, 5, 9, 4, 2, 3, 8, 5, 2, 4, 2, 3, 5, 3] ++  [4, 2, 1, 7, 3, 8, 10, 8, 4, 8, 7, 8, 6, 6, 7, 8, 1, 3, 9, 4, 8, 7, 8, 7, 5, 2, 7, 1, 10, 3] ++  [4, 1, 1, 7, 9, 8, 3, 8, 5, 8, 1, 8, 6, 6, 2, 8, 1, 1, 9, 10, 8, 7, 5, 4, 7, 2, 7, 1, 9, 3] ++  [4, 1, 1, 6, 1, 7, 5, 8, 5, 8, 3, 8, 7, 9, 9, 8, 8, 6, 7, 9, 3, 7, 5, 4, 7, 2, 2, 1, 9, 3] ++  [2, 1, 10, 6, 9, 10, 7, 6, 3, 9, 8, 2, 9, 9, 6, 4, 8, 6, 6, 9, 3, 7, 10, 3, 6, 2, 3, 6, 9, 7] ++  [1, 6, 10, 6, 8, 6, 5, 5, 3, 2, 8, 2, 9, 10, 3, 4, 8, 8, 7, 9, 3, 7, 10, 5, 6, 8, 1, 3, 9, 8] ++  [1, 6, 4, 6, 8, 3, 8, 9, 10, 4, 10, 7, 9, 10, 3, 1, 8, 8, 7, 9, 4, 7, 1, 3, 8, 8, 8, 8, 9, 8] ++  [6, 10, 10, 9, 9, 3, 2, 1, 4, 4, 5, 7, 9, 7, 6, 7, 5, 8, 3, 9, 7, 7, 1, 3, 10, 8, 8, 8, 9, 8] ++  [6, 3, 7, 9, 9, 3, 2, 9, 9, 7, 5, 7, 9, 8, 6, 5, 4, 1, 2, 1, 7, 10, 5, 6, 8, 8, 8, 6, 9, 8] ++  [6, 3, 7, 10, 6, 3, 2, 1, 9, 4, 4, 7, 9, 1, 6, 4, 4, 3, 2, 1, 10, 1, 5, 6, 8, 6, 5, 6, 2, 8] ++  [6, 3, 7, 10, 1, 8, 9, 1, 9, 4, 9, 2, 5, 1, 9, 9, 1, 6, 4, 3, 10, 5, 5, 2, 8, 6, 5, 9, 2, 4]
);