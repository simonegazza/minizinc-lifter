par int: n_shifts;
par int: n_employees;
par int: n_expertises;
array[EMPLOYEE] of par 0..1000: contract;
array[EMPLOYEE] of var 0..1000: contract_lifted :: doc_comment("contract_lifted");
array[EMPLOYEE] of par set of EXPERTISE: employee_expertises;
array[SHIFT] of par EXPERTISE: req_expertise;
array[SHIFT] of var EXPERTISE: req_expertise_lifted :: doc_comment("req_expertise_lifted");
array[SHIFT] of par 0..450: start_time;
array[SHIFT] of var 0..450: start_time_lifted :: doc_comment("start_time_lifted");
array[SHIFT] of par 0..500: stop_time;
array[SHIFT] of var 0..500: stop_time_lifted :: doc_comment("stop_time_lifted");
par int: time_units_per_hour;
par set of int: SHIFT     = 1..n_shifts;
par set of int: EMPLOYEE  = 1..n_employees;
par set of int: EXPERTISE = 1..n_expertises;

int: MAX_DIFF;

% Validations
include "sort.mzn";
constraint start_time_lifted=sort(start_time_lifted);

% Variables
array[EMPLOYEE, SHIFT] of var bool: assigned;
array[EMPLOYEE] of var int: contract_diff = [ sum (s in SHIFT) (assigned[e, s]*(stop_time_lifted[s]-start_time_lifted[s])) - contract_lifted[e] | e in EMPLOYEE ];

% Functions
function var bool: overlapping(SHIFT: s1, SHIFT: s2) = start_time_lifted[s1] < stop_time_lifted[s2] /\ start_time_lifted[s2] < stop_time_lifted[s1];
function var bool: identical_shifts(SHIFT: s1, SHIFT: s2) = start_time_lifted[s1] = start_time_lifted[s2] /\ stop_time_lifted[s1] = stop_time_lifted[s2] /\ req_expertise_lifted[s1] = req_expertise_lifted[s2];

% Constraints
constraint forall (s in SHIFT) (sum (e in EMPLOYEE) (assigned[e, s]) <= 1); % No double assignments
constraint forall (s1, s2 in SHIFT where s1 < s2 /\ overlapping(s1, s2)) (forall (e in EMPLOYEE) (assigned[e, s1] + assigned[e, s2] <= 1)); % No overlapping assignments
constraint forall (e in EMPLOYEE, s in SHIFT where not (req_expertise_lifted[s] in employee_expertises[e])) (not assigned[e, s]); % Appropriate expertise required
constraint forall (e in EMPLOYEE where contract_lifted[e] > 0) (10 * sum (s in SHIFT) (assigned[e,s] * (stop_time_lifted[s] - start_time_lifted[s])) <= 13 * contract_lifted[e]); % Not allowed to work more than 130% of your contract


% Constraints -- Symmetry-breaking
constraint symmetry_breaking_constraint(forall (s1, s2 in SHIFT where s1 < s2 /\ identical_shifts(s1, s2)) (sum (e in EMPLOYEE) (assigned[e, s2]) <= sum (e in EMPLOYEE) (assigned[e, s1])));

constraint summed_abs_contract_diff <= MAX_DIFF;

% Objective
var int: number_assigned_shifts = sum (e in EMPLOYEE, s in SHIFT) (assigned[e, s]);
var int: summed_abs_contract_diff;
constraint summed_abs_contract_diff = sum (e in EMPLOYEE) (abs(contract_diff[e]));
var int: W = 1 + max(max (e in EMPLOYEE) (contract_lifted[e]), max (s in SHIFT) (stop_time_lifted[s] - start_time_lifted[s])); % Weight factor for objective to be lexicographical
var int: objective = W*number_assigned_shifts - summed_abs_contract_diff;

output ["original contract = \(contract)\nlifted   contract = \(contract_lifted)\n\n"] ++ ["original req_expertise = \(req_expertise)\nlifted   req_expertise = \(req_expertise_lifted)\n\n"] ++ ["original start_time = \(start_time)\nlifted   start_time = \(start_time_lifted)\n\n"] ++ ["original stop_time = \(stop_time)\nlifted   stop_time = \(stop_time_lifted)\n\n"];

array[int] of int: params_int = [req_expertise[i0] | i0 in SHIFT]
	 ++ [contract[i0] | i0 in EMPLOYEE]
	 ++ [stop_time[i0] | i0 in SHIFT]
	 ++ [start_time[i0] | i0 in SHIFT];

array[int] of var int: params_int_lifted = [req_expertise_lifted[i0] | i0 in SHIFT]
	 ++ [contract_lifted[i0] | i0 in EMPLOYEE]
	 ++ [stop_time_lifted[i0] | i0 in SHIFT]
	 ++ [start_time_lifted[i0] | i0 in SHIFT];

include "experimental/assume.mzn";

array[int] of var bool: lifted_assumed = [params_int_lifted[i] = params_int[i] | i in index_set(params_int)];

array[int] of var bool: assumed = [if i in EXCLUDE_ME
	then true else lifted_assumed[i] endif | i in index_set(lifted_assumed)];

constraint assume(assumed);

constraint assert(trace(
	"Length of params_int        = \(length(params_int))\n",
	length(params_int)
)= trace(
	"Length of params_int_lifted = \(length(params_int_lifted))\n",
	length(params_int_lifted)
), "ERROR: length of parameters and lifted does not match");

var int: objective_lifted :: output_var = sum([abs(contract_lifted[i0] - contract[i0]) | i0 in EMPLOYEE])
	+ sum([abs(req_expertise_lifted[i0] - req_expertise[i0]) | i0 in SHIFT])
	+ sum([abs(start_time_lifted[i0] - start_time[i0]) | i0 in SHIFT])
	+ sum([abs(stop_time_lifted[i0] - stop_time[i0]) | i0 in SHIFT])
;
solve
	::warm_start(assumed, [true | _ in index_set(assumed)])
minimize objective_lifted;

array[int] of int: EXCLUDE_ME;
EXCLUDE_ME = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53];
