include "at_least.mzn";

int: numCargos;
int: numTanks;

array[1..numTanks] of 0..1500: capacities;
array[1..numTanks] of var 0..1500: capacities_lifted :: doc_comment("capacities_lifted");
array[1..numTanks] of set of int: neighbours;
array[1..numTanks] of set of int: impossibleCargos;
array[1..numCargos] of 0..7500: volumeToShip;
array[1..numCargos] of var 0..7500: volumeToShip_lifted :: doc_comment("volumeToShip_lifted");
array[int] of set of int: incompatibilities;

int: FREE_TANKS;

array[1..numTanks] of var 0..numCargos: allocation;

% all volumes are shiped
constraint forall(c in 1..numCargos)(sum(t in 1..numTanks where allocation[t] = c)(capacities_lifted[t]) >= volumeToShip_lifted[c]);

% no tanks filled with impossible cargo
constraint forall(t in 1..numTanks)(forall(ic in impossibleCargos[t]) (allocation[t] != ic));

% no neighbours incompatibilities
constraint forall(t in 1..numTanks)(forall(n in neighbours[t])(forall(i in incompatibilities)(if allocation[t] == i[1] then allocation[n]  != i[2] endif)));

var 0..numTanks: freeTanks;
constraint freeTanks = count(allocation, 0);

% infeasibility constraint
constraint freeTanks >= FREE_TANKS;

output ["original capacities = \(capacities)\nlifted   capacities = \(capacities_lifted)\n\n"] ++ ["original volumeToShip = \(volumeToShip)\nlifted   volumeToShip = \(volumeToShip_lifted)\n\n"];

array[int] of int: params_int = [capacities[i0] | i0 in 1..numTanks]
	 ++ [volumeToShip[i0] | i0 in 1..numCargos];

array[int] of var int: params_int_lifted = [capacities_lifted[i0] | i0 in 1..numTanks]
	 ++ [volumeToShip_lifted[i0] | i0 in 1..numCargos];

include "experimental/assume.mzn";

array[int] of var bool: lifted_assumed = [params_int_lifted[i] = params_int[i] | i in index_set(params_int)];

array[int] of var bool: assumed = [if i in EXCLUDE_ME
	then true else lifted_assumed[i] endif | i in index_set(lifted_assumed)];

constraint assume(assumed);

constraint assert(trace(
	"Length of params_int        = \(length(params_int))\n",
	length(params_int)
)= trace(
	"Length of params_int_lifted = \(length(params_int_lifted))\n",
	length(params_int_lifted)
), "ERROR: length of parameters and lifted does not match");

var int: objective_lifted :: output_var = sum([abs(capacities_lifted[i0] - capacities[i0]) | i0 in 1..numTanks])
	+ sum([abs(volumeToShip_lifted[i0] - volumeToShip[i0]) | i0 in 1..numCargos])
;
solve
	::warm_start(assumed, [true | _ in index_set(assumed)])
minimize objective_lifted;

array[int] of int: EXCLUDE_ME;
EXCLUDE_ME = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20];
