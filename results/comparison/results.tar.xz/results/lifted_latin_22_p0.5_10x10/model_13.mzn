predicate global_cardinality(
    array [$X] of var $$E: x,
    array [int] of var $$E: cover,
    array [int] of var int: lbound,
    array [int] of var int: ubound
) = forall(i in 1..length(cover))(
    sum([e = cover[i] | e in x]) in lbound[i]..ubound[i]
);

predicate cumulative(
    array[$$E] of var opt int: s,
    array[$$E] of var opt int: d,
    array[$$E] of var opt int: r,
    var int: b
) = assert(
    % They all must have same length
    index_set(s) == index_set(d) /\ index_set(s) == index_set(r),
    "cumulative redefinition: arrays must have identical index sets",

    let {
        array[index_set(s)] of var 0..ub(max(d)): d_deopt;
        array[index_set(s)] of var 0..ub(max(r)): r_deopt;
    } in
    % If s occurs than also d and r must occur, and viceversa
    forall(i in index_set(s))(occurs(s[i]) = occurs(d[i]) /\ occurs(s[i]) = occurs(r[i]))
    /\
    % "channeling" from d to define d_deopt
    d_deopt = [
        if occurs(d[i]) then d_deopt[i] = deopt(d[i]) else d_deopt[i] = 0 endif
        | i in index_set(s)]
    /\
    % "channeling" from r to define r_deopt
    r_deopt = [
        if occurs(r[i]) then r_deopt[i] = deopt(r[i]) else r_deopt[i] = 0 endif
        | i in index_set(s)]
    /\
    % Nonnegativity only when present
    forall(i in index_set(s))(occurs(d[i]) -> d[i] >= 0 /\ occurs(r[i]) -> r[i] >= 0)
    /\
    cumulative(s, d_deopt, r_deopt, b)
);

include "alldifferent.mzn";

int: n;

array[1..n, 1..n] of 0..n: initial_grid;
array[1..n, 1..n] of var 0..n: initial_grid_lifted :: doc_comment("initial_grid_lifted");

array[1..n, 1..n] of var 1..n: square :: output;

constraint forall(i in 1..n)(alldifferent([square[i, j] | j in 1..n]));

constraint forall(j in 1..n)(alldifferent([square[i, j] | i in 1..n]));

constraint forall(i in 1..n, j in 1..n)(
    if initial_grid_lifted[i, j] > 0 then
        square[i, j] = initial_grid_lifted[i, j]
    endif
);


output ["objective = \(objective_lifted)\noriginal initial_grid = \(initial_grid)\nlifted   initial_grid = \(initial_grid_lifted)\n\n"];

array[int] of int: params_int = [initial_grid[i0, i1] | i0 in 1..n, i1 in 1..n];

array[int] of var int: params_int_lifted = [initial_grid_lifted[i0, i1] | i0 in 1..n, i1 in 1..n];

include "experimental/assume.mzn";

array[int] of var bool: lifted_assumed = [params_int_lifted[i] = params_int[i] | i in index_set(params_int)];

array[int] of var bool: assumed = [if i in EXCLUDE_ME
	then true else lifted_assumed[i] endif | i in index_set(lifted_assumed)];

constraint assume(assumed);

constraint assert(trace(
	"Length of params_int        = \(length(params_int))\n",
	length(params_int)
)= trace(
	"Length of params_int_lifted = \(length(params_int_lifted))\n",
	length(params_int_lifted)
), "ERROR: length of parameters and lifted does not match");

var int: objective_lifted :: output_var = sum([abs(initial_grid_lifted[i0, i1] - initial_grid[i0, i1]) | i0 in 1..n, i1 in 1..n]);
solve
	::warm_start(assumed, [true | _ in index_set(assumed)])
minimize objective_lifted;

array[int] of int: EXCLUDE_ME;
EXCLUDE_ME = [13,15,12,22,23,26,5,35,17,37,32,42,31,51,52,54,2,21,43,44,45,47,48,49,50,55,56,3,63,8,64,68,29,69,71,75];
