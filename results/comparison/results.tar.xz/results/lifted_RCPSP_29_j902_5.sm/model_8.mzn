include "cumulative_opt.mzn";

int: jobs;
int: last_job = jobs;
set of int: JOBS = 1..jobs;
int: nb_ressource;
set of int: RESSOURCES = 1..nb_ressource;

array[RESSOURCES] of 0..100: max_ressources;
array[RESSOURCES] of var 0..100: max_ressources_lifted :: doc_comment("max_ressources_lifted");
array[JOBS] of 0..100: duration;
array[JOBS] of var 0..100: duration_lifted :: doc_comment("duration_lifted");

array[JOBS, RESSOURCES] of 0..100: ressources;
array[JOBS, RESSOURCES] of var 0..100: ressources_lifted :: doc_comment("ressources_lifted");
array[int, 1..2] of int: precedence;

array[JOBS] of var 0..ub((sum(duration_lifted) * max(JOBS))): start;
int: DEADLINE;

var int: obj;
constraint obj = start[last_job];
constraint obj <= DEADLINE;

constraint forall(resource in RESSOURCES)(assert(
    index_set(start) == index_set(duration_lifted) /\ index_set(start) == index_set([ressources_lifted[j, resource] | j in JOBS]),
    "cumulative redefinition: arrays must have identical index sets",
    let {
        array[index_set(start)] of var int: r = [ressources_lifted[j, resource] | j in JOBS];
        array[index_set(start)] of var 0..ub(max(duration_lifted)): d_deopt;
        array[index_set(start)] of var 0..ub(max(r)): r_deopt;
    } in
    forall(i in index_set(start))(occurs(start[i]) = occurs(duration_lifted[i]) /\ occurs(start[i]) = occurs(r[i]))
    /\
    d_deopt = [
        if occurs(duration_lifted[i]) then d_deopt[i] = deopt(duration_lifted[i]) else d_deopt[i] = 0 endif
        | i in index_set(start)]
    /\
    r_deopt = [
        if occurs(r[i]) then r_deopt[i] = deopt(r[i]) else r_deopt[i] = 0 endif
        | i in index_set(start)]
    /\
    forall(i in index_set(start))(occurs(duration_lifted[i]) -> duration_lifted[i] >= 0 /\ occurs(r[i]) -> r[i] >= 0)
    /\
    cumulative(
        [start[j] | j in JOBS where ressources_lifted[j, resource] > 0],
        d_deopt,
        r_deopt,
        max_ressources_lifted[resource]))
);

constraint forall(p in index_set_1of2(precedence))(
         (start[precedence[p, 1]] + duration_lifted[precedence[p,1]] <= start[precedence[p, 2]]));

output ["original duration = \(duration)\nlifted   duration = \(duration_lifted)\n\n"] ++ ["original max_ressources = \(max_ressources)\nlifted   max_ressources = \(max_ressources_lifted)\n\n"] ++ ["original ressources = \(ressources)\nlifted   ressources = \(ressources_lifted)\n\n"];

array[int] of int: params_int = [ressources[i0, i1] | i0 in JOBS, i1 in RESSOURCES]
	 ++ [duration[i0] | i0 in JOBS]
	 ++ [max_ressources[i0] | i0 in RESSOURCES];

array[int] of var int: params_int_lifted = [ressources_lifted[i0, i1] | i0 in JOBS, i1 in RESSOURCES]
	 ++ [duration_lifted[i0] | i0 in JOBS]
	 ++ [max_ressources_lifted[i0] | i0 in RESSOURCES];

include "experimental/assume.mzn";

array[int] of var bool: lifted_assumed = [params_int_lifted[i] = params_int[i] | i in index_set(params_int)];

array[int] of var bool: assumed = [if i in EXCLUDE_ME
	then true else lifted_assumed[i] endif | i in index_set(lifted_assumed)];

constraint assume(assumed);

constraint assert(trace(
	"Length of params_int        = \(length(params_int))\n",
	length(params_int)
)= trace(
	"Length of params_int_lifted = \(length(params_int_lifted))\n",
	length(params_int_lifted)
), "ERROR: length of parameters and lifted does not match");

var int: objective_lifted :: output_var = sum([abs(duration_lifted[i0] - duration[i0]) | i0 in JOBS])
	+ sum([abs(max_ressources_lifted[i0] - max_ressources[i0]) | i0 in RESSOURCES])
	+ sum([abs(ressources_lifted[i0, i1] - ressources[i0, i1]) | i0 in JOBS, i1 in RESSOURCES])
;
solve
	::warm_start(assumed, [true | _ in index_set(assumed)])
minimize objective_lifted;

array[int] of int: EXCLUDE_ME;
EXCLUDE_ME = [369,370,382,383,387,389,392,401,417,443,449,450,451,456,458,460,368,352,348,344,340];
