include "globals.mzn";

int: WTab;
int: HTab;
int: WMin;
int: HMin;
int: NTypes;
int: WBar;
array[1..NTypes] of int: _NFix;
array[0..NTypes] of int: WFix;
array[0..NTypes] of int: HFix;

int: minFix; % min no. of fixtures.
int: maxFix; % max no. of fixtures.
int: maxFixBars;

array [1..maxFix] of var 0..WTab: x;
array [1..maxFix] of var 0..HTab: y;
array [1..maxFix] of var 0..NTypes: t;

int: NExt;
array [1..NExt] of int: HExt;
array [1..NExt] of int: WExt;
array [1..NExt] of int: XExt;
array [1..NExt] of int: YExt;

int: NIneq;
array [1..NIneq, 1..5] of int: ineq_coeff;

array [1..NTypes] of var 0..maxFix: _n;
var minFix..maxFix: n;

function var int:
xc(var 0..maxFix: i) ::promise_total = (x[i] + (WFix[t[i]] div 2));
function var int:
yc(var 0..maxFix: i) ::promise_total = (y[i] + (HFix[t[i]] div 2));

% Redundant constraints to better handle xc and yc division by 2.
constraint forall(i in 1..maxFix) (
let {
  var {0, 144, 180}: wx = WFix[t[i]] - (WFix[t[i]] mod 2);
  var {0, 144,  64}: wy = HFix[t[i]] - (HFix[t[i]] mod 2);
  var 1..3: b = t[i] + 1;
} in
  wx = [0, 144, 180][b] /\
  wy = [0, 144,  64][b] /\
  2*xc(i) - 2*x[i] = wx /\
  2*yc(i) - 2*y[i] = wy /\
  wx >= wy
);
% Balancing fixtures: aorund half must stay in bottom-left part of the tab.
constraint forall (i in 1..n div 2) (
  2*x[i] <= max(x) - min(x) + 1 /\ 
  2*y[i] <= max(y) - min(y) + 1
);

constraint n = sum(_n);

constraint _n = [count(t,i) | i in 1..NTypes] /\ count(t,0) = maxFix - n;

constraint forall(i in 1..NTypes)(_n[i] <= _NFix[i]);

constraint lex_chain(array2d(1..2, 1..maxFix, x ++ y));

constraint forall (i in 1..maxFix) (
  (i > n) <-> (x[i] = WTab /\ y[i] = HTab /\ t[i] = 0)
);

constraint diffn_nonstrict(
  x ++ XExt, y ++ YExt, [WFix[t[i]] | i in 1..maxFix] ++ WExt, [HFix[t[i]] | i in 1..maxFix] ++ HExt
);

constraint forall (i, j in 1..n where i < j) (
 [xc(i) + WBar + WMin <= xc(j), y[i] + HFix[t[i]] + HMin <= y[j] \/ y[j] + HFix[t[j]] + HMin  <= y[i]][(xc(i) == xc(j)) + 1]
 );

constraint forall (i in 2..n where xc(i-1) < xc(i)) (
  xc(i-1) + WBar + WMin <= xc(i)
);

constraint forall (j in 1..NIneq, i in 1..n)(
let {
  var int: x1 = x[i] + WFix[t[i]];
  var int: y1 = y[i] + HFix[t[i]];
} in
  ineq_coeff[j, 1] * x[i] +
  ineq_coeff[j, 2] * y[i] +
  ineq_coeff[j, 3] * x1   +
  ineq_coeff[j, 4] * y1   +
  ineq_coeff[j, 5] <= 0
);

% Maximize distance between pairs of centroids plus sum widths + heights
solve
%   :: restart_constant(1000)
%   :: relax_and_reconstruct(x, 80)
 maximize sum(i, j in 1..n where i < j)(
   abs(xc(j) - xc(i)) + abs(yc(j) - yc(i))
) + sum(i in 1..n)(WFix[t[i]] * HFix[t[i]]);

output [
  "{\n",
  "\"x\": ", show([x[i] | i in 1..n]), ",\n",
  "\"y\": ", show([y[i] | i in 1..n]), ",\n",
  "\"x1\": ", show([x[i] | i in 1..n]), ",\n",
  "\"y1\": ", show([(y[i] + HFix[t[i]]) | i in 1..n]), ",\n",
  "\"x2\": ", show([(x[i] + WFix[t[i]]) | i in 1..n]), ",\n",
  "\"y2\": ", show([(y[i] + HFix[t[i]]) | i in 1..n]), ",\n",
  "\"x3\": ", show([(x[i] + WFix[t[i]]) | i in 1..n]), ",\n",
  "\"y3\": ", show([y[i] | i in 1..n]), ",\n",
  "\"angle\": ", show([0 | i in 1..n]), ",\n",
  "\"fixtures_center_x\": ", show([(x[i] + (WFix[t[i]] / 2)) | i in 1..n]), ",\n",
  "\"fixtures_center_y\": ", show([(y[i] + (HFix[t[i]] / 2)) | i in 1..n]), ",\n",
  "\"bars_center\": ", show([x[i] + (WFix[t[i]] div 2) | i in 1..n]), ",\n",
  "\"selected_fixture\": ", show([1 * (t[i] != 0) | i in 1..n]), ",\n",
  "\"fixture_type\": ", show([t[i] | i in 1..n]), ",\n",
  "\"objective_value\": ", show(_objective), "\n",
  "}\n"
];

% % Coffee table with Chuffed:
% {
% "x": [206, 206, 206, 551, 551, 551, 881, 899, 899],
% "y": [30, 275, 520, 0, 245, 554, 562, 72, 317],
% "x1": [206, 206, 206, 551, 551, 551, 881, 899, 899],
% "y1": [175, 420, 665, 145, 390, 699, 627, 217, 462],
% "x2": [351, 351, 351, 696, 696, 696, 1061, 1044, 1044],
% "y2": [175, 420, 665, 145, 390, 699, 627, 217, 462],
% "x3": [351, 351, 351, 696, 696, 696, 1061, 1044, 1044],
% "y3": [30, 275, 520, 0, 245, 554, 562, 72, 317],
% "angle": [0, 0, 0, 0, 0, 0, 0, 0, 0],
% "fixtures_center_x": [278.5, 278.5, 278.5, 623.5, 623.5, 623.5, 971.0, 971.5, 971.5],
% "fixtures_center_y": [102.5, 347.5, 592.5, 72.5, 317.5, 626.5, 594.5, 144.5, 389.5],
% "bars_center": [278, 278, 278, 623, 623, 623, 971, 971, 971],
% "selected_fixture": [1, 1, 1, 1, 1, 1, 1, 1, 1],
% "fixture_type": [1, 1, 1, 1, 1, 1, 2, 1, 1],
% "objective_value": 201694
% }
% ----------
% ==========
% % [X_INTRODUCED_49_ <= 201694]
% real 63.67
% user 63.50
% sys 0.15

WTab=2500;
HTab=1500;
NTypes=2;
WBar=145;
_NFix=[24,12];
WFix=array1d(0..NTypes,[145,0,180]);
HFix=array1d(0..NTypes,[65,0,145]);
maxFixBars=3;
minFix=6;
maxFix=10;
NExt=0;
HExt=[];
WExt=[];
XExt=[];
YExt=[];
ineq_coeff=[|0,0,0,1,-699,|-1,0,0,0,1|-2,0,0,34,-23424,|-5,0,0,34,-22135,|-8,0,0,33,-20747,|-12,0,0,32,-19276,|-15,0,0,31,-17735,|-18,0,0,29,-16138,|-20,0,0,28,-14502,|-23,0,0,25,-12841,|-25,0,0,23,-11173,|-28,0,0,20,-9513,|-29,0,0,18,-7876,|-31,0,0,15,-6280,|-32,0,0,12,-4738,|-33,0,0,8,-3267,|-34,0,0,5,-1880,|-34,0,0,2,-590,|-34,-2,0,0,590,|-34,-5,0,0,1648,|-33,-8,0,0,2575,|-32,-12,0,0,3362,|-31,-15,0,0,4000,|-29,-18,0,0,4484,|-28,-20,0,0,4810,|-25,-23,0,0,4974,|-23,-25,0,0,4974,|-20,-28,0,0,4810,|-18,-29,0,0,4484,|-15,-31,0,0,4000,|-12,-32,0,0,3362,|-8,-33,0,0,2575,|-5,-34,0,0,1648,|-2,-34,0,0,590,|0,-34,2,0,-1433,|0,-34,5,0,-4399,|0,-33,8,0,-7440,|0,-32,12,0,-10524,|0,-31,15,0,-13622,|0,-29,18,0,-16705,|0,-28,20,0,-19743,|0,-25,23,0,-22706,|0,-23,25,0,-25566,|0,-20,28,0,-28296,|0,-18,29,0,-30868,|0,-15,31,0,-33259,|0,-12,32,0,-35446,|0,-8,33,0,-37406,|0,-5,34,0,-39122,|0,-2,34,0,-40577,|0,0,34,2,-41757,|0,0,34,5,-42650,|0,0,33,8,-43248,|0,0,32,12,-43546,|0,0,31,15,-43539,|0,0,29,18,-43229,|0,0,28,20,-42618,|0,0,25,23,-41713,|0,0,23,25,-40521,|0,0,20,28,-39055,|0,0,18,29,-37328,|0,0,15,31,-35357,|0,0,12,32,-33162,|0,0,8,33,-30762,|0,0,5,34,-28182,|0,0,2,34,-25447,|];
NIneq=66;
WMin = 216% CHANGED HERE from 220 to 216
;
HMin = 115% CHANGED HERE from 110 to 115
;
