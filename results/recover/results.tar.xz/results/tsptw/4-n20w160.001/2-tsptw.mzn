predicate global_cardinality(
    array [$X] of var $$E: x,
    array [int] of var $$E: cover,
    array [int] of var int: lbound,
    array [int] of var int: ubound
) = forall(i in 1..length(cover))(
    sum([e = cover[i] | e in x]) in lbound[i]..ubound[i]
);

predicate cumulative(
    array[$$E] of var opt int: s,
    array[$$E] of var opt int: d,
    array[$$E] of var opt int: r,
    var int: b
) = assert(
    % They all must have same length
    index_set(s) == index_set(d) /\ index_set(s) == index_set(r),
    "cumulative redefinition: arrays must have identical index sets",

    let {
        array[index_set(s)] of var 0..ub(max(d)): d_deopt;
        array[index_set(s)] of var 0..ub(max(r)): r_deopt;
    } in
    % If s occurs than also d and r must occur (d and r may be non-optional,
    % so an absent task must not force them to be absent)
    forall(i in index_set(s))(occurs(s[i]) -> (occurs(d[i]) /\ occurs(r[i])))
    /\
    % "channeling" from d to define d_deopt
    forall(i in index_set(s))(
        if occurs(d[i]) then d_deopt[i] = deopt(d[i]) else d_deopt[i] = 0 endif)
    /\
    % "channeling" from r to define r_deopt
    forall(i in index_set(s))(
        if occurs(r[i]) then r_deopt[i] = deopt(r[i]) else r_deopt[i] = 0 endif)
    /\
    % Nonnegativity only when present
    forall(i in index_set(s))((occurs(d[i]) -> d[i] >= 0) /\ (occurs(r[i]) -> r[i] >= 0))
    /\
    cumulative(s, d_deopt, r_deopt, b)
);

% Taken from https://github.com/MiniZinc/mzn-challenge/blob/develop/2025/tsptw/tsptw.mzn

% Copyright 2025 Frej Knutar Lewander
%
% Permission is hereby granted, free of charge, to any person obtaining a copy
% of this software and associated documentation files (the “Software”), to deal
% in the Software without restriction, including without limitation the rights
% to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
% copies of the Software, and to permit persons to whom the Software is
% furnished to do so, subject to the following conditions:
%
% The above copyright notice and this permission notice shall be included in
% all copies or substantial portions of the Software.
%
% THE SOFTWARE IS PROVIDED “AS IS”, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
% IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
% FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
% AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
% LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
% OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
% SOFTWARE.
include "globals.mzn";
int: numLocations; % the total number of locations (including the depot)
set of int: Locations = 1..numLocations;
% early[l] = the earliest visiting time of location l:
array[Locations] of int: early;
array[Locations] of var min(early)..max(early): early_lifted :: doc_comment("early_lifted");
% late[l] = the latest visiting time of location l:
array[Locations] of int: late;
array[Locations] of var min(late)..max(late): late_lifted :: doc_comment("late_lifted");
array[Locations, Locations] of int: duration;
array[Locations, Locations] of var min(duration)..max(duration): duration_lifted :: doc_comment("duration_lifted");
int: depot = 1; % The first location is the depot
% pred[l] = the location visited before location l:
array[Locations] of var Locations: pred;
% durToPred[l] = the distance from location pred[l] to location l:
array[Locations] of var 0..ub(max(duration_lifted)): durToPred = [
    duration_lifted[l, pred[l]] | l in Locations];
% arrival[l] = the arrival at location l:
array[Locations] of var 0..ub(max(late_lifted)): arrival;
% departure[l] = the departure at location l:
array[Locations] of var lb(min(early_lifted))..ub(max(late_lifted)): departure = [0] ++ [
    max(arrival[l], early_lifted[l]) | l in 2..numLocations];
% departurePred[l] = the departure from location pred[l]:
array[Locations] of var 0..ub(max(late_lifted)): departurePred = [
    departure[pred[l]] | l in Locations];
% The objective is the arrival back at the depot:
var int: objective = arrival[depot];
% The arrival at location l is the departure from location pred[l] +
% The duration from pred[l] to l:
constraint forall (l in Locations) (
    arrival[l] = departurePred[l] + durToPred[l]);
% The pred variables forms a Hamiltionian circuit:
constraint circuit(pred) :: domain;
% The departure from location l is before its latest visiting time late[l]:
constraint forall (l in Locations) (departure[l] <= late_lifted[l]);
% Search strategy: first try to create the Hamiltonian circuit, then try to
%                  reduce the arrival times.


numLocations=21;
duration=[|0,15,8,32,18,16,36,29,33,29,7,21,24,4,19,25,9,34,40,7,31|15,0,22,19,8,6,21,14,26,36,14,13,31,14,16,26,18,20,34,8,32|8,22,0,40,27,24,43,36,33,22,15,29,18,9,28,23,16,42,40,14,28|32,19,40,0,14,17,6,8,37,54,28,15,49,32,19,42,31,2,43,26,47|18,8,27,14,0,3,19,14,34,43,14,5,38,18,9,34,17,16,41,13,40|16,6,24,17,3,0,21,15,32,40,12,7,35,16,9,32,15,18,40,11,37|36,21,43,6,19,21,0,7,35,55,33,21,50,35,25,42,36,4,40,29,47|29,14,36,8,14,15,7,0,29,47,27,17,43,28,22,35,30,8,35,23,40|33,26,33,37,34,32,35,29,0,28,37,39,25,29,41,14,40,36,8,27,15|29,36,22,54,43,40,55,47,28,0,36,47,5,26,47,15,37,54,31,30,14|7,14,15,28,14,12,33,27,37,36,0,15,31,10,13,32,4,30,44,9,37|21,13,29,15,5,7,21,17,39,47,15,0,42,21,4,39,17,17,46,17,45|24,31,18,49,38,35,50,43,25,5,31,42,0,22,42,11,33,49,29,25,13|4,14,9,32,18,16,35,28,29,26,10,21,22,0,21,22,12,33,36,5,28|19,16,28,19,9,9,25,22,41,47,13,4,42,21,0,40,14,22,49,17,46|25,26,23,42,34,32,42,35,14,15,32,39,11,22,40,0,34,42,18,23,6|9,18,16,31,17,15,36,30,40,37,4,17,33,12,14,34,0,33,48,13,40|34,20,42,2,16,18,4,8,36,54,30,17,49,33,22,42,33,0,43,28,48|40,34,40,43,41,40,40,35,8,31,44,46,29,36,49,18,48,43,0,35,17|7,8,14,26,13,11,29,23,27,30,9,17,25,5,17,23,13,28,35,0,29|31,32,28,47,40,37,47,40,15,14,37,45,13,28,46,6,40,48,17,29,0|];
early=[0,0,155,0,0,0,0,0,162,104,0,0,70,34,3,101,39,269,272,0,195];
late = array1d(1..21, [486, 124, 307, 137, 117, 169% CHANGED HERE from 153 to 169
, 140% CHANGED HERE from 126 to 140
, 80% CHANGED HERE from 142 to 80
, 307, 286, 72, 453% CHANGED HERE from 129 to 453
, 373% CHANGED HERE from 272 to 373
, 170, 205, 232, 232, 72, 446, 110, 381]);

output ["original duration = \(duration)\nlifted   duration = \(duration_lifted)\n\n"] ++ ["original early = \(early)\nlifted   early = \(early_lifted)\n\n"] ++ ["original late = \(late)\nlifted   late = \(late_lifted)\n\n"];

constraint forall(lifted_bound_element in durToPred)(lifted_bound_element <= (max(duration_lifted)));
constraint forall(lifted_bound_element in arrival)(lifted_bound_element <= (max(late_lifted)));
constraint forall(lifted_bound_element in departure)(lifted_bound_element >= (min(early_lifted)));
constraint forall(lifted_bound_element in departure)(lifted_bound_element <= (max(late_lifted)));
constraint forall(lifted_bound_element in departurePred)(lifted_bound_element <= (max(late_lifted)));
array[int] of int: params_int = [duration[i0, i1] | i0 in Locations, i1 in Locations]
	 ++ [early[i0] | i0 in Locations]
	 ++ [late[i0] | i0 in Locations];

array[int] of var int: params_int_lifted = [duration_lifted[i0, i1] | i0 in Locations, i1 in Locations]
	 ++ [early_lifted[i0] | i0 in Locations]
	 ++ [late_lifted[i0] | i0 in Locations];

include "experimental/assume.mzn";

array[int] of var bool: lifted_assumed = [params_int_lifted[i] = params_int[i] | i in index_set(params_int)];

array[int] of var bool: assumed = [if i in 
	{459, 480}
	then true else lifted_assumed[i] endif | i in index_set(lifted_assumed)];

constraint assume(assumed);

constraint assert(trace(
	"Length of params_int        = \(length(params_int))\n",
	length(params_int)
)= trace(
	"Length of params_int_lifted = \(length(params_int_lifted))\n",
	length(params_int_lifted)
), "ERROR: length of parameters and lifted does not match");

var int: objective_lifted :: output_var = sum([abs(duration_lifted[i0, i1] - duration[i0, i1]) | i0 in Locations, i1 in Locations])
	+ sum([abs(early_lifted[i0] - early[i0]) | i0 in Locations])
	+ sum([abs(late_lifted[i0] - late[i0]) | i0 in Locations])
;
solve
	::warm_start(assumed, [true | _ in index_set(assumed)])
minimize objective_lifted;

output ["_objective = \(objective_lifted)\n"];

