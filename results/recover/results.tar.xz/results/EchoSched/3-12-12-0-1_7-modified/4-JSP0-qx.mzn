
constraint forall(assumed);
predicate global_cardinality(
    array [$X] of var $$E: x,
    array [int] of var $$E: cover,
    array [int] of var int: lbound,
    array [int] of var int: ubound
) = forall(i in 1..length(cover))(
    sum([e = cover[i] | e in x]) in lbound[i]..ubound[i]
);

predicate cumulative(
    array[$$E] of var opt int: s,
    array[$$E] of var opt int: d,
    array[$$E] of var opt int: r,
    var int: b
) = assert(
    % They all must have same length
    index_set(s) == index_set(d) /\ index_set(s) == index_set(r),
    "cumulative redefinition: arrays must have identical index sets",

    let {
        array[index_set(s)] of var 0..ub(max(d)): d_deopt;
        array[index_set(s)] of var 0..ub(max(r)): r_deopt;
    } in
    % If s occurs than also d and r must occur, and viceversa
    forall(i in index_set(s))(occurs(s[i]) = occurs(d[i]) /\ occurs(s[i]) = occurs(r[i]))
    /\
    % "channeling" from d to define d_deopt
    d_deopt = [
        if occurs(d[i]) then d_deopt[i] = deopt(d[i]) else d_deopt[i] = 0 endif
        | i in index_set(s)]
    /\
    % "channeling" from r to define r_deopt
    r_deopt = [
        if occurs(r[i]) then r_deopt[i] = deopt(r[i]) else r_deopt[i] = 0 endif
        | i in index_set(s)]
    /\
    % Nonnegativity only when present
    forall(i in index_set(s))(occurs(d[i]) -> d[i] >= 0 /\ occurs(r[i]) -> r[i] >= 0)
    /\
    cumulative(s, d_deopt, r_deopt, b)
);

% Taken from https://github.com/MiniZinc/mzn-challenge/blob/develop/2025/EchoSched/JSP0.mzn
% Minor changes have been made

% Modifications by MiniZinc Challenge Organizers:
% - Modify search annotation to allow running in FD
% - Name objective variable `objective`
% - Fix redundant constraint to be hard constraint

% sets
set of int: JOBS;
set of int: MACHINES;
int: SPEED;

% data
array[JOBS,MACHINES,1..SPEED] of int: time;
array[JOBS, MACHINES, 1..SPEED] of var 1..max(time): time_lifted :: doc_comment("time_lifted");
array[JOBS,MACHINES,1..SPEED] of int: energy;
array[JOBS, MACHINES, 1..SPEED] of var min(energy)..max(energy): energy_lifted :: doc_comment("energy_lifted");
array[JOBS,MACHINES] of int: precedence;
array[JOBS, MACHINES] of var 0..13: precedence_lifted :: doc_comment("precedence_lifted");

% variables
array[JOBS,MACHINES] of var 0..ub(sum(time_lifted)): start_time; % CHANGE: removed annotation ":: output" here
array[JOBS,MACHINES] of var 1..SPEED: SpeedScaling; % CHANGE: removed annotation ":: output" here


constraint forall(j in JOBS, p in MACHINES, s in MACHINES where p != s)(
  if precedence_lifted[j,p] > precedence_lifted[j,s] then
      start_time[j,p] >= start_time[j,s] + time_lifted[j,s,SpeedScaling[j,s]]
  else
      start_time[j,s] >= start_time[j,p] + time_lifted[j,p,SpeedScaling[j,p]]
  endif
);


constraint forall(j1 in JOBS, j2 in JOBS, m in MACHINES where j1 < j2)(
  %redundant_constraint (start_time[j1,m] + time[j1,m,SpeedScaling[j1,m]] <= start_time[j2,m] \/ start_time[j2,m] + time[j2,m,SpeedScaling[j2,m]] <= start_time[j1,m]
  (start_time[j1,m] + time_lifted[j1,m,SpeedScaling[j1,m]] <= start_time[j2,m] \/ start_time[j2,m] + time_lifted[j2,m,SpeedScaling[j2,m]] <= start_time[j1,m]
));


var int: makespan = max([start_time[j,m] + time[j,m,SpeedScaling[j,m]] | m in MACHINES, j in JOBS]); % CHANGE: removed annotation ":: output" here
var int: consumedEnergy = sum(m in MACHINES, j in JOBS) (energy[j,m,SpeedScaling[j,m]]); % CHANGE: removed annotation ":: output" here

var int: objective = makespan + consumedEnergy;


JOBS=1..12;
MACHINES=1..12;
SPEED=1;
time = array3d(1..12, 1..12, 1..1, [12, 1, 8, 62, 6, 15, 69, 1, 23, 77, 6, 20, 62, 3, 19, 35, 28, 16, 5, 17, 12, 16, 11, 47, 37, 9, 21, 8, 15, 11, 27, 11, 15, 32, 13, 61, 5, 34, 14, 14, 26, 19, 13, 1, 2, 31, 19, 30, 80, 29, 1, 9, 23, 6, 86, 75, 48, 16, 47, 3, 9, 16, 35, 17, 3, 10, 10, 9, 4, 13, 15, 38, 41, 19, 15, 38, 56, 29, 41, 72, 1, 53, 8, 16, 41, 32, 4, 27, 1, 11, 43, 14, 23, 33, 44, 36, 1, 14, 16, 1, 20, 24, 45, 73, 3, 6, 27, 3, 6, 40% CHANGED HERE from 22 to 40
, 4, 39, 50, 1, 19, 41, 95, 8, 4, 54, 62, 33% CHANGED HERE from 5 to 33
, 15, 32, 48, 4, 28, 42, 20, 4, 1, 8, 42, 1, 53% CHANGED HERE from 1 to 53
, 11, 1, 4, 1, 19, 30, 14, 3, 10]);
energy = array3d(1..12, 1..12, 1..1, [88, 87% CHANGED HERE from 99 to 87
, 92, 53, 94, 86, 50, 99, 89% CHANGED HERE from 79 to 89
, 46, 94, 81, 53, 97, 82, 70, 75, 85, 95, 84, 88, 81% CHANGED HERE from 85 to 81
, 89, 62, 69, 91, 81, 92, 86, 89, 76, 89, 86, 72, 87, 54, 95, 71, 86, 86, 77, 82, 87, 99, 98, 73, 82, 74, 44, 74, 99, 91, 79, 94, 42, 47, 61, 85, 62, 97, 91, 85, 70, 84, 97, 90, 90, 91, 96, 87, 86, 68, 66, 82, 86, 68, 57, 74, 66, 48, 99, 58, 92, 85, 66, 72, 96, 76, 99, 89, 65, 86, 79, 71, 64, 69, 99, 86, 85, 99, 81, 78, 63, 48, 97, 94, 76, 97, 94, 80, 96, 67, 60, 99, 82, 66, 38, 92, 96, 58, 53, 95, 86, 72, 61, 96, 75, 65, 81, 96, 99, 92, 65, 99, 99, 89, 99, 96, 99, 82, 74, 86, 97, 90]);
precedence = array2d(1..12, 1..12, [9, 3, 1, 4, 7, 6, 2, 5, 8, 11, 10, 10, 9, 0, 6, 2, 10, 3, 5, 8, 1, 4, 11, 7, 4, 6, 5, 11, 2, 1, 3, 7, 9, 10, 0, 8, 9, 10, 7, 3, 4, 1, 0, 6, 2, 5, 8, 11, 3, 10, 6, 2, 11, 7, 9, 4, 8, 0, 1, 5, 4, 11, 10, 2, 1, 8, 0, 5, 9, 3, 7, 6, 7, 3% CHANGED HERE from 0 to 3
, 9, 5, 11, 6, 10, 2, 4, 1, 8, 3, 0, 4, 5, 1, 2, 11, 6, 8, 10, 9, 7, 3, 10, 3, 0, 9, 11, 8, 7, 4, 1, 2, 5, 6, 0, 1, 4, 5, 10, 7, 3, 8, 9, 6, 2, 11, 2, 11, 8, 7, 9, 0, 3, 6, 8% CHANGED HERE from 10 to 8
, 1, 4, 5, 6, 10, 9, 8, 7, 1, 0, 2, 11, 5, 4, 3]);

output ["original energy = \(energy)\nlifted   energy = \(energy_lifted)\n\n"] ++ ["original precedence = \(precedence)\nlifted   precedence = \(precedence_lifted)\n\n"] ++ ["original time = \(time)\nlifted   time = \(time_lifted)\n\n"];

array[int] of int: params_int = [time[i0, i1, i2] | i0 in JOBS, i1 in MACHINES, i2 in 1..SPEED]
	 ++ [energy[i0, i1, i2] | i0 in JOBS, i1 in MACHINES, i2 in 1..SPEED]
	 ++ [precedence[i0, i1] | i0 in JOBS, i1 in MACHINES];

array[int] of var int: params_int_lifted = [time_lifted[i0, i1, i2] | i0 in JOBS, i1 in MACHINES, i2 in 1..SPEED]
	 ++ [energy_lifted[i0, i1, i2] | i0 in JOBS, i1 in MACHINES, i2 in 1..SPEED]
	 ++ [precedence_lifted[i0, i1] | i0 in JOBS, i1 in MACHINES];

include "experimental/assume.mzn";

array[int] of var bool: lifted_assumed = [params_int_lifted[i] = params_int[i] | i in index_set(params_int)];

array[int] of var bool: assumed = [if i in 
	{1, 3, 4, 5, 6, 7, 9, 11, 12, 73, 74, 75, 76, 78, 79, 80, 82, 83, 84, 121, 123, 124, 125, 126, 127, 128, 129, 289, 290, 291, 292, 293, 294, 295, 296, 297, 298, 299, 300, 361, 362, 363, 364, 365, 366, 367, 368, 369, 370, 371, 372, 409, 410, 411, 412, 413, 414, 415, 416, 417}
	then true else lifted_assumed[i] endif | i in index_set(lifted_assumed)];


constraint assert(trace(
	"Length of params_int        = \(length(params_int))\n",
	length(params_int)
)= trace(
	"Length of params_int_lifted = \(length(params_int_lifted))\n",
	length(params_int_lifted)
), "ERROR: length of parameters and lifted does not match");

var int: objective_lifted :: output_var = sum([abs(energy_lifted[i0, i1, i2] - energy[i0, i1, i2]) | i0 in JOBS, i1 in MACHINES, i2 in 1..SPEED])
	+ sum([abs(precedence_lifted[i0, i1] - precedence[i0, i1]) | i0 in JOBS, i1 in MACHINES])
	+ sum([abs(time_lifted[i0, i1, i2] - time[i0, i1, i2]) | i0 in JOBS, i1 in MACHINES, i2 in 1..SPEED])
;
solve
	::warm_start(assumed, [true | _ in index_set(assumed)])
minimize objective_lifted;
