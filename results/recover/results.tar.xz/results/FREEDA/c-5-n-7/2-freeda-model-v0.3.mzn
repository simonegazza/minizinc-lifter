predicate global_cardinality(
    array [$X] of var $$E: x,
    array [int] of var $$E: cover,
    array [int] of var int: lbound,
    array [int] of var int: ubound
) = forall(i in 1..length(cover))(
    sum([e = cover[i] | e in x]) in lbound[i]..ubound[i]
);

predicate cumulative(
    array[$$E] of var opt int: s,
    array[$$E] of var opt int: d,
    array[$$E] of var opt int: r,
    var int: b
) = assert(
    % They all must have same length
    index_set(s) == index_set(d) /\ index_set(s) == index_set(r),
    "cumulative redefinition: arrays must have identical index sets",

    let {
        array[index_set(s)] of var 0..ub(max(d)): d_deopt;
        array[index_set(s)] of var 0..ub(max(r)): r_deopt;
    } in
    % If s occurs than also d and r must occur (d and r may be non-optional,
    % so an absent task must not force them to be absent)
    forall(i in index_set(s))(occurs(s[i]) -> (occurs(d[i]) /\ occurs(r[i])))
    /\
    % "channeling" from d to define d_deopt
    forall(i in index_set(s))(
        if occurs(d[i]) then d_deopt[i] = deopt(d[i]) else d_deopt[i] = 0 endif)
    /\
    % "channeling" from r to define r_deopt
    forall(i in index_set(s))(
        if occurs(r[i]) then r_deopt[i] = deopt(r[i]) else r_deopt[i] = 0 endif)
    /\
    % Nonnegativity only when present
    forall(i in index_set(s))((occurs(d[i]) -> d[i] >= 0) /\ (occurs(r[i]) -> r[i] >= 0))
    /\
    cumulative(s, d_deopt, r_deopt, b)
);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%% MiniZinc parametric model for FREEDA %%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

include "globals.mzn";

%%%%%%%%%%%%%%%%%%%%%%
%%%%% Parameters %%%%%
%%%%%%%%%%%%%%%%%%%%%%

%%%%% Components and Flavours %%%%%

% All the components.
enum Comps;
% Components that *must* always be deployed.
set of Comps: mustComps;

% All the flavours.
enum Flavs;
% Flav[c] is the set of all flavours offered by component c.
array[Comps] of set of Flavs: Flav;

% CompFlavs is the index set for the rows of the deployment matrices.
set of int: CompFlavs = 1..sum(c in Comps)(length(Flav[c]));
% Idx(c,f) is the row of component c in flavour f in the deployment matrices.
% It maps pairs from Comps × Flavs to indices of CompFlavs.
function int:
Idx(Comps: c, Flavs: f) =
  sum (i in 1..c-1)(length(Flav[Comps[i]])) + arg_max([f = i | i in Flav[c]]);

% Importance of a component in a given flavour.
% FIXME: we assume f ⪯c f′ iff imp(c,f) ≤ imp(c,f′).
array[Comps, Flavs] of int: imp;

% Uses[Idx(c,f),Idx(c',f')] = 1 iff component c in flavour f requires component
% c' in a flavour at least as powerful as f′.
array[CompFlavs, CompFlavs] of 0..1: Uses;

% mayUse[c,Idx(c',f)] = 1 iff c' in flavour f may use c in some flavour.
array[Comps, CompFlavs] of 0..1: mayUse;

%%%%% Resources %%%%%

% Consumable resources.
enum CRes;
% Non-consumable resources.
enum NRes;
% All the resources.
enum Res = C(CRes) ++ N(NRes);

% Req_cf[Idx(c,f)] is the set of resources required by c in flavour f.
array[CompFlavs] of set of Res: Req_cf = [
  {r | r in Res where comReq[cf, r] != worstBounds[r]} | cf in CompFlavs
];
array[CompFlavs] of var set of Res: Req_cf_lifted = [
  {r | r in Res where comReq_lifted[cf, r] != worstBounds[r]} | cf in CompFlavs
];

% Req_cfc[c,f,c'] is the set of resources required by the connection between
% "source" component c, deployed in flavour f, and "target" component c′.
array[Comps, Flavs, Comps] of set of Res: Req_cfc = array3d(Comps, Flavs, Comps,
  [{r | r in Res where depReq[c1, i, c2, r] != worstBounds[r]}
  | c1 in Comps, i in Flavs, c2 in Comps
  ]);
array[Comps, Flavs, Comps] of var set of Res: Req_cfc_lifted = array3d(Comps, Flavs, Comps,
  [{r | r in Res where depReq_lifted[c1, i, c2, r] != worstBounds[r]}
  | c1 in Comps, i in Flavs, c2 in Comps
  ]);

% Lower bound for bestBounds and worseBounds values.
int: MIN_RBOUNDS;
% Upper bound for bestBounds and worseBounds values.
int: MAX_RBOUNDS;
% No value for a resource r can be worse than worstBounds[r].
array[Res] of MIN_RBOUNDS..MAX_RBOUNDS: bestBounds;
% No value for a resource r can be better than bestBounds[r].
array[Res] of MIN_RBOUNDS..MAX_RBOUNDS: worstBounds;

% comReq[Idx(c,f), r] defines the amount of resource r in Req_cf[Idx(c,f)]
% required by c to be executed in flavour f: if worstBounds[r] = MIN_RBOUNDS,
% then c requires at least comReq[Idx(c,f), r] units of r; otherwise, it
% requires at most comReq[Idx(c,f), r] units of r.
array[CompFlavs, Res] of MIN_RBOUNDS..MAX_RBOUNDS: comReq;
array[CompFlavs, Res] of var min(comReq)..max(comReq): comReq_lifted :: doc_comment("comReq_lifted");

% depReq[c, f, c', r] defines the amount of resource r in Req_cfc[c,f,c']
% required by the link connecting the node of the source component c to the
% node of the target component c′: if worstBounds[r] = MIN_RBOUNDS,
% then the link requires at least depReq[c, f, c', r] units of r; otherwise,
% it requires at most depReq[c, f, c', r] units of r.
array[Comps, Flavs, Comps, Res] of MIN_RBOUNDS..MAX_RBOUNDS: depReq;
array[Comps, Flavs, Comps, Res] of var min(depReq)..max(depReq): depReq_lifted :: doc_comment("depReq_lifted");

%%%%% Infrastructure, capacity and budget %%%%%

% All the nodes of the infrastructure.
enum Nodes;
% Node 0 is a dummy node added for convenience, to better handle the
% constraints below. No component can be deployed on node 0.
set of int: Nodes0 = {0} union Nodes;

% Req_n[n] is the set of resources offered by node n.
array[Nodes] of set of Res: Req_n = [
  {r | r in Res where nodeCap[n, r] != worstBounds[r]} | n in Nodes
];
array[Nodes] of var set of Res: Req_n_lifted = [
  {r | r in Res where nodeCap_lifted[n, r] != worstBounds[r]} | n in Nodes
];

% nodeCap[n,r] is maximum amount of resource r available at node n.
array[Nodes0, Res] of MIN_RBOUNDS..MAX_RBOUNDS: nodeCap;
array[Nodes0, Res] of var min(nodeCap)..max(nodeCap): nodeCap_lifted :: doc_comment("nodeCap_lifted");
% If n = 0, it must be nodeCap[n,r] = bestBounds[r].
constraint forall(r in Res)(nodeCap_lifted[0,r] = bestBounds[r]);

% linkCap[n, n', r] is the maximum amount of r that the link between n and n′
% can handle.
array[Nodes0, Nodes0, Res] of MIN_RBOUNDS..MAX_RBOUNDS: linkCap;
array[Nodes0, Nodes0, Res] of var min(linkCap)..max(linkCap): linkCap_lifted :: doc_comment("linkCap_lifted");
% If n = 0 or n' = 0, it must be linkCap[n, n', r] = bestBounds[r].
constraint forall(n in Nodes, r in Res)(
  linkCap_lifted[n,0,r] = bestBounds[r] /\ linkCap_lifted[0, n, r] = bestBounds[r]);

% cost[n,r] is the unit cost of using resource r node n.
array[Nodes0, Res] of 0..10: cost;
array[Nodes0, Res] of var min(cost)..max(cost): cost_lifted :: doc_comment("cost_lifted");
% It must be cost[0,r] = 0.
constraint forall(r in Res)(cost_lifted[0,r] = 0);
% Money budget.
1..1000000: costBudget;
var costBudget - abs(costBudget) div 10..costBudget + abs(costBudget) div 10: costBudget_lifted :: doc_comment("costBudget_lifted");

% carb[n] is the carbon emission per node n.
array[Nodes0] of 0..10: carb;
array[Nodes0] of var min(carb)..max(carb): carb_lifted :: doc_comment("carb_lifted");
% It must be carb[0] = 0.
constraint carb_lifted[0] = 0;
% Carbon budget.
1..2000000: carbBudget;
var carbBudget - abs(carbBudget) div 10..carbBudget + abs(carbBudget) div 10: carbBudget_lifted :: doc_comment("carbBudget_lifted");


%%%%%%%%%%%%%%%%%%%%%
%%%%% Variables %%%%%
%%%%%%%%%%%%%%%%%%%%%

% D[Idx(c,f),j] = 1 iff component c is deployed in flavour f on node j.
array [{0} union CompFlavs, Nodes0] of var 0..1: D;

% node[c] is the node where c is deployed, or node[c] = 0 if c not deployed.
array [Comps] of var Nodes0: node = [
  sum(i in Flav[c], j in Nodes)(j * D[Idx(c, i), j]) | c in Comps
];

% Total cost of the deployment.
var int: totCost;
constraint totCost = sum(c in Comps, i in Flav[c], r in Req_cf_lifted[Idx(c, i)])(
  comReq_lifted[Idx(c, i), r] * cost_lifted[node[c], r] * D[Idx(c, i), node[c]]
);

% Energy reuirements for each component-flavour
array[CompFlavs] of 0..1000: energy;
array[CompFlavs] of var min(energy)..max(energy): energy_lifted :: doc_comment("energy_lifted");

% Energy consumption for the dependency between components
array[Comps, Flavs, Comps] of 0..1000: energy_dependency;
array[Comps, Flavs, Comps] of var min(energy_dependency)..max(energy_dependency): energy_dependency_lifted :: doc_comment("energy_dependency_lifted");

% Total carbon emission of the deployment.
var int: totCarb;
constraint totCarb = sum(cs in Comps, is in Flav[cs], js in Nodes)(
  D[Idx(cs, is), js] * (
    energy_lifted[Idx(cs, is)] * carb_lifted[js] + sum(
      cd in Comps,
      id in Flav[cd] where mayUse[cd, Idx(cs, is)] = 1 /\ energy_dependency_lifted[cs, is, cd] > 0,
      jd in Nodes
    )(
      D[Idx(cd, id), jd] * energy_dependency_lifted[cs, is, cd] * (carb_lifted[js] + carb_lifted[jd]) div 2
    )
  )
);

%%%%%%%%%%%%%%%%%%%%%%%
%%%%% Constraints %%%%%
%%%%%%%%%%%%%%%%%%%%%%%

% Zero values for D[0,j] and D[i,0].
constraint forall(j in Nodes0)(D[0, j] = 0);
constraint forall(i in CompFlavs)(D[i, 0] = 0);

% Each component is deployed in at most one flavour, on at most one node.
constraint forall(c in Comps)(
  sum(i in Flav[c], j in Nodes)(D[Idx(c, i), j]) <= 1
);

% Components that must be deployed
constraint forall(m in mustComps)(
  sum (i in Flav[m], j in Nodes)(D[Idx(m, i), j]) > 0 /\ node[m] > 0
);

% If component c is deployed in flavour i, for each (c',i') in Uses[c,i]
% component c' must be deployed in a flavour bigger or equal than i'.
constraint forall(
  c in Comps,
  i in Flav[c],
  cu in Comps,
  iu in Flav[cu] where Uses[Idx(c, i), Idx(cu, iu)] = 1
)(
  sum(j in Nodes)(D[Idx(c, i), j]) <=
  sum(k in Flav[cu], j in Nodes where imp[cu,k] >= imp[cu,iu])(D[Idx(cu, k),j])
);

% If a "target" component c not in mustComps is deployed, at least one "source"
% component c' must be deployed in a flavour f requiring c.
constraint forall(c in Comps diff mustComps)(
  sum(i in Flav[c], j in Nodes)(D[Idx(c, i), j]) <=
  sum(
    cs in Comps where c != cs,
    is in Flav[cs] where mayUse[c, Idx(cs, is)] = 1,
    j in Nodes
  )(D[Idx(cs, is), j])
);

% Each node j has a sufficient quantity of a certain resource r to meet the
% demands of all the components deployed on it.
constraint forall(j in Nodes, r in Req_n_lifted[j] where r in C(CRes)) (
  if worstBounds[r] = MIN_RBOUNDS then
    sum(c in Comps, i in Flav[c] where r in Req_cf_lifted[Idx(c,i)])
      (comReq_lifted[Idx(c,i), r] * D[Idx(c,i), j]) <= nodeCap_lifted[j,r]
  else
    assert(false, "·Lower bound for 'maximization' resources unsupported.")
  endif
);

% If component c deployed in flavour i requires a certain amount of resource r,
% then node c must have capacity for r
constraint forall(
  c in Comps,
  i in Flav[c],
  r in Req_cf_lifted[Idx(c,i)] where r in N(NRes)
)(
  if worstBounds[r] = MIN_RBOUNDS then
    comReq_lifted[Idx(c,i), r] * D[Idx(c,i), node[c]] <= nodeCap_lifted[node[c], r]
  else
    comReq_lifted[Idx(c,i), r] >= nodeCap_lifted[node[c], r] * D[Idx(c,i), node[c]]
  endif
);

% Dependency from c to c' must be fulfilled only if there is an active
% dependency between c and c'.
% FIXME: so far, only defined on non-consumable resources.
constraint forall(
  cs in Comps,
  is in Flav[cs],
  cd in Comps where mayUse[cd, Idx(cs, is)] = 1,
  r in Req_cfc_lifted[cs, is, cd] where r in N(NRes),
)(
  if worstBounds[r] = MIN_RBOUNDS then
    depReq_lifted[cs, is, cd, r] * sum(j in Nodes)(D[Idx(cs, is), j]) <=
    linkCap_lifted[node[cs], node[cd], r]
  else
    depReq_lifted[cs, is, cd, r] >= sum(j in Nodes)(D[Idx(cs, is), j]) *
    linkCap_lifted[node[cs], node[cd], r]
  endif
);


% Budget requirements.
constraint totCost <= costBudget_lifted;
constraint totCarb <= carbBudget_lifted;


%%%%%%%%%%%%%%%%%%%%%
%%%%% Objective %%%%%
%%%%%%%%%%%%%%%%%%%%%

var int: obj = sum(c in Comps, i in Flav[c])(
  imp[c,i] * sum([D[Idx(c,i),j] | j in Nodes])
);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%% Output formatting %%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

output ["original Req_cf = \(Req_cf)\nlifted   Req_cf = \(Req_cf_lifted)\n\n"] ++ ["original Req_cfc = \(Req_cfc)\nlifted   Req_cfc = \(Req_cfc_lifted)\n\n"] ++ ["original Req_n = \(Req_n)\nlifted   Req_n = \(Req_n_lifted)\n\n"] ++ ["original carb = \(carb)\nlifted   carb = \(carb_lifted)\n\n"] ++ ["original carbBudget = \(carbBudget)\nlifted   carbBudget = \(carbBudget_lifted)\n\n"] ++ ["original comReq = \(comReq)\nlifted   comReq = \(comReq_lifted)\n\n"] ++ ["original cost = \(cost)\nlifted   cost = \(cost_lifted)\n\n"] ++ ["original costBudget = \(costBudget)\nlifted   costBudget = \(costBudget_lifted)\n\n"] ++ ["original depReq = \(depReq)\nlifted   depReq = \(depReq_lifted)\n\n"] ++ ["original energy = \(energy)\nlifted   energy = \(energy_lifted)\n\n"] ++ ["original energy_dependency = \(energy_dependency)\nlifted   energy_dependency = \(energy_dependency_lifted)\n\n"] ++ ["original linkCap = \(linkCap)\nlifted   linkCap = \(linkCap_lifted)\n\n"] ++ ["original nodeCap = \(nodeCap)\nlifted   nodeCap = \(nodeCap_lifted)\n\n"] ++ [
  if fix(node[c]) > 0 then
    "Component \(c) deployed in flavour \([Flavs[i] | i in Flav[c] where D[Idx(c, i), node[c]] > 0][1]) on node \(Nodes[node[c]]).\n"
  else
    "Component \(c) not deployed.\n"
  endif
  | c in Comps
] ++ [
  "Objective value: \(obj)\n\tTotal cost: \(totCost)\n\tTotal carb: \(totCarb)"
];
% ++ [
%     "\n\(r) : \(cs)_\(is) -> \(cd) on \(node[cs]) -> \(node[cd]) -- \(depReq[cs, is, cd, r] * sum(j in Nodes)(D[Idx(cs, is), j])) >= \(linkCap[node[cs], node[cd], r])"
%   | cs in Comps,
%     is in Flav[cs] ,%where fix(D[Idx(cs, is), node[cs]]) > 0,
%     cd in Comps ,%where exists(id in Flav[cd])(Uses[Idx(cs, is), Idx(cd, id)] = 1 /\ fix(D[Idx(cd, id), node[cd]]) > 0),
%     r in Req_cfc[cs, is, cd] where r in N(NRes) /\ worstBounds[r] != MIN_RBOUNDS
% ]

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Input data for app in infrastructure %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Comps = {component_0, component_2, component_3, component_1, component_4};
mustComps = {component_0, component_1};
Flavs = {flavour_0, flavour_1};
Flav = [{flavour_0, flavour_1}, {flavour_0}, {flavour_0, flavour_1}, {flavour_0}, {flavour_0}];
imp = array2d(Comps, Flavs, [
	%flavour_0, flavour_1
	1, 2, % component_0
	1, 0, % component_2
	1, 2, % component_3
	1, 0, % component_1
	1, 0, % component_4
]);
energy = [906, 422, 886, 801, 993, 446, 445];
energy_dependency = array3d(Comps, Flavs, Comps, [

	% component_0
	%component_0, component_2, component_3, component_1, component_4
	0, 0, 0, 0, 0, % flavour_0
	0, 0, 0, 30, 0, % flavour_1

	% component_2
	%component_0, component_2, component_3, component_1, component_4
	0, 0, 0, 48, 0, % flavour_0
	0, 0, 0, 0, 0, % flavour_1

	% component_3
	%component_0, component_2, component_3, component_1, component_4
	0, 0, 0, 0, 0, % flavour_0
	0, 0, 0, 0, 42, % flavour_1

	% component_1
	%component_0, component_2, component_3, component_1, component_4
	0, 0, 15, 0, 0, % flavour_0
	0, 0, 0, 0, 0, % flavour_1

	% component_4
	%component_0, component_2, component_3, component_1, component_4
	0, 0, 0, 0, 0, % flavour_0
	0, 0, 0, 0, 0, % flavour_1

]);
Uses = array2d(CompFlavs, CompFlavs, [
	%component_0_flavour_0, component_0_flavour_1, component_2_flavour_0, component_3_flavour_0, component_3_flavour_1, component_1_flavour_0, component_4_flavour_0
	0, 0, 0, 1, 0, 1, 0, % component_0_flavour_0
	0, 0, 1, 0, 1, 1, 0, % component_0_flavour_1
	0, 0, 0, 1, 0, 1, 0, % component_2_flavour_0
	0, 0, 0, 0, 0, 0, 0, % component_3_flavour_0
	0, 0, 0, 0, 0, 0, 1, % component_3_flavour_1
	0, 0, 0, 1, 0, 0, 0, % component_1_flavour_0
	0, 0, 0, 0, 0, 0, 0, % component_4_flavour_0
]);
mayUse = array2d(Comps, CompFlavs, [
	%component_0_flavour_0, component_0_flavour_1, component_2_flavour_0, component_3_flavour_0, component_3_flavour_1, component_1_flavour_0, component_4_flavour_0
	0, 0, 0, 0, 0, 0, 0, % component_0
	0, 1, 0, 0, 0, 0, 0, % component_2
	1, 1, 1, 0, 0, 1, 0, % component_3
	1, 1, 1, 0, 0, 0, 0, % component_1
	0, 0, 0, 0, 1, 0, 0, % component_4
]);
CRes = {res_conumable, resource_2};
NRes = {res_non_conumable, resource_0_resource_0_0, resource_0_resource_0_1, resource_0_resource_0_2, resource_1_resource_1_0, resource_1_resource_1_1, resource_1_resource_1_2, resource_1_resource_1_3, resource_1_resource_1_4, resource_1_resource_1_5, resource_1_resource_1_6, resource_1_resource_1_7, resource_1_resource_1_8, resource_1_resource_1_9, resource_3, resource_4, resource_5_resource_5_0, resource_5_resource_5_1, resource_5_resource_5_2, resource_6, resource_7_resource_7_0, resource_7_resource_7_1, resource_7_resource_7_2, resource_7_resource_7_3, resource_7_resource_7_4, resource_7_resource_7_5, resource_7_resource_7_6, resource_7_resource_7_7, resource_7_resource_7_8};
MAX_RBOUNDS = 978;
MIN_RBOUNDS = 0;
worstBounds = [
	MIN_RBOUNDS, % res_conumable
	MIN_RBOUNDS, % resource_2
	MIN_RBOUNDS, % res_non_conumable
	MIN_RBOUNDS, % resource_0_resource_0_0
	MIN_RBOUNDS, % resource_0_resource_0_1
	MIN_RBOUNDS, % resource_0_resource_0_2
	MIN_RBOUNDS, % resource_1_resource_1_0
	MIN_RBOUNDS, % resource_1_resource_1_1
	MIN_RBOUNDS, % resource_1_resource_1_2
	MIN_RBOUNDS, % resource_1_resource_1_3
	MIN_RBOUNDS, % resource_1_resource_1_4
	MIN_RBOUNDS, % resource_1_resource_1_5
	MIN_RBOUNDS, % resource_1_resource_1_6
	MIN_RBOUNDS, % resource_1_resource_1_7
	MIN_RBOUNDS, % resource_1_resource_1_8
	MIN_RBOUNDS, % resource_1_resource_1_9
	MIN_RBOUNDS, % resource_3
	MIN_RBOUNDS, % resource_4
	MIN_RBOUNDS, % resource_5_resource_5_0
	MIN_RBOUNDS, % resource_5_resource_5_1
	MIN_RBOUNDS, % resource_5_resource_5_2
	MIN_RBOUNDS, % resource_6
	MIN_RBOUNDS, % resource_7_resource_7_0
	MIN_RBOUNDS, % resource_7_resource_7_1
	MIN_RBOUNDS, % resource_7_resource_7_2
	MIN_RBOUNDS, % resource_7_resource_7_3
	MIN_RBOUNDS, % resource_7_resource_7_4
	MIN_RBOUNDS, % resource_7_resource_7_5
	MIN_RBOUNDS, % resource_7_resource_7_6
	MIN_RBOUNDS, % resource_7_resource_7_7
	MIN_RBOUNDS, % resource_7_resource_7_8
];
bestBounds = [
	MAX_RBOUNDS, % res_conumable
	MAX_RBOUNDS, % resource_2
	MAX_RBOUNDS, % res_non_conumable
	MAX_RBOUNDS, % resource_0_resource_0_0
	MAX_RBOUNDS, % resource_0_resource_0_1
	MAX_RBOUNDS, % resource_0_resource_0_2
	MAX_RBOUNDS, % resource_1_resource_1_0
	MAX_RBOUNDS, % resource_1_resource_1_1
	MAX_RBOUNDS, % resource_1_resource_1_2
	MAX_RBOUNDS, % resource_1_resource_1_3
	MAX_RBOUNDS, % resource_1_resource_1_4
	MAX_RBOUNDS, % resource_1_resource_1_5
	MAX_RBOUNDS, % resource_1_resource_1_6
	MAX_RBOUNDS, % resource_1_resource_1_7
	MAX_RBOUNDS, % resource_1_resource_1_8
	MAX_RBOUNDS, % resource_1_resource_1_9
	MAX_RBOUNDS, % resource_3
	MAX_RBOUNDS, % resource_4
	MAX_RBOUNDS, % resource_5_resource_5_0
	MAX_RBOUNDS, % resource_5_resource_5_1
	MAX_RBOUNDS, % resource_5_resource_5_2
	MAX_RBOUNDS, % resource_6
	MAX_RBOUNDS, % resource_7_resource_7_0
	MAX_RBOUNDS, % resource_7_resource_7_1
	MAX_RBOUNDS, % resource_7_resource_7_2
	MAX_RBOUNDS, % resource_7_resource_7_3
	MAX_RBOUNDS, % resource_7_resource_7_4
	MAX_RBOUNDS, % resource_7_resource_7_5
	MAX_RBOUNDS, % resource_7_resource_7_6
	MAX_RBOUNDS, % resource_7_resource_7_7
	MAX_RBOUNDS, % resource_7_resource_7_8
];

comReq = array2d(CompFlavs, Res, [
	%res_conumable, resource_2, res_non_conumable, resource_0_resource_0_0, resource_0_resource_0_1, resource_0_resource_0_2, resource_1_resource_1_0, resource_1_resource_1_1, resource_1_resource_1_2, resource_1_resource_1_3, resource_1_resource_1_4, resource_1_resource_1_5, resource_1_resource_1_6, resource_1_resource_1_7, resource_1_resource_1_8, resource_1_resource_1_9, resource_3, resource_4, resource_5_resource_5_0, resource_5_resource_5_1, resource_5_resource_5_2, resource_6, resource_7_resource_7_0, resource_7_resource_7_1, resource_7_resource_7_2, resource_7_resource_7_3, resource_7_resource_7_4, resource_7_resource_7_5, resource_7_resource_7_6, resource_7_resource_7_7, resource_7_resource_7_8
	96, 53, 64, 1, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 1, MIN_RBOUNDS, MIN_RBOUNDS, 1, 1, 1, 1, 1, 135, 57, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 156, 1, 1, MIN_RBOUNDS, 1, 1, 1, MIN_RBOUNDS, 1, MIN_RBOUNDS, % component_0_flavour_0
	96, 53, 24, 1, MIN_RBOUNDS, MIN_RBOUNDS, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 135, 14, 1, 1, 1, 55, 1, 1, MIN_RBOUNDS, 1, 1, 1, MIN_RBOUNDS, 1, MIN_RBOUNDS, % component_0_flavour_1
	119, 162, 92, MIN_RBOUNDS, 1, MIN_RBOUNDS, 1, 1, 1, 1, MIN_RBOUNDS, 1, 1, 1, 1, 1, 105, 115, MIN_RBOUNDS, 1, MIN_RBOUNDS, 46, 1, 1, 1, 1, 1, 1, 1, 1, 1, % component_2_flavour_0
	117, 75, 82, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 1, 1, MIN_RBOUNDS, MIN_RBOUNDS, 1, 1, 1, MIN_RBOUNDS, MIN_RBOUNDS, 132, 9, 1, MIN_RBOUNDS, MIN_RBOUNDS, 34, 1, 1, 1, 1, 1, 1, 1, 1, 1, % component_3_flavour_0
	63, 63, 4, 1, MIN_RBOUNDS, MIN_RBOUNDS, 1, MIN_RBOUNDS, MIN_RBOUNDS, 1, MIN_RBOUNDS, 1, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 1, 70, 9, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 17, 1, 1, 1, 1, 1, 1, 1, 1, 1, % component_3_flavour_1
	68, 93, 102, 1, 1, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 1, 1, 1, 1, 1, MIN_RBOUNDS, 1, MIN_RBOUNDS, 90, 150, 1, 1, 1, 42, 1, 1, 1, 1, 1, 1, 1, 1, 1, % component_1_flavour_0
	141, 73, 115, MIN_RBOUNDS, 1, MIN_RBOUNDS, 1, MIN_RBOUNDS, 1, MIN_RBOUNDS, 1, MIN_RBOUNDS, MIN_RBOUNDS, 1, MIN_RBOUNDS, 1, 19, 125, 1, 1, 1, 143, 1, 1, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 1, MIN_RBOUNDS, % component_4_flavour_0
]);
Nodes = {node_0, node_1, node_2, node_3, node_4, node_5, node_6};

nodeCap = array2d(Nodes0, Res,
	[bestBounds[r] | r in Res] ++ [ % No node
	%res_conumable, resource_2, res_non_conumable, resource_0_resource_0_0, resource_0_resource_0_1, resource_0_resource_0_2, resource_1_resource_1_0, resource_1_resource_1_1, resource_1_resource_1_2, resource_1_resource_1_3, resource_1_resource_1_4, resource_1_resource_1_5, resource_1_resource_1_6, resource_1_resource_1_7, resource_1_resource_1_8, resource_1_resource_1_9, resource_3, resource_4, resource_5_resource_5_0, resource_5_resource_5_1, resource_5_resource_5_2, resource_6, resource_7_resource_7_0, resource_7_resource_7_1, resource_7_resource_7_2, resource_7_resource_7_3, resource_7_resource_7_4, resource_7_resource_7_5, resource_7_resource_7_6, resource_7_resource_7_7, resource_7_resource_7_8
	209, 156, 172, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 737, 629, 1, 1, 1, 20, 1, 1, 1, 1, 1, 1, 1, 1, 1, % node_0
	513, 950, 813, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 425, 322, 1, 1, 1, 626, 1, 1, 1, 1, 1, 1, 1, 1, 1, % node_1
	211, 493, 113, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 473, 893, 1, 1, 1, 191, 1, 1, 1, 1, 1, 1, 1, 1, 1, % node_2
	569, 801, 566, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 814, 142, 1, 1, 1, 971, 1, 1, 1, 1, 1, 1, 1, 1, 1, % node_3
	667, 372, 91, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 352, 232, 1, 1, 1, 300, 1, 1, 1, 1, 1, 1, 1, 1, 1, % node_4
	272, 440, 557, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 583, 423, 1, 1, 1, 787, 1, 1, 1, 1, 1, 1, 1, 1, 1, % node_5
	804, 744, 644, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 317, 954, 1, 1, 1, 923, 1, 1, 1, 1, 1, 1, 1, 1, 1, % node_6
]);
depReq = array4d(Comps, Flavs, Comps, Res, [

	% component_0

	% flavour_0
	%res_conumable, resource_2, res_non_conumable, resource_0_resource_0_0, resource_0_resource_0_1, resource_0_resource_0_2, resource_1_resource_1_0, resource_1_resource_1_1, resource_1_resource_1_2, resource_1_resource_1_3, resource_1_resource_1_4, resource_1_resource_1_5, resource_1_resource_1_6, resource_1_resource_1_7, resource_1_resource_1_8, resource_1_resource_1_9, resource_3, resource_4, resource_5_resource_5_0, resource_5_resource_5_1, resource_5_resource_5_2, resource_6, resource_7_resource_7_0, resource_7_resource_7_1, resource_7_resource_7_2, resource_7_resource_7_3, resource_7_resource_7_4, resource_7_resource_7_5, resource_7_resource_7_6, resource_7_resource_7_7, resource_7_resource_7_8
	MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % component_0
	MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % component_2
	MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % component_3
	MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % component_1
	MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % component_4

	% flavour_1
	%res_conumable, resource_2, res_non_conumable, resource_0_resource_0_0, resource_0_resource_0_1, resource_0_resource_0_2, resource_1_resource_1_0, resource_1_resource_1_1, resource_1_resource_1_2, resource_1_resource_1_3, resource_1_resource_1_4, resource_1_resource_1_5, resource_1_resource_1_6, resource_1_resource_1_7, resource_1_resource_1_8, resource_1_resource_1_9, resource_3, resource_4, resource_5_resource_5_0, resource_5_resource_5_1, resource_5_resource_5_2, resource_6, resource_7_resource_7_0, resource_7_resource_7_1, resource_7_resource_7_2, resource_7_resource_7_3, resource_7_resource_7_4, resource_7_resource_7_5, resource_7_resource_7_6, resource_7_resource_7_7, resource_7_resource_7_8
	MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % component_0
	MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % component_2
	MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % component_3
	MIN_RBOUNDS, MIN_RBOUNDS, 86, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 56, 20, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % component_1
	MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % component_4


	% component_2

	% flavour_0
	%res_conumable, resource_2, res_non_conumable, resource_0_resource_0_0, resource_0_resource_0_1, resource_0_resource_0_2, resource_1_resource_1_0, resource_1_resource_1_1, resource_1_resource_1_2, resource_1_resource_1_3, resource_1_resource_1_4, resource_1_resource_1_5, resource_1_resource_1_6, resource_1_resource_1_7, resource_1_resource_1_8, resource_1_resource_1_9, resource_3, resource_4, resource_5_resource_5_0, resource_5_resource_5_1, resource_5_resource_5_2, resource_6, resource_7_resource_7_0, resource_7_resource_7_1, resource_7_resource_7_2, resource_7_resource_7_3, resource_7_resource_7_4, resource_7_resource_7_5, resource_7_resource_7_6, resource_7_resource_7_7, resource_7_resource_7_8
	MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % component_0
	MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % component_2
	MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % component_3
	MIN_RBOUNDS, MIN_RBOUNDS, 83, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 103, 109, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % component_1
	MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % component_4

	% flavour_1
	%res_conumable, resource_2, res_non_conumable, resource_0_resource_0_0, resource_0_resource_0_1, resource_0_resource_0_2, resource_1_resource_1_0, resource_1_resource_1_1, resource_1_resource_1_2, resource_1_resource_1_3, resource_1_resource_1_4, resource_1_resource_1_5, resource_1_resource_1_6, resource_1_resource_1_7, resource_1_resource_1_8, resource_1_resource_1_9, resource_3, resource_4, resource_5_resource_5_0, resource_5_resource_5_1, resource_5_resource_5_2, resource_6, resource_7_resource_7_0, resource_7_resource_7_1, resource_7_resource_7_2, resource_7_resource_7_3, resource_7_resource_7_4, resource_7_resource_7_5, resource_7_resource_7_6, resource_7_resource_7_7, resource_7_resource_7_8
	MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % component_0
	MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % component_2
	MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % component_3
	MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % component_1
	MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % component_4


	% component_3

	% flavour_0
	%res_conumable, resource_2, res_non_conumable, resource_0_resource_0_0, resource_0_resource_0_1, resource_0_resource_0_2, resource_1_resource_1_0, resource_1_resource_1_1, resource_1_resource_1_2, resource_1_resource_1_3, resource_1_resource_1_4, resource_1_resource_1_5, resource_1_resource_1_6, resource_1_resource_1_7, resource_1_resource_1_8, resource_1_resource_1_9, resource_3, resource_4, resource_5_resource_5_0, resource_5_resource_5_1, resource_5_resource_5_2, resource_6, resource_7_resource_7_0, resource_7_resource_7_1, resource_7_resource_7_2, resource_7_resource_7_3, resource_7_resource_7_4, resource_7_resource_7_5, resource_7_resource_7_6, resource_7_resource_7_7, resource_7_resource_7_8
	MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % component_0
	MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % component_2
	MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % component_3
	MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % component_1
	MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % component_4

	% flavour_1
	%res_conumable, resource_2, res_non_conumable, resource_0_resource_0_0, resource_0_resource_0_1, resource_0_resource_0_2, resource_1_resource_1_0, resource_1_resource_1_1, resource_1_resource_1_2, resource_1_resource_1_3, resource_1_resource_1_4, resource_1_resource_1_5, resource_1_resource_1_6, resource_1_resource_1_7, resource_1_resource_1_8, resource_1_resource_1_9, resource_3, resource_4, resource_5_resource_5_0, resource_5_resource_5_1, resource_5_resource_5_2, resource_6, resource_7_resource_7_0, resource_7_resource_7_1, resource_7_resource_7_2, resource_7_resource_7_3, resource_7_resource_7_4, resource_7_resource_7_5, resource_7_resource_7_6, resource_7_resource_7_7, resource_7_resource_7_8
	MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % component_0
	MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % component_2
	MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % component_3
	MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % component_1
	MIN_RBOUNDS, MIN_RBOUNDS, 35, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 61, 27, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % component_4


	% component_1

	% flavour_0
	%res_conumable, resource_2, res_non_conumable, resource_0_resource_0_0, resource_0_resource_0_1, resource_0_resource_0_2, resource_1_resource_1_0, resource_1_resource_1_1, resource_1_resource_1_2, resource_1_resource_1_3, resource_1_resource_1_4, resource_1_resource_1_5, resource_1_resource_1_6, resource_1_resource_1_7, resource_1_resource_1_8, resource_1_resource_1_9, resource_3, resource_4, resource_5_resource_5_0, resource_5_resource_5_1, resource_5_resource_5_2, resource_6, resource_7_resource_7_0, resource_7_resource_7_1, resource_7_resource_7_2, resource_7_resource_7_3, resource_7_resource_7_4, resource_7_resource_7_5, resource_7_resource_7_6, resource_7_resource_7_7, resource_7_resource_7_8
	MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % component_0
	MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % component_2
	MIN_RBOUNDS, MIN_RBOUNDS, 1, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 152, 16, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % component_3
	MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % component_1
	MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % component_4

	% flavour_1
	%res_conumable, resource_2, res_non_conumable, resource_0_resource_0_0, resource_0_resource_0_1, resource_0_resource_0_2, resource_1_resource_1_0, resource_1_resource_1_1, resource_1_resource_1_2, resource_1_resource_1_3, resource_1_resource_1_4, resource_1_resource_1_5, resource_1_resource_1_6, resource_1_resource_1_7, resource_1_resource_1_8, resource_1_resource_1_9, resource_3, resource_4, resource_5_resource_5_0, resource_5_resource_5_1, resource_5_resource_5_2, resource_6, resource_7_resource_7_0, resource_7_resource_7_1, resource_7_resource_7_2, resource_7_resource_7_3, resource_7_resource_7_4, resource_7_resource_7_5, resource_7_resource_7_6, resource_7_resource_7_7, resource_7_resource_7_8
	MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % component_0
	MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % component_2
	MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % component_3
	MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % component_1
	MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % component_4


	% component_4

	% flavour_0
	%res_conumable, resource_2, res_non_conumable, resource_0_resource_0_0, resource_0_resource_0_1, resource_0_resource_0_2, resource_1_resource_1_0, resource_1_resource_1_1, resource_1_resource_1_2, resource_1_resource_1_3, resource_1_resource_1_4, resource_1_resource_1_5, resource_1_resource_1_6, resource_1_resource_1_7, resource_1_resource_1_8, resource_1_resource_1_9, resource_3, resource_4, resource_5_resource_5_0, resource_5_resource_5_1, resource_5_resource_5_2, resource_6, resource_7_resource_7_0, resource_7_resource_7_1, resource_7_resource_7_2, resource_7_resource_7_3, resource_7_resource_7_4, resource_7_resource_7_5, resource_7_resource_7_6, resource_7_resource_7_7, resource_7_resource_7_8
	MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % component_0
	MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % component_2
	MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % component_3
	MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % component_1
	MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % component_4

	% flavour_1
	%res_conumable, resource_2, res_non_conumable, resource_0_resource_0_0, resource_0_resource_0_1, resource_0_resource_0_2, resource_1_resource_1_0, resource_1_resource_1_1, resource_1_resource_1_2, resource_1_resource_1_3, resource_1_resource_1_4, resource_1_resource_1_5, resource_1_resource_1_6, resource_1_resource_1_7, resource_1_resource_1_8, resource_1_resource_1_9, resource_3, resource_4, resource_5_resource_5_0, resource_5_resource_5_1, resource_5_resource_5_2, resource_6, resource_7_resource_7_0, resource_7_resource_7_1, resource_7_resource_7_2, resource_7_resource_7_3, resource_7_resource_7_4, resource_7_resource_7_5, resource_7_resource_7_6, resource_7_resource_7_7, resource_7_resource_7_8
	MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % component_0
	MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % component_2
	MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % component_3
	MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % component_1
	MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % component_4


]);
linkCap = array3d(Nodes0, Nodes0, Res, [

	% 0
	%res_conumable, resource_2, res_non_conumable, resource_0_resource_0_0, resource_0_resource_0_1, resource_0_resource_0_2, resource_1_resource_1_0, resource_1_resource_1_1, resource_1_resource_1_2, resource_1_resource_1_3, resource_1_resource_1_4, resource_1_resource_1_5, resource_1_resource_1_6, resource_1_resource_1_7, resource_1_resource_1_8, resource_1_resource_1_9, resource_3, resource_4, resource_5_resource_5_0, resource_5_resource_5_1, resource_5_resource_5_2, resource_6, resource_7_resource_7_0, resource_7_resource_7_1, resource_7_resource_7_2, resource_7_resource_7_3, resource_7_resource_7_4, resource_7_resource_7_5, resource_7_resource_7_6, resource_7_resource_7_7, resource_7_resource_7_8
	MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, % 0
	MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, % node_0
	MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, % node_1
	MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, % node_2
	MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, % node_3
	MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, % node_4
	MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, % node_5
	MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, % node_6

	% node_0
	%res_conumable, resource_2, res_non_conumable, resource_0_resource_0_0, resource_0_resource_0_1, resource_0_resource_0_2, resource_1_resource_1_0, resource_1_resource_1_1, resource_1_resource_1_2, resource_1_resource_1_3, resource_1_resource_1_4, resource_1_resource_1_5, resource_1_resource_1_6, resource_1_resource_1_7, resource_1_resource_1_8, resource_1_resource_1_9, resource_3, resource_4, resource_5_resource_5_0, resource_5_resource_5_1, resource_5_resource_5_2, resource_6, resource_7_resource_7_0, resource_7_resource_7_1, resource_7_resource_7_2, resource_7_resource_7_3, resource_7_resource_7_4, resource_7_resource_7_5, resource_7_resource_7_6, resource_7_resource_7_7, resource_7_resource_7_8
	MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, % 0
	209, 156, 172, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 737, 629, 1, 1, 1, 20, 1, 1, 1, 1, 1, 1, 1, 1, 1, % node_0
	MIN_RBOUNDS, MIN_RBOUNDS, 770, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 467, 333, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 977, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % node_1
	MIN_RBOUNDS, MIN_RBOUNDS, 219, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 585, 743, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 384, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % node_2
	MIN_RBOUNDS, MIN_RBOUNDS, 231, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 372, 494, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 77, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % node_3
	MIN_RBOUNDS, MIN_RBOUNDS, 417, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 131, 754, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 609, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % node_4
	MIN_RBOUNDS, MIN_RBOUNDS, 501, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 844, 140, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 362, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % node_5
	MIN_RBOUNDS, MIN_RBOUNDS, 677, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 510, 627, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 958, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % node_6

	% node_1
	%res_conumable, resource_2, res_non_conumable, resource_0_resource_0_0, resource_0_resource_0_1, resource_0_resource_0_2, resource_1_resource_1_0, resource_1_resource_1_1, resource_1_resource_1_2, resource_1_resource_1_3, resource_1_resource_1_4, resource_1_resource_1_5, resource_1_resource_1_6, resource_1_resource_1_7, resource_1_resource_1_8, resource_1_resource_1_9, resource_3, resource_4, resource_5_resource_5_0, resource_5_resource_5_1, resource_5_resource_5_2, resource_6, resource_7_resource_7_0, resource_7_resource_7_1, resource_7_resource_7_2, resource_7_resource_7_3, resource_7_resource_7_4, resource_7_resource_7_5, resource_7_resource_7_6, resource_7_resource_7_7, resource_7_resource_7_8
	MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, % 0
	MIN_RBOUNDS, MIN_RBOUNDS, 770, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 467, 333, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 977, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % node_0
	513, 950, 813, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 425, 322, 1, 1, 1, 626, 1, 1, 1, 1, 1, 1, 1, 1, 1, % node_1
	MIN_RBOUNDS, MIN_RBOUNDS, 212, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 325, 784, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 870, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % node_2
	MIN_RBOUNDS, MIN_RBOUNDS, 716, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 631, 755, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 888, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % node_3
	MIN_RBOUNDS, MIN_RBOUNDS, 777, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 35, 530, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 555, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % node_4
	MIN_RBOUNDS, MIN_RBOUNDS, 378, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 825, 85, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 246, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % node_5
	MIN_RBOUNDS, MIN_RBOUNDS, 309, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 490, 266, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 336, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % node_6

	% node_2
	%res_conumable, resource_2, res_non_conumable, resource_0_resource_0_0, resource_0_resource_0_1, resource_0_resource_0_2, resource_1_resource_1_0, resource_1_resource_1_1, resource_1_resource_1_2, resource_1_resource_1_3, resource_1_resource_1_4, resource_1_resource_1_5, resource_1_resource_1_6, resource_1_resource_1_7, resource_1_resource_1_8, resource_1_resource_1_9, resource_3, resource_4, resource_5_resource_5_0, resource_5_resource_5_1, resource_5_resource_5_2, resource_6, resource_7_resource_7_0, resource_7_resource_7_1, resource_7_resource_7_2, resource_7_resource_7_3, resource_7_resource_7_4, resource_7_resource_7_5, resource_7_resource_7_6, resource_7_resource_7_7, resource_7_resource_7_8
	MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, % 0
	MIN_RBOUNDS, MIN_RBOUNDS, 219, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 585, 743, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 384, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % node_0
	MIN_RBOUNDS, MIN_RBOUNDS, 212, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 325, 784, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 870, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % node_1
	211, 493, 113, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 473, 893, 1, 1, 1, 191, 1, 1, 1, 1, 1, 1, 1, 1, 1, % node_2
	MIN_RBOUNDS, MIN_RBOUNDS, 233, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 152, 912, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 151, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % node_3
	MIN_RBOUNDS, MIN_RBOUNDS, 52, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 309, 73, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 900, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % node_4
	MIN_RBOUNDS, MIN_RBOUNDS, 170, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 677, 85, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 454, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % node_5
	MIN_RBOUNDS, MIN_RBOUNDS, 442, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 357, 669, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 437, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % node_6

	% node_3
	%res_conumable, resource_2, res_non_conumable, resource_0_resource_0_0, resource_0_resource_0_1, resource_0_resource_0_2, resource_1_resource_1_0, resource_1_resource_1_1, resource_1_resource_1_2, resource_1_resource_1_3, resource_1_resource_1_4, resource_1_resource_1_5, resource_1_resource_1_6, resource_1_resource_1_7, resource_1_resource_1_8, resource_1_resource_1_9, resource_3, resource_4, resource_5_resource_5_0, resource_5_resource_5_1, resource_5_resource_5_2, resource_6, resource_7_resource_7_0, resource_7_resource_7_1, resource_7_resource_7_2, resource_7_resource_7_3, resource_7_resource_7_4, resource_7_resource_7_5, resource_7_resource_7_6, resource_7_resource_7_7, resource_7_resource_7_8
	MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, % 0
	MIN_RBOUNDS, MIN_RBOUNDS, 231, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 372, 494, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 77, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % node_0
	MIN_RBOUNDS, MIN_RBOUNDS, 716, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 631, 755, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 888, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % node_1
	MIN_RBOUNDS, MIN_RBOUNDS, 233, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 152, 912, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 151, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % node_2
	569, 801, 566, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 814, 142, 1, 1, 1, 971, 1, 1, 1, 1, 1, 1, 1, 1, 1, % node_3
	MIN_RBOUNDS, MIN_RBOUNDS, 387, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 19, 212, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 99, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % node_4
	MIN_RBOUNDS, MIN_RBOUNDS, 610, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 97, 552, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 495, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % node_5
	MIN_RBOUNDS, MIN_RBOUNDS, 474, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 292, 513, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 640, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % node_6

	% node_4
	%res_conumable, resource_2, res_non_conumable, resource_0_resource_0_0, resource_0_resource_0_1, resource_0_resource_0_2, resource_1_resource_1_0, resource_1_resource_1_1, resource_1_resource_1_2, resource_1_resource_1_3, resource_1_resource_1_4, resource_1_resource_1_5, resource_1_resource_1_6, resource_1_resource_1_7, resource_1_resource_1_8, resource_1_resource_1_9, resource_3, resource_4, resource_5_resource_5_0, resource_5_resource_5_1, resource_5_resource_5_2, resource_6, resource_7_resource_7_0, resource_7_resource_7_1, resource_7_resource_7_2, resource_7_resource_7_3, resource_7_resource_7_4, resource_7_resource_7_5, resource_7_resource_7_6, resource_7_resource_7_7, resource_7_resource_7_8
	MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, % 0
	MIN_RBOUNDS, MIN_RBOUNDS, 417, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 131, 754, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 609, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % node_0
	MIN_RBOUNDS, MIN_RBOUNDS, 777, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 35, 530, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 555, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % node_1
	MIN_RBOUNDS, MIN_RBOUNDS, 52, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 309, 73, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 900, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % node_2
	MIN_RBOUNDS, MIN_RBOUNDS, 387, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 19, 212, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 99, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % node_3
	667, 372, 91, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 352, 232, 1, 1, 1, 300, 1, 1, 1, 1, 1, 1, 1, 1, 1, % node_4
	MIN_RBOUNDS, MIN_RBOUNDS, 34, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 791, 284, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 379, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % node_5
	MIN_RBOUNDS, MIN_RBOUNDS, 594, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 111, 184, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 174, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % node_6

	% node_5
	%res_conumable, resource_2, res_non_conumable, resource_0_resource_0_0, resource_0_resource_0_1, resource_0_resource_0_2, resource_1_resource_1_0, resource_1_resource_1_1, resource_1_resource_1_2, resource_1_resource_1_3, resource_1_resource_1_4, resource_1_resource_1_5, resource_1_resource_1_6, resource_1_resource_1_7, resource_1_resource_1_8, resource_1_resource_1_9, resource_3, resource_4, resource_5_resource_5_0, resource_5_resource_5_1, resource_5_resource_5_2, resource_6, resource_7_resource_7_0, resource_7_resource_7_1, resource_7_resource_7_2, resource_7_resource_7_3, resource_7_resource_7_4, resource_7_resource_7_5, resource_7_resource_7_6, resource_7_resource_7_7, resource_7_resource_7_8
	MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, % 0
	MIN_RBOUNDS, MIN_RBOUNDS, 501, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 844, 140, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 362, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % node_0
	MIN_RBOUNDS, MIN_RBOUNDS, 378, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 825, 85, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 246, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % node_1
	MIN_RBOUNDS, MIN_RBOUNDS, 170, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 677, 85, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 454, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % node_2
	MIN_RBOUNDS, MIN_RBOUNDS, 610, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 97, 552, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 495, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % node_3
	MIN_RBOUNDS, MIN_RBOUNDS, 34, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 791, 284, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 379, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % node_4
	272, 440, 557, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 583, 423, 1, 1, 1, 787, 1, 1, 1, 1, 1, 1, 1, 1, 1, % node_5
	MIN_RBOUNDS, MIN_RBOUNDS, 265, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 11, 936, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 651, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % node_6

	% node_6
	%res_conumable, resource_2, res_non_conumable, resource_0_resource_0_0, resource_0_resource_0_1, resource_0_resource_0_2, resource_1_resource_1_0, resource_1_resource_1_1, resource_1_resource_1_2, resource_1_resource_1_3, resource_1_resource_1_4, resource_1_resource_1_5, resource_1_resource_1_6, resource_1_resource_1_7, resource_1_resource_1_8, resource_1_resource_1_9, resource_3, resource_4, resource_5_resource_5_0, resource_5_resource_5_1, resource_5_resource_5_2, resource_6, resource_7_resource_7_0, resource_7_resource_7_1, resource_7_resource_7_2, resource_7_resource_7_3, resource_7_resource_7_4, resource_7_resource_7_5, resource_7_resource_7_6, resource_7_resource_7_7, resource_7_resource_7_8
	MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, % 0
	MIN_RBOUNDS, MIN_RBOUNDS, 677, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 510, 627, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 958, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % node_0
	MIN_RBOUNDS, MIN_RBOUNDS, 309, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 490, 266, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 336, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % node_1
	MIN_RBOUNDS, MIN_RBOUNDS, 442, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 357, 669, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 437, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % node_2
	MIN_RBOUNDS, MIN_RBOUNDS, 474, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 292, 513, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 640, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % node_3
	MIN_RBOUNDS, MIN_RBOUNDS, 594, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 111, 184, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 174, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % node_4
	MIN_RBOUNDS, MIN_RBOUNDS, 265, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 11, 936, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 651, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % node_5
	804, 744, 644, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 317, 954, 1, 1, 1, 923, 1, 1, 1, 1, 1, 1, 1, 1, 1, % node_6

]);
cost = array2d(Nodes0, Res, [0 | r in Res] ++ [ % No node
	%res_conumable, resource_2, res_non_conumable, resource_0_resource_0_0, resource_0_resource_0_1, resource_0_resource_0_2, resource_1_resource_1_0, resource_1_resource_1_1, resource_1_resource_1_2, resource_1_resource_1_3, resource_1_resource_1_4, resource_1_resource_1_5, resource_1_resource_1_6, resource_1_resource_1_7, resource_1_resource_1_8, resource_1_resource_1_9, resource_3, resource_4, resource_5_resource_5_0, resource_5_resource_5_1, resource_5_resource_5_2, resource_6, resource_7_resource_7_0, resource_7_resource_7_1, resource_7_resource_7_2, resource_7_resource_7_3, resource_7_resource_7_4, resource_7_resource_7_5, resource_7_resource_7_6, resource_7_resource_7_7, resource_7_resource_7_8
	7, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, % node_0
	10, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, % node_1
	3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, % node_2
	9, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, % node_3
	8, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, % node_4
	3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, % node_5
	6, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, % node_6
]);
carb = array1d(Nodes0, [0] ++ [ % No node
	2, 4, 5, 5, 10, 10, 7
]);
costBudget = 34;
carbBudget = 7608;


array[int] of set of int: params_set = [Req_cf[i0] | i0 in CompFlavs]
	 ++ [Req_cfc[i0, i1, i2] | i0 in Comps, i1 in Flavs, i2 in Comps]
	 ++ [Req_n[i0] | i0 in Nodes];

array[int] of var set of int: params_set_lifted = [Req_cf_lifted[i0] | i0 in CompFlavs]
	 ++ [Req_cfc_lifted[i0, i1, i2] | i0 in Comps, i1 in Flavs, i2 in Comps]
	 ++ [Req_n_lifted[i0] | i0 in Nodes];

array[int] of int: params_int = [carbBudget]
	 ++ [carb[i0] | i0 in Nodes0]
	 ++ [comReq[i0, i1] | i0 in CompFlavs, i1 in Res]
	 ++ [costBudget]
	 ++ [cost[i0, i1] | i0 in Nodes0, i1 in Res]
	 ++ [depReq[i0, i1, i2, i3] | i0 in Comps, i1 in Flavs, i2 in Comps, i3 in Res]
	 ++ [energy_dependency[i0, i1, i2] | i0 in Comps, i1 in Flavs, i2 in Comps]
	 ++ [energy[i0] | i0 in CompFlavs]
	 ++ [linkCap[i0, i1, i2] | i0 in Nodes0, i1 in Nodes0, i2 in Res]
	 ++ [nodeCap[i0, i1] | i0 in Nodes0, i1 in Res];

array[int] of var int: params_int_lifted = [carbBudget_lifted]
	 ++ [carb_lifted[i0] | i0 in Nodes0]
	 ++ [comReq_lifted[i0, i1] | i0 in CompFlavs, i1 in Res]
	 ++ [costBudget_lifted]
	 ++ [cost_lifted[i0, i1] | i0 in Nodes0, i1 in Res]
	 ++ [depReq_lifted[i0, i1, i2, i3] | i0 in Comps, i1 in Flavs, i2 in Comps, i3 in Res]
	 ++ [energy_dependency_lifted[i0, i1, i2] | i0 in Comps, i1 in Flavs, i2 in Comps]
	 ++ [energy_lifted[i0] | i0 in CompFlavs]
	 ++ [linkCap_lifted[i0, i1, i2] | i0 in Nodes0, i1 in Nodes0, i2 in Res]
	 ++ [nodeCap_lifted[i0, i1] | i0 in Nodes0, i1 in Res];

include "experimental/assume.mzn";

array[int] of var bool: lifted_assumed = [params_set_lifted[i] = params_set[i] | i in index_set(params_set)]
	++[params_int_lifted[i] = params_int[i] | i in index_set(params_int)];

array[int] of var bool: assumed = [if i in 
	{4, 5, 65, 67, 68, 69, 70, 71, 72, 73, 167, 198, 291, 323, 354, 385, 416, 447, 478, 509, 2092, 2093, 2119, 2140, 2143, 2144}
	then true else lifted_assumed[i] endif | i in index_set(lifted_assumed)];

constraint assume(assumed);

constraint assert(trace(
	"Length of params_set        = \(length(params_set))\n",
	length(params_set)
)= trace(
	"Length of params_set_lifted = \(length(params_set_lifted))\n",
	length(params_set_lifted)
), "ERROR: length of parameters and lifted does not match");

constraint assert(trace(
	"Length of params_int        = \(length(params_int))\n",
	length(params_int)
)= trace(
	"Length of params_int_lifted = \(length(params_int_lifted))\n",
	length(params_int_lifted)
), "ERROR: length of parameters and lifted does not match");

var int: objective_lifted :: output_var = 0 %sum([abs(card(Req_cf_lifted[i0] symdiff Req_cf[i0])) | i0 in CompFlavs])
	+ 0 %sum([abs(card(Req_cfc_lifted[i0, i1, i2] symdiff Req_cfc[i0, i1, i2])) | i0 in Comps, i1 in Flavs, i2 in Comps])
	+ 0 %sum([abs(card(Req_n_lifted[i0] symdiff Req_n[i0])) | i0 in Nodes])
	+ abs(carbBudget_lifted - carbBudget)
	+ sum([abs(carb_lifted[i0] - carb[i0]) | i0 in Nodes0])
	+ sum([abs(comReq_lifted[i0, i1] - comReq[i0, i1]) | i0 in CompFlavs, i1 in Res])
	+ abs(costBudget_lifted - costBudget)
	+ sum([abs(cost_lifted[i0, i1] - cost[i0, i1]) | i0 in Nodes0, i1 in Res])
	+ sum([abs(depReq_lifted[i0, i1, i2, i3] - depReq[i0, i1, i2, i3]) | i0 in Comps, i1 in Flavs, i2 in Comps, i3 in Res])
	+ sum([abs(energy_dependency_lifted[i0, i1, i2] - energy_dependency[i0, i1, i2]) | i0 in Comps, i1 in Flavs, i2 in Comps])
	+ sum([abs(energy_lifted[i0] - energy[i0]) | i0 in CompFlavs])
	+ sum([abs(linkCap_lifted[i0, i1, i2] - linkCap[i0, i1, i2]) | i0 in Nodes0, i1 in Nodes0, i2 in Res])
	+ sum([abs(nodeCap_lifted[i0, i1] - nodeCap[i0, i1]) | i0 in Nodes0, i1 in Res])
;
solve
	::warm_start(assumed, [true | _ in index_set(assumed)])
minimize objective_lifted;

output ["_objective = \(objective_lifted)\n"];

