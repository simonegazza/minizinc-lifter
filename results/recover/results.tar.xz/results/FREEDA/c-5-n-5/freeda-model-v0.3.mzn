%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%% MiniZinc parametric model for FREEDA %%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

include "globals.mzn";

%%%%%%%%%%%%%%%%%%%%%%
%%%%% Parameters %%%%%
%%%%%%%%%%%%%%%%%%%%%%

%%%%% Components and Flavours %%%%%

% All the components.
enum Comps;
% Components that *must* always be deployed.
set of Comps: mustComps;

% All the flavours.
enum Flavs;
% Flav[c] is the set of all flavours offered by component c.
array[Comps] of set of Flavs: Flav;

% CompFlavs is the index set for the rows of the deployment matrices.
set of int: CompFlavs = 1..sum(c in Comps)(length(Flav[c]));
% Idx(c,f) is the row of component c in flavour f in the deployment matrices.
% It maps pairs from Comps × Flavs to indices of CompFlavs.
function int:
Idx(Comps: c, Flavs: f) =
  sum (i in 1..c-1)(length(Flav[Comps[i]])) + arg_max([f = i | i in Flav[c]]);

% Importance of a component in a given flavour.
% FIXME: we assume f ⪯c f′ iff imp(c,f) ≤ imp(c,f′).
array[Comps, Flavs] of int: imp;

% Uses[Idx(c,f),Idx(c',f')] = 1 iff component c in flavour f requires component
% c' in a flavour at least as powerful as f′.
array[CompFlavs, CompFlavs] of 0..1: Uses;

% mayUse[c,Idx(c',f)] = 1 iff c' in flavour f may use c in some flavour.
array[Comps, CompFlavs] of 0..1: mayUse;

%%%%% Resources %%%%%

% Consumable resources.
enum CRes;
% Non-consumable resources.
enum NRes;
% All the resources.
enum Res = C(CRes) ++ N(NRes);

% Req_cf[Idx(c,f)] is the set of resources required by c in flavour f.
array[CompFlavs] of set of Res: Req_cf = [
  {r | r in Res where comReq[cf, r] != worstBounds[r]} | cf in CompFlavs
];

% Req_cfc[c,f,c'] is the set of resources required by the connection between
% "source" component c, deployed in flavour f, and "target" component c′.
array[Comps, Flavs, Comps] of set of Res: Req_cfc = array3d(Comps, Flavs, Comps,
  [{r | r in Res where depReq[c1, i, c2, r] != worstBounds[r]}
  | c1 in Comps, i in Flavs, c2 in Comps
  ]);

% Lower bound for bestBounds and worseBounds values.
int: MIN_RBOUNDS;
% Upper bound for bestBounds and worseBounds values.
int: MAX_RBOUNDS;
% No value for a resource r can be worse than worstBounds[r].
array[Res] of MIN_RBOUNDS..MAX_RBOUNDS: bestBounds;
% No value for a resource r can be better than bestBounds[r].
array[Res] of MIN_RBOUNDS..MAX_RBOUNDS: worstBounds;

% comReq[Idx(c,f), r] defines the amount of resource r in Req_cf[Idx(c,f)]
% required by c to be executed in flavour f: if worstBounds[r] = MIN_RBOUNDS,
% then c requires at least comReq[Idx(c,f), r] units of r; otherwise, it
% requires at most comReq[Idx(c,f), r] units of r.
array[CompFlavs, Res] of MIN_RBOUNDS..MAX_RBOUNDS: comReq;

% depReq[c, f, c', r] defines the amount of resource r in Req_cfc[c,f,c']
% required by the link connecting the node of the source component c to the
% node of the target component c′: if worstBounds[r] = MIN_RBOUNDS,
% then the link requires at least depReq[c, f, c', r] units of r; otherwise,
% it requires at most depReq[c, f, c', r] units of r.
array[Comps, Flavs, Comps, Res] of MIN_RBOUNDS..MAX_RBOUNDS: depReq;

%%%%% Infrastructure, capacity and budget %%%%%

% All the nodes of the infrastructure.
enum Nodes;
% Node 0 is a dummy node added for convenience, to better handle the
% constraints below. No component can be deployed on node 0.
set of int: Nodes0 = {0} union Nodes;

% Req_n[n] is the set of resources offered by node n.
array[Nodes] of set of Res: Req_n = [
  {r | r in Res where nodeCap[n, r] != worstBounds[r]} | n in Nodes
];

% nodeCap[n,r] is maximum amount of resource r available at node n.
array[Nodes0, Res] of MIN_RBOUNDS..MAX_RBOUNDS: nodeCap;
% If n = 0, it must be nodeCap[n,r] = bestBounds[r].
constraint assert (forall(r in Res)(nodeCap[0,r] = bestBounds[r]),
  "Assertion nodeCap[0,r] = bestBounds[r] failed.", true);

% linkCap[n, n', r] is the maximum amount of r that the link between n and n′
% can handle.
array[Nodes0, Nodes0, Res] of MIN_RBOUNDS..MAX_RBOUNDS: linkCap;
% If n = 0 or n' = 0, it must be linkCap[n, n', r] = bestBounds[r].
constraint assert (forall(n in Nodes, r in Res)(
  linkCap[n,0,r] = bestBounds[r] /\ linkCap[0, n, r] = bestBounds[r]),
  "Assertion linkCap[n,0,r] = linkCap[0,n,r] = bestBounds[r] failed.", true);

% cost[n,r] is the unit cost of using resource r node n.
array[Nodes0, Res] of 0..10: cost;
% It must be cost[0,r] = 0.
constraint assert (forall(r in Res)(cost[0,r] = 0),
  "Assertion cost[0,r] = 0 failed.", true);
% Money budget.
1..1000000: costBudget;

% carb[n] is the carbon emission per node n.
array[Nodes0] of 0..10: carb;
% It must be carb[0] = 0.
constraint assert (carb[0] = 0,
  "Assertion carb[0] = 0 failed.", true);
% Carbon budget.
1..2000000: carbBudget;


%%%%%%%%%%%%%%%%%%%%%
%%%%% Variables %%%%%
%%%%%%%%%%%%%%%%%%%%%

% D[Idx(c,f),j] = 1 iff component c is deployed in flavour f on node j.
array [{0} union CompFlavs, Nodes0] of var 0..1: D;

% node[c] is the node where c is deployed, or node[c] = 0 if c not deployed.
array [Comps] of var Nodes0: node = [
  sum(i in Flav[c], j in Nodes)(j * D[Idx(c, i), j]) | c in Comps
];

% Total cost of the deployment.
var int: totCost;
constraint totCost = sum(c in Comps, i in Flav[c], r in Req_cf[Idx(c, i)])(
  comReq[Idx(c, i), r] * cost[node[c], r] * D[Idx(c, i), node[c]]
);

% Energy reuirements for each component-flavour
array[CompFlavs] of 0..1000: energy;

% Energy consumption for the dependency between components
array[Comps, Flavs, Comps] of 0..1000: energy_dependency;

% Total carbon emission of the deployment.
var int: totCarb;
constraint totCarb = sum(cs in Comps, is in Flav[cs], js in Nodes)(
  D[Idx(cs, is), js] * (
    energy[Idx(cs, is)] * carb[js] + sum(
      cd in Comps,
      id in Flav[cd] where mayUse[cd, Idx(cs, is)] = 1 /\ energy_dependency[cs, is, cd] > 0,
      jd in Nodes
    )(
      D[Idx(cd, id), jd] * energy_dependency[cs, is, cd] * (carb[js] + carb[jd]) div 2
    )
  )
);

%%%%%%%%%%%%%%%%%%%%%%%
%%%%% Constraints %%%%%
%%%%%%%%%%%%%%%%%%%%%%%

% Zero values for D[0,j] and D[i,0].
constraint forall(j in Nodes0)(D[0, j] = 0);
constraint forall(i in CompFlavs)(D[i, 0] = 0);

% Each component is deployed in at most one flavour, on at most one node.
constraint forall(c in Comps)(
  sum(i in Flav[c], j in Nodes)(D[Idx(c, i), j]) <= 1
);

% Components that must be deployed
constraint forall(m in mustComps)(
  sum (i in Flav[m], j in Nodes)(D[Idx(m, i), j]) > 0 /\ node[m] > 0
);

% If component c is deployed in flavour i, for each (c',i') in Uses[c,i]
% component c' must be deployed in a flavour bigger or equal than i'.
constraint forall(
  c in Comps,
  i in Flav[c],
  cu in Comps,
  iu in Flav[cu] where Uses[Idx(c, i), Idx(cu, iu)] = 1
)(
  sum(j in Nodes)(D[Idx(c, i), j]) <=
  sum(k in Flav[cu], j in Nodes where imp[cu,k] >= imp[cu,iu])(D[Idx(cu, k),j])
);

% If a "target" component c not in mustComps is deployed, at least one "source"
% component c' must be deployed in a flavour f requiring c.
constraint forall(c in Comps diff mustComps)(
  sum(i in Flav[c], j in Nodes)(D[Idx(c, i), j]) <=
  sum(
    cs in Comps where c != cs,
    is in Flav[cs] where mayUse[c, Idx(cs, is)] = 1,
    j in Nodes
  )(D[Idx(cs, is), j])
);

% Each node j has a sufficient quantity of a certain resource r to meet the
% demands of all the components deployed on it.
constraint forall(j in Nodes, r in Req_n[j] where r in C(CRes)) (
  if worstBounds[r] = MIN_RBOUNDS then
    sum(c in Comps, i in Flav[c] where r in Req_cf[Idx(c,i)])
      (comReq[Idx(c,i), r] * D[Idx(c,i), j]) <= nodeCap[j,r]
  else
    assert(false, "·Lower bound for 'maximization' resources unsupported.")
  endif
);

% If component c deployed in flavour i requires a certain amount of resource r,
% then node c must have capacity for r
constraint forall(
  c in Comps,
  i in Flav[c],
  r in Req_cf[Idx(c,i)] where r in N(NRes)
)(
  if worstBounds[r] = MIN_RBOUNDS then
    comReq[Idx(c,i), r] * D[Idx(c,i), node[c]] <= nodeCap[node[c], r]
  else
    comReq[Idx(c,i), r] >= nodeCap[node[c], r] * D[Idx(c,i), node[c]]
  endif
);

% Dependency from c to c' must be fulfilled only if there is an active
% dependency between c and c'.
% FIXME: so far, only defined on non-consumable resources.
constraint forall(
  cs in Comps,
  is in Flav[cs],
  cd in Comps where mayUse[cd, Idx(cs, is)] = 1,
  r in Req_cfc[cs, is, cd] where r in N(NRes),
)(
  if worstBounds[r] = MIN_RBOUNDS then
    depReq[cs, is, cd, r] * sum(j in Nodes)(D[Idx(cs, is), j]) <=
    linkCap[node[cs], node[cd], r]
  else
    depReq[cs, is, cd, r] >= sum(j in Nodes)(D[Idx(cs, is), j]) *
    linkCap[node[cs], node[cd], r]
  endif
);


% Budget requirements.
constraint totCost <= costBudget;
constraint totCarb <= carbBudget;


%%%%%%%%%%%%%%%%%%%%%
%%%%% Objective %%%%%
%%%%%%%%%%%%%%%%%%%%%

var int: obj = sum(c in Comps, i in Flav[c])(
  imp[c,i] * sum([D[Idx(c,i),j] | j in Nodes])
);
solve maximize obj;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%% Output formatting %%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

output [
  if fix(node[c]) > 0 then
    "Component \(c) deployed in flavour \([Flavs[i] | i in Flav[c] where D[Idx(c, i), node[c]] > 0][1]) on node \(Nodes[node[c]]).\n"
  else
    "Component \(c) not deployed.\n"
  endif
  | c in Comps
] ++ [
  "Objective value: \(obj)\n\tTotal cost: \(totCost)\n\tTotal carb: \(totCarb)"
];
% ++ [
%     "\n\(r) : \(cs)_\(is) -> \(cd) on \(node[cs]) -> \(node[cd]) -- \(depReq[cs, is, cd, r] * sum(j in Nodes)(D[Idx(cs, is), j])) >= \(linkCap[node[cs], node[cd], r])"
%   | cs in Comps,
%     is in Flav[cs] ,%where fix(D[Idx(cs, is), node[cs]]) > 0,
%     cd in Comps ,%where exists(id in Flav[cd])(Uses[Idx(cs, is), Idx(cd, id)] = 1 /\ fix(D[Idx(cd, id), node[cd]]) > 0),
%     r in Req_cfc[cs, is, cd] where r in N(NRes) /\ worstBounds[r] != MIN_RBOUNDS
% ]

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Input data for app in infrastructure %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Comps = {component_0, component_1, component_3, component_2, component_4};
mustComps = {component_0};
Flavs = {flavour_0, flavour_1};
Flav = [{flavour_0}, {flavour_0}, {flavour_0, flavour_1}, {flavour_0}, {flavour_0}];
imp = array2d(Comps, Flavs, [
	%flavour_0, flavour_1
	1, 0, % component_0
	1, 0, % component_1
	1, 2, % component_3
	1, 0, % component_2
	1, 0, % component_4
]);
energy = [951, 225, 609, 61, 837, 856];
energy_dependency = array3d(Comps, Flavs, Comps, [

	% component_0
	%component_0, component_1, component_3, component_2, component_4
	0, 0, 0, 0, 0, % flavour_0
	0, 0, 0, 0, 0, % flavour_1

	% component_1
	%component_0, component_1, component_3, component_2, component_4
	0, 0, 0, 0, 0, % flavour_0
	0, 0, 0, 0, 0, % flavour_1

	% component_3
	%component_0, component_1, component_3, component_2, component_4
	0, 0, 0, 0, 0, % flavour_0
	0, 0, 0, 0, 0, % flavour_1

	% component_2
	%component_0, component_1, component_3, component_2, component_4
	0, 0, 0, 0, 0, % flavour_0
	0, 0, 0, 0, 0, % flavour_1

	% component_4
	%component_0, component_1, component_3, component_2, component_4
	0, 0, 0, 0, 0, % flavour_0
	0, 0, 0, 0, 0, % flavour_1

]);
Uses = array2d(CompFlavs, CompFlavs, [
	%component_0_flavour_0, component_1_flavour_0, component_3_flavour_0, component_3_flavour_1, component_2_flavour_0, component_4_flavour_0
	0, 0, 1, 0, 0, 0, % component_0_flavour_0
	0, 0, 0, 0, 1, 1, % component_1_flavour_0
	0, 0, 0, 0, 0, 1, % component_3_flavour_0
	0, 0, 0, 0, 0, 1, % component_3_flavour_1
	0, 0, 1, 0, 0, 1, % component_2_flavour_0
	0, 0, 0, 0, 0, 0, % component_4_flavour_0
]);
mayUse = array2d(Comps, CompFlavs, [
	%component_0_flavour_0, component_1_flavour_0, component_3_flavour_0, component_3_flavour_1, component_2_flavour_0, component_4_flavour_0
	0, 0, 0, 0, 0, 0, % component_0
	0, 0, 0, 0, 0, 0, % component_1
	1, 0, 0, 0, 1, 0, % component_3
	0, 1, 0, 0, 0, 0, % component_2
	0, 1, 1, 1, 1, 0, % component_4
]);
CRes = {res_conumable, resource_2, resource_4, resource_5, resource_6, resource_7};
NRes = {res_non_conumable, resource_0_resource_0_0, resource_0_resource_0_1, resource_0_resource_0_2, resource_0_resource_0_3, resource_0_resource_0_4, resource_0_resource_0_5, resource_0_resource_0_6, resource_0_resource_0_7, resource_0_resource_0_8, resource_0_resource_0_9, resource_1_resource_1_0, resource_1_resource_1_1, resource_1_resource_1_2, resource_1_resource_1_3, resource_1_resource_1_4, resource_1_resource_1_5, resource_1_resource_1_6, resource_1_resource_1_7, resource_3};
MAX_RBOUNDS = 997;
MIN_RBOUNDS = 0;
worstBounds = [
	MIN_RBOUNDS, % res_conumable
	MIN_RBOUNDS, % resource_2
	MIN_RBOUNDS, % resource_4
	MIN_RBOUNDS, % resource_5
	MIN_RBOUNDS, % resource_6
	MIN_RBOUNDS, % resource_7
	MIN_RBOUNDS, % res_non_conumable
	MIN_RBOUNDS, % resource_0_resource_0_0
	MIN_RBOUNDS, % resource_0_resource_0_1
	MIN_RBOUNDS, % resource_0_resource_0_2
	MIN_RBOUNDS, % resource_0_resource_0_3
	MIN_RBOUNDS, % resource_0_resource_0_4
	MIN_RBOUNDS, % resource_0_resource_0_5
	MIN_RBOUNDS, % resource_0_resource_0_6
	MIN_RBOUNDS, % resource_0_resource_0_7
	MIN_RBOUNDS, % resource_0_resource_0_8
	MIN_RBOUNDS, % resource_0_resource_0_9
	MIN_RBOUNDS, % resource_1_resource_1_0
	MIN_RBOUNDS, % resource_1_resource_1_1
	MIN_RBOUNDS, % resource_1_resource_1_2
	MIN_RBOUNDS, % resource_1_resource_1_3
	MIN_RBOUNDS, % resource_1_resource_1_4
	MIN_RBOUNDS, % resource_1_resource_1_5
	MIN_RBOUNDS, % resource_1_resource_1_6
	MIN_RBOUNDS, % resource_1_resource_1_7
	MIN_RBOUNDS, % resource_3
];
bestBounds = [
	MAX_RBOUNDS, % res_conumable
	MAX_RBOUNDS, % resource_2
	MAX_RBOUNDS, % resource_4
	MAX_RBOUNDS, % resource_5
	MAX_RBOUNDS, % resource_6
	MAX_RBOUNDS, % resource_7
	MAX_RBOUNDS, % res_non_conumable
	MAX_RBOUNDS, % resource_0_resource_0_0
	MAX_RBOUNDS, % resource_0_resource_0_1
	MAX_RBOUNDS, % resource_0_resource_0_2
	MAX_RBOUNDS, % resource_0_resource_0_3
	MAX_RBOUNDS, % resource_0_resource_0_4
	MAX_RBOUNDS, % resource_0_resource_0_5
	MAX_RBOUNDS, % resource_0_resource_0_6
	MAX_RBOUNDS, % resource_0_resource_0_7
	MAX_RBOUNDS, % resource_0_resource_0_8
	MAX_RBOUNDS, % resource_0_resource_0_9
	MAX_RBOUNDS, % resource_1_resource_1_0
	MAX_RBOUNDS, % resource_1_resource_1_1
	MAX_RBOUNDS, % resource_1_resource_1_2
	MAX_RBOUNDS, % resource_1_resource_1_3
	MAX_RBOUNDS, % resource_1_resource_1_4
	MAX_RBOUNDS, % resource_1_resource_1_5
	MAX_RBOUNDS, % resource_1_resource_1_6
	MAX_RBOUNDS, % resource_1_resource_1_7
	MAX_RBOUNDS, % resource_3
];

comReq = array2d(CompFlavs, Res, [
	%res_conumable, resource_2, resource_4, resource_5, resource_6, resource_7, res_non_conumable, resource_0_resource_0_0, resource_0_resource_0_1, resource_0_resource_0_2, resource_0_resource_0_3, resource_0_resource_0_4, resource_0_resource_0_5, resource_0_resource_0_6, resource_0_resource_0_7, resource_0_resource_0_8, resource_0_resource_0_9, resource_1_resource_1_0, resource_1_resource_1_1, resource_1_resource_1_2, resource_1_resource_1_3, resource_1_resource_1_4, resource_1_resource_1_5, resource_1_resource_1_6, resource_1_resource_1_7, resource_3
	86, 89, 89, 133, 140, 10, 106, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 1, MIN_RBOUNDS, 1, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 1, 1, 1, 1, 1, MIN_RBOUNDS, MIN_RBOUNDS, 1, 43, % component_0_flavour_0
	65, 115, 207, 99, 41, 68, 40, MIN_RBOUNDS, 1, 1, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 1, MIN_RBOUNDS, MIN_RBOUNDS, 1, 1, 1, MIN_RBOUNDS, MIN_RBOUNDS, 1, MIN_RBOUNDS, MIN_RBOUNDS, 139, % component_1_flavour_0
	152, 65, 235, 22, 160, 55, 94, 1, 1, 1, 1, 1, 1, MIN_RBOUNDS, MIN_RBOUNDS, 1, 1, 1, 1, 1, MIN_RBOUNDS, MIN_RBOUNDS, 1, 1, 1, 138, % component_3_flavour_0
	147, 57, 235, 19, 114, 41, 48, 1, MIN_RBOUNDS, MIN_RBOUNDS, 1, 1, 1, 1, 1, 1, 1, MIN_RBOUNDS, MIN_RBOUNDS, 1, MIN_RBOUNDS, 1, MIN_RBOUNDS, 1, MIN_RBOUNDS, 104, % component_3_flavour_1
	54, 36, 17, 96, 20, 49, 62, 1, 1, 1, 1, 1, 1, 1, 1, 1, MIN_RBOUNDS, MIN_RBOUNDS, 1, 1, 1, MIN_RBOUNDS, MIN_RBOUNDS, 1, 1, 17, % component_2_flavour_0
	9, 219, 87, 84, 121, 119, 131, MIN_RBOUNDS, 1, MIN_RBOUNDS, MIN_RBOUNDS, 1, 1, MIN_RBOUNDS, 1, MIN_RBOUNDS, 1, 1, 1, 1, MIN_RBOUNDS, 1, MIN_RBOUNDS, MIN_RBOUNDS, 1, 10, % component_4_flavour_0
]);
Nodes = {node_0, node_1, node_2, node_3, node_4};

nodeCap = array2d(Nodes0, Res,
	[bestBounds[r] | r in Res] ++ [ % No node
	%res_conumable, resource_2, resource_4, resource_5, resource_6, resource_7, res_non_conumable, resource_0_resource_0_0, resource_0_resource_0_1, resource_0_resource_0_2, resource_0_resource_0_3, resource_0_resource_0_4, resource_0_resource_0_5, resource_0_resource_0_6, resource_0_resource_0_7, resource_0_resource_0_8, resource_0_resource_0_9, resource_1_resource_1_0, resource_1_resource_1_1, resource_1_resource_1_2, resource_1_resource_1_3, resource_1_resource_1_4, resource_1_resource_1_5, resource_1_resource_1_6, resource_1_resource_1_7, resource_3
	784, 807, 265, 859, 372, 668, 856, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 882, % node_0
	311, 887, 847, 831, 518, 98, 377, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 124, % node_1
	933, 674, 531, 275, 100, 247, 585, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 507, % node_2
	528, 725, 86, 233, 394, 331, 400, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 731, % node_3
	613, 98, 317, 640, 459, 560, 826, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 528, % node_4
]);
depReq = array4d(Comps, Flavs, Comps, Res, [

	% component_0

	% flavour_0
	%res_conumable, resource_2, resource_4, resource_5, resource_6, resource_7, res_non_conumable, resource_0_resource_0_0, resource_0_resource_0_1, resource_0_resource_0_2, resource_0_resource_0_3, resource_0_resource_0_4, resource_0_resource_0_5, resource_0_resource_0_6, resource_0_resource_0_7, resource_0_resource_0_8, resource_0_resource_0_9, resource_1_resource_1_0, resource_1_resource_1_1, resource_1_resource_1_2, resource_1_resource_1_3, resource_1_resource_1_4, resource_1_resource_1_5, resource_1_resource_1_6, resource_1_resource_1_7, resource_3
	MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % component_0
	MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % component_1
	MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % component_3
	MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % component_2
	MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % component_4

	% flavour_1
	%res_conumable, resource_2, resource_4, resource_5, resource_6, resource_7, res_non_conumable, resource_0_resource_0_0, resource_0_resource_0_1, resource_0_resource_0_2, resource_0_resource_0_3, resource_0_resource_0_4, resource_0_resource_0_5, resource_0_resource_0_6, resource_0_resource_0_7, resource_0_resource_0_8, resource_0_resource_0_9, resource_1_resource_1_0, resource_1_resource_1_1, resource_1_resource_1_2, resource_1_resource_1_3, resource_1_resource_1_4, resource_1_resource_1_5, resource_1_resource_1_6, resource_1_resource_1_7, resource_3
	MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % component_0
	MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % component_1
	MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % component_3
	MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % component_2
	MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % component_4


	% component_1

	% flavour_0
	%res_conumable, resource_2, resource_4, resource_5, resource_6, resource_7, res_non_conumable, resource_0_resource_0_0, resource_0_resource_0_1, resource_0_resource_0_2, resource_0_resource_0_3, resource_0_resource_0_4, resource_0_resource_0_5, resource_0_resource_0_6, resource_0_resource_0_7, resource_0_resource_0_8, resource_0_resource_0_9, resource_1_resource_1_0, resource_1_resource_1_1, resource_1_resource_1_2, resource_1_resource_1_3, resource_1_resource_1_4, resource_1_resource_1_5, resource_1_resource_1_6, resource_1_resource_1_7, resource_3
	MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % component_0
	MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % component_1
	MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % component_3
	MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % component_2
	MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % component_4

	% flavour_1
	%res_conumable, resource_2, resource_4, resource_5, resource_6, resource_7, res_non_conumable, resource_0_resource_0_0, resource_0_resource_0_1, resource_0_resource_0_2, resource_0_resource_0_3, resource_0_resource_0_4, resource_0_resource_0_5, resource_0_resource_0_6, resource_0_resource_0_7, resource_0_resource_0_8, resource_0_resource_0_9, resource_1_resource_1_0, resource_1_resource_1_1, resource_1_resource_1_2, resource_1_resource_1_3, resource_1_resource_1_4, resource_1_resource_1_5, resource_1_resource_1_6, resource_1_resource_1_7, resource_3
	MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % component_0
	MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % component_1
	MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % component_3
	MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % component_2
	MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % component_4


	% component_3

	% flavour_0
	%res_conumable, resource_2, resource_4, resource_5, resource_6, resource_7, res_non_conumable, resource_0_resource_0_0, resource_0_resource_0_1, resource_0_resource_0_2, resource_0_resource_0_3, resource_0_resource_0_4, resource_0_resource_0_5, resource_0_resource_0_6, resource_0_resource_0_7, resource_0_resource_0_8, resource_0_resource_0_9, resource_1_resource_1_0, resource_1_resource_1_1, resource_1_resource_1_2, resource_1_resource_1_3, resource_1_resource_1_4, resource_1_resource_1_5, resource_1_resource_1_6, resource_1_resource_1_7, resource_3
	MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % component_0
	MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % component_1
	MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % component_3
	MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % component_2
	MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % component_4

	% flavour_1
	%res_conumable, resource_2, resource_4, resource_5, resource_6, resource_7, res_non_conumable, resource_0_resource_0_0, resource_0_resource_0_1, resource_0_resource_0_2, resource_0_resource_0_3, resource_0_resource_0_4, resource_0_resource_0_5, resource_0_resource_0_6, resource_0_resource_0_7, resource_0_resource_0_8, resource_0_resource_0_9, resource_1_resource_1_0, resource_1_resource_1_1, resource_1_resource_1_2, resource_1_resource_1_3, resource_1_resource_1_4, resource_1_resource_1_5, resource_1_resource_1_6, resource_1_resource_1_7, resource_3
	MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % component_0
	MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % component_1
	MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % component_3
	MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % component_2
	MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % component_4


	% component_2

	% flavour_0
	%res_conumable, resource_2, resource_4, resource_5, resource_6, resource_7, res_non_conumable, resource_0_resource_0_0, resource_0_resource_0_1, resource_0_resource_0_2, resource_0_resource_0_3, resource_0_resource_0_4, resource_0_resource_0_5, resource_0_resource_0_6, resource_0_resource_0_7, resource_0_resource_0_8, resource_0_resource_0_9, resource_1_resource_1_0, resource_1_resource_1_1, resource_1_resource_1_2, resource_1_resource_1_3, resource_1_resource_1_4, resource_1_resource_1_5, resource_1_resource_1_6, resource_1_resource_1_7, resource_3
	MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % component_0
	MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % component_1
	MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % component_3
	MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % component_2
	MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % component_4

	% flavour_1
	%res_conumable, resource_2, resource_4, resource_5, resource_6, resource_7, res_non_conumable, resource_0_resource_0_0, resource_0_resource_0_1, resource_0_resource_0_2, resource_0_resource_0_3, resource_0_resource_0_4, resource_0_resource_0_5, resource_0_resource_0_6, resource_0_resource_0_7, resource_0_resource_0_8, resource_0_resource_0_9, resource_1_resource_1_0, resource_1_resource_1_1, resource_1_resource_1_2, resource_1_resource_1_3, resource_1_resource_1_4, resource_1_resource_1_5, resource_1_resource_1_6, resource_1_resource_1_7, resource_3
	MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % component_0
	MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % component_1
	MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % component_3
	MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % component_2
	MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % component_4


	% component_4

	% flavour_0
	%res_conumable, resource_2, resource_4, resource_5, resource_6, resource_7, res_non_conumable, resource_0_resource_0_0, resource_0_resource_0_1, resource_0_resource_0_2, resource_0_resource_0_3, resource_0_resource_0_4, resource_0_resource_0_5, resource_0_resource_0_6, resource_0_resource_0_7, resource_0_resource_0_8, resource_0_resource_0_9, resource_1_resource_1_0, resource_1_resource_1_1, resource_1_resource_1_2, resource_1_resource_1_3, resource_1_resource_1_4, resource_1_resource_1_5, resource_1_resource_1_6, resource_1_resource_1_7, resource_3
	MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % component_0
	MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % component_1
	MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % component_3
	MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % component_2
	MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % component_4

	% flavour_1
	%res_conumable, resource_2, resource_4, resource_5, resource_6, resource_7, res_non_conumable, resource_0_resource_0_0, resource_0_resource_0_1, resource_0_resource_0_2, resource_0_resource_0_3, resource_0_resource_0_4, resource_0_resource_0_5, resource_0_resource_0_6, resource_0_resource_0_7, resource_0_resource_0_8, resource_0_resource_0_9, resource_1_resource_1_0, resource_1_resource_1_1, resource_1_resource_1_2, resource_1_resource_1_3, resource_1_resource_1_4, resource_1_resource_1_5, resource_1_resource_1_6, resource_1_resource_1_7, resource_3
	MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % component_0
	MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % component_1
	MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % component_3
	MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % component_2
	MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, % component_4


]);
linkCap = array3d(Nodes0, Nodes0, Res, [

	% 0
	%res_conumable, resource_2, resource_4, resource_5, resource_6, resource_7, res_non_conumable, resource_0_resource_0_0, resource_0_resource_0_1, resource_0_resource_0_2, resource_0_resource_0_3, resource_0_resource_0_4, resource_0_resource_0_5, resource_0_resource_0_6, resource_0_resource_0_7, resource_0_resource_0_8, resource_0_resource_0_9, resource_1_resource_1_0, resource_1_resource_1_1, resource_1_resource_1_2, resource_1_resource_1_3, resource_1_resource_1_4, resource_1_resource_1_5, resource_1_resource_1_6, resource_1_resource_1_7, resource_3
	MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, % 0
	MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, % node_0
	MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, % node_1
	MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, % node_2
	MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, % node_3
	MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, % node_4

	% node_0
	%res_conumable, resource_2, resource_4, resource_5, resource_6, resource_7, res_non_conumable, resource_0_resource_0_0, resource_0_resource_0_1, resource_0_resource_0_2, resource_0_resource_0_3, resource_0_resource_0_4, resource_0_resource_0_5, resource_0_resource_0_6, resource_0_resource_0_7, resource_0_resource_0_8, resource_0_resource_0_9, resource_1_resource_1_0, resource_1_resource_1_1, resource_1_resource_1_2, resource_1_resource_1_3, resource_1_resource_1_4, resource_1_resource_1_5, resource_1_resource_1_6, resource_1_resource_1_7, resource_3
	MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, % 0
	784, 807, 265, 859, 372, 668, 856, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 882, % node_0
	MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 230, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 537, % node_1
	MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 416, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 779, % node_2
	MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 462, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 864, % node_3
	MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 249, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 286, % node_4

	% node_1
	%res_conumable, resource_2, resource_4, resource_5, resource_6, resource_7, res_non_conumable, resource_0_resource_0_0, resource_0_resource_0_1, resource_0_resource_0_2, resource_0_resource_0_3, resource_0_resource_0_4, resource_0_resource_0_5, resource_0_resource_0_6, resource_0_resource_0_7, resource_0_resource_0_8, resource_0_resource_0_9, resource_1_resource_1_0, resource_1_resource_1_1, resource_1_resource_1_2, resource_1_resource_1_3, resource_1_resource_1_4, resource_1_resource_1_5, resource_1_resource_1_6, resource_1_resource_1_7, resource_3
	MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, % 0
	MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 230, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 537, % node_0
	311, 887, 847, 831, 518, 98, 377, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 124, % node_1
	MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 278, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 283, % node_2
	MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 651, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 554, % node_3
	MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 390, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 842, % node_4

	% node_2
	%res_conumable, resource_2, resource_4, resource_5, resource_6, resource_7, res_non_conumable, resource_0_resource_0_0, resource_0_resource_0_1, resource_0_resource_0_2, resource_0_resource_0_3, resource_0_resource_0_4, resource_0_resource_0_5, resource_0_resource_0_6, resource_0_resource_0_7, resource_0_resource_0_8, resource_0_resource_0_9, resource_1_resource_1_0, resource_1_resource_1_1, resource_1_resource_1_2, resource_1_resource_1_3, resource_1_resource_1_4, resource_1_resource_1_5, resource_1_resource_1_6, resource_1_resource_1_7, resource_3
	MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, % 0
	MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 416, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 779, % node_0
	MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 278, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 283, % node_1
	933, 674, 531, 275, 100, 247, 585, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 507, % node_2
	MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 510, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 639, % node_3
	MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 687, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 748, % node_4

	% node_3
	%res_conumable, resource_2, resource_4, resource_5, resource_6, resource_7, res_non_conumable, resource_0_resource_0_0, resource_0_resource_0_1, resource_0_resource_0_2, resource_0_resource_0_3, resource_0_resource_0_4, resource_0_resource_0_5, resource_0_resource_0_6, resource_0_resource_0_7, resource_0_resource_0_8, resource_0_resource_0_9, resource_1_resource_1_0, resource_1_resource_1_1, resource_1_resource_1_2, resource_1_resource_1_3, resource_1_resource_1_4, resource_1_resource_1_5, resource_1_resource_1_6, resource_1_resource_1_7, resource_3
	MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, % 0
	MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 462, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 864, % node_0
	MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 651, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 554, % node_1
	MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 510, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 639, % node_2
	528, 725, 86, 233, 394, 331, 400, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 731, % node_3
	MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 730, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 936, % node_4

	% node_4
	%res_conumable, resource_2, resource_4, resource_5, resource_6, resource_7, res_non_conumable, resource_0_resource_0_0, resource_0_resource_0_1, resource_0_resource_0_2, resource_0_resource_0_3, resource_0_resource_0_4, resource_0_resource_0_5, resource_0_resource_0_6, resource_0_resource_0_7, resource_0_resource_0_8, resource_0_resource_0_9, resource_1_resource_1_0, resource_1_resource_1_1, resource_1_resource_1_2, resource_1_resource_1_3, resource_1_resource_1_4, resource_1_resource_1_5, resource_1_resource_1_6, resource_1_resource_1_7, resource_3
	MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, MAX_RBOUNDS, % 0
	MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 249, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 286, % node_0
	MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 390, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 842, % node_1
	MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 687, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 748, % node_2
	MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 730, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, MIN_RBOUNDS, 936, % node_3
	613, 98, 317, 640, 459, 560, 826, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 528, % node_4

]);
cost = array2d(Nodes0, Res, [0 | r in Res] ++ [ % No node
	%res_conumable, resource_2, resource_4, resource_5, resource_6, resource_7, res_non_conumable, resource_0_resource_0_0, resource_0_resource_0_1, resource_0_resource_0_2, resource_0_resource_0_3, resource_0_resource_0_4, resource_0_resource_0_5, resource_0_resource_0_6, resource_0_resource_0_7, resource_0_resource_0_8, resource_0_resource_0_9, resource_1_resource_1_0, resource_1_resource_1_1, resource_1_resource_1_2, resource_1_resource_1_3, resource_1_resource_1_4, resource_1_resource_1_5, resource_1_resource_1_6, resource_1_resource_1_7, resource_3
	0, 0, 0, 0, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, % node_0
	0, 0, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, % node_1
	0, 0, 0, 0, 9, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, % node_2
	0, 0, 0, 0, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, % node_3
	0, 0, 0, 0, 6, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, % node_4
]);
carb = array1d(Nodes0, [0] ++ [ % No node
	10, 10, 10, 3, 6
]);
costBudget = 3183;
carbBudget = 4610;

