predicate global_cardinality(
    array [$X] of var $$E: x,
    array [int] of var $$E: cover,
    array [int] of var int: lbound,
    array [int] of var int: ubound
) = forall(i in 1..length(cover))(
    sum([e = cover[i] | e in x]) in lbound[i]..ubound[i]
);

predicate cumulative(
    array[$$E] of var opt int: s,
    array[$$E] of var opt int: d,
    array[$$E] of var opt int: r,
    var int: b
) = assert(
    % They all must have same length
    index_set(s) == index_set(d) /\ index_set(s) == index_set(r),
    "cumulative redefinition: arrays must have identical index sets",

    let {
        array[index_set(s)] of var 0..ub(max(d)): d_deopt;
        array[index_set(s)] of var 0..ub(max(r)): r_deopt;
    } in
    % If s occurs than also d and r must occur (d and r may be non-optional,
    % so an absent task must not force them to be absent)
    forall(i in index_set(s))(occurs(s[i]) -> (occurs(d[i]) /\ occurs(r[i])))
    /\
    % "channeling" from d to define d_deopt
    forall(i in index_set(s))(
        if occurs(d[i]) then d_deopt[i] = deopt(d[i]) else d_deopt[i] = 0 endif)
    /\
    % "channeling" from r to define r_deopt
    forall(i in index_set(s))(
        if occurs(r[i]) then r_deopt[i] = deopt(r[i]) else r_deopt[i] = 0 endif)
    /\
    % Nonnegativity only when present
    forall(i in index_set(s))((occurs(d[i]) -> d[i] >= 0) /\ (occurs(r[i]) -> r[i] >= 0))
    /\
    cumulative(s, d_deopt, r_deopt, b)
);

% Taken from https://github.com/MiniZinc/mzn-challenge/blob/develop/2024/aircraft-disassembly/aircraft.mzn

% Author: Allen Zhong 2022
% Aircraft Disassembly Scheduling
% Constraint Programming model
% The model is inspired by the following models:
%  - the CP Optimizer model for Aircraft Disassembly Scheduling from https://github.com/cftmthomas/AircraftDisassemblyScheduling
%  - the MiniZinc model for Multi-Skill Project Scheduling Problem from https://github.com/youngkd/MSPSP-InstLib

include "cumulative.mzn";
include "disjunctive.mzn";
% include "redefinitions.mzn";

%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~%
% INSTANCE INITIALISATION
int: nActs;
int: nResources;
int: nSkills;
int: nPrecs;
int: nUnavailable;
int: nUnrels; % number of unrelated activites wrt to the precedence graph
int: maxt;  % maximum makespan

set of int: ACT = 1..nActs;
set of int: RESOURCE = 1..nResources;
set of int: SKILL = 1..nSkills;
set of int: PREC = 1..nPrecs;
set of int: UNREL = 1..nUnrels;
set of int: TIME = 0..maxt;
set of int: UNAVAILABLE = 1..nUnavailable;

array[ACT] of set of RESOURCE: USEFUL_RES; % useful resources for each act
array[RESOURCE] of set of ACT: POTENTIAL_ACT; % potential activities for each res

array[ACT] of int: dur; % duration
array[ACT,SKILL] of int: sreq;
array[ACT, SKILL] of var min(sreq)..max(sreq): sreq_lifted :: doc_comment("sreq_lifted"); % task's skill requirement
array[RESOURCE,SKILL] of bool: mastery; % resource's skill mastery
array[RESOURCE] of int: resource_cost;
array[RESOURCE] of var min(resource_cost)..max(resource_cost): resource_cost_lifted :: doc_comment("resource_cost_lifted"); % cost of resource per period
array[PREC] of ACT: pred; % predecessor activity
array[PREC] of ACT: succ; % successor activity
array[UNREL] of ACT: unpred; % unrelated predecessor activity
array[UNREL] of ACT: unsucc; % unrelated successor activity
array[SKILL] of 0..nResources: scap = [sum(r in RESOURCE)(bool2int(mastery[r,s])) | s in SKILL]; % capacity of each skill
array[UNAVAILABLE] of RESOURCE: unavailable_resource;
array[UNAVAILABLE] of var min(unavailable_resource)..max(unavailable_resource): unavailable_resource_lifted :: doc_comment("unavailable_resource_lifted");
array[UNAVAILABLE] of TIME: unavailable_start;
array[UNAVAILABLE] of var min(unavailable_start)..max(unavailable_start): unavailable_start_lifted :: doc_comment("unavailable_start_lifted");
array[UNAVAILABLE] of TIME: unavailable_end;
array[UNAVAILABLE] of var min(unavailable_end)..max(unavailable_end): unavailable_end_lifted :: doc_comment("unavailable_end_lifted");

% producer/consumer constraint
array[ACT] of int: mass; % mass required by different activities
set of int: M; % set of mass required to be balanced
array[M, 1..2] of set of LOC: comp_prod; % the producer and consumer location of mass
array[M] of int: maxDiff;
array[M] of var min(maxDiff)..max(maxDiff): maxDiff_lifted :: doc_comment("maxDiff_lifted"); % maximum difference of mass

% amount of mass removed from the balance
array[M, ACT] of int: consumption = array2d(M, ACT, [ if loc[j] in comp_prod[i, 1] then mass[j] else if loc[j] in comp_prod[i, 2] then -mass[j] else 0 endif endif | i in M, j in ACT]);
array [M] of set of int: resAct = [ {i | i in ACT where consumption[m, i] != 0} | m in M];  % set of "non-zero" activities for each mass balanced

% Location constraint
int: nLocations;
set of int: LOC = 1..nLocations;
array[ACT] of LOC: loc; % location of activities
array[LOC] of int: loc_cap;
array[LOC] of var min(loc_cap)..max(loc_cap): loc_cap_lifted :: doc_comment("loc_cap_lifted"); % capacity of locations
array[ACT] of int: occupancy;
array[ACT] of var min(occupancy)..max(occupancy): occupancy_lifted :: doc_comment("occupancy_lifted"); % occupancy requirement

%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~%
% DECISION VARIABLES
array[ACT] of var TIME: start; % start time
array[ACT,RESOURCE] of var bool: assign; % assignment of resources to activities
array[ACT,RESOURCE,SKILL] of var bool: contrib; % skill contribution assignment
array[UNREL] of var bool: overlap; % overlapping of unrelated activities

%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~%
% CONSTRAINTS

% Precedence constraint
constraint forall(p in PREC)(
    start[pred[p]] + dur[pred[p]] <= start[succ[p]]
);

% Unary resource constraint
% CHANGED: this constraint was changed because uses let declarations
% constraint
%   forall (
%     u in UNREL
%   )(
%   let {int: i = unpred[u],
%        int: j = unsucc[u]} in
%         if exists( s in SKILL )( sreq[i,s] + sreq[j,s] > scap[s] ) then
%              (     overlap[u]  -> start[i] + dur[i] <= start[j] ) /\
%              ( not(overlap[u]) -> start[j] + dur[j] <= start[i] )
%         else
%             (
%               not(overlap[u]) <-> (start[i] + dur[i] <= start[j] \/
%                                    start[j] + dur[j] <= start[i])
%             ) /\ (
%               forall(
%                 r in USEFUL_RES[i] intersect USEFUL_RES[j]
%               )(
%                 (assign[i,r] /\ assign[j,r]) -> not(overlap[u])
%               )
%             )
%         endif
%   );
constraint
  forall (
    u in UNREL
  )(
  
        if exists( s in SKILL )( sreq_lifted[unpred[u],s] + sreq_lifted[unsucc[u],s] > scap[s] ) then
             (     overlap[u]  -> start[unpred[u]] + dur[unpred[u]] <= start[unsucc[u]] ) /\
             ( not(overlap[u]) -> start[unsucc[u]] + dur[unsucc[u]] <= start[unpred[u]] )
        else
            (
              not(overlap[u]) <-> (start[unpred[u]] + dur[unpred[u]] <= start[unsucc[u]] \/
                                   start[unsucc[u]] + dur[unsucc[u]] <= start[unpred[u]])
            ) /\ (
              forall(
                r in USEFUL_RES[unpred[u]] intersect USEFUL_RES[unsucc[u]]
              )(
                (assign[unpred[u],r] /\ assign[unsucc[u],r]) -> not(overlap[u])
              )
            )
        endif
  );

% Resource unavailable constraint
constraint forall(i in UNAVAILABLE)(
  forall(a in ACT)(
    assign[a, unavailable_resource_lifted[i]] -> (start[a] + dur[a] <= unavailable_start_lifted[i] \/ start[a] >= unavailable_end_lifted[i])
  )
);

% Skill constraint: Skill requirements are satisfied
constraint forall(a in ACT, s in SKILL where sreq_lifted[a,s]>0)(
  sum(r in USEFUL_RES[a])(contrib[a,r,s]) == sreq_lifted[a,s]
);

% Non-Multi-Tasking constraint: Maximum of one contribution by each activity
constraint forall(a in ACT, r in USEFUL_RES[a])(
  sum(s in SKILL where mastery[r,s]==true /\ sreq_lifted[a,s]>0)
     (contrib[a,r,s]) <= 1
);

% Skill constraint: Resources only use skills they have mastered
constraint forall(a in ACT, r in USEFUL_RES[a], s in SKILL)(
  contrib[a,r,s] <= bool2int(mastery[r,s])
);

% Linking constraint: resources only contribute to activities they are assigned
constraint forall(a in ACT, r in USEFUL_RES[a], s in SKILL where sreq_lifted[a,s]>0) (
  contrib[a,r,s] <= bool2int(assign[a,r])
);

% Location constraint: limit the maximum number of technicians allowed to work there at the same time.
constraint forall(i in LOC)(cumulative(start, dur, occupancy_lifted, loc_cap_lifted[i]));

% order variables describe the relative precedence between pairs of activities
array[ACT, ACT] of var bool: act_leq_act = array2d(ACT, ACT, [start[i] <= start[j] | i, j in ACT]);

% constraint for correct reservoir levels at the start of activities
constraint forall(m in M, i in resAct[m])(
		sum(j in resAct[m])( consumption[m, j] * act_leq_act[j, i] ) <= maxDiff_lifted[m]
	/\ 	sum(j in resAct[m])( consumption[m, j] * act_leq_act[j, i] ) >= -maxDiff_lifted[m]
);

% constraint for act_leq_act
constraint forall(i, j in ACT where i < j)( act_leq_act[i, j] \/ act_leq_act[j, i]);

% minimize the makespan
var int: objective = 100000 * max(start) + sum(a in ACT, r in RESOURCE)(resource_cost_lifted[r] * dur[a] * assign[a, r]);


nActs=54;
nResources=21;
nSkills=3;
nPrecs=206;
nUnavailable=21;
nUnrels=1225;
maxt=1920;
USEFUL_RES=[{1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21},{1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21},{1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21},{1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21},{1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21},{1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21},{1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21},{1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21},{1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21},{1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21},{1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21},{1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21},{1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21},{1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21},{1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21},{1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21},{1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21},{1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21},{1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21},{1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21},{1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21},{1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21},{1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21},{1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21},{1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21},{1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21},{1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21},{1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21},{1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21},{1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21},{1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21},{1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21},{1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21},{1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21},{1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21},{1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21},{1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21},{1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21},{1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21},{1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21},{1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21},{1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21},{1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21},{1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21},{1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21},{1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21},{1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21},{1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21},{1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21},{1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21},{1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21},{1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21},{1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21},{1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21}];
POTENTIAL_ACT=[{1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54},{1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54},{1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54},{1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54},{1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54},{1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54},{1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54},{1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54},{1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54},{1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54},{1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54},{1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54},{1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54},{1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54},{1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54},{1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54},{1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54},{1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54},{1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54},{1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54},{1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54}];
resource_cost=[750,750,750,750,750,750,750,750,750,750,750,750,1000,1000,1000,1000,1000,1000,1000,1250,1250];
dur=[1,4,3,3,4,4,1,8,4,4,4,4,6,4,16,12,8,1,2,1,1,1,3,1,1,2,2,4,4,2,2,2,4,2,1,2,4,2,2,4,1,3,1,1,1,2,1,1,2,2,1,1,2,2];
sreq=array2d(ACT,SKILL,[1,0,0,1,0,0,2,0,0,2,0,0,2,0,0,2,0,0,2,0,0,2,0,0,1,1,0,1,1,0,1,1,0,1,1,0,2,0,0,1,1,0,1,1,0,1,1,0,1,1,0,1,1,0,1,1,0,1,1,0,1,1,0,2,0,0,2,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0]);
mastery=array2d(RESOURCE,SKILL,[true,false,false,true,false,false,true,false,false,true,false,false,true,false,false,true,false,false,true,false,false,true,false,false,true,false,false,true,false,false,true,false,false,true,true,false,true,true,false,true,true,false,true,true,false,true,true,false,true,true,false,true,false,true,true,false,true,true,true,true,true,true,true]);
pred=[5,17,1,5,17,1,2,5,17,1,2,1,5,17,1,2,5,17,1,2,5,17,1,2,5,17,1,2,5,17,1,2,5,17,1,2,5,17,1,2,5,17,1,2,5,17,1,2,5,17,1,2,5,17,1,2,5,1,5,17,1,2,5,17,1,2,5,17,1,2,5,17,1,2,5,17,1,2,5,17,1,2,5,17,1,2,5,17,1,2,5,17,1,2,5,17,1,2,5,17,1,2,5,17,1,2,5,17,1,2,5,17,1,2,5,17,1,2,5,17,1,2,5,17,1,2,5,17,1,2,5,17,1,2,5,17,1,2,5,17,1,2,5,17,1,2,5,17,1,2,5,17,1,2,5,17,1,2,5,17,1,2,5,17,1,2,5,17,1,2,5,17,1,2,5,17,1,2,5,17,1,2,5,17,1,2,5,17,1,2,5,17,1,2,5,17,1,2,5,17,1,2,5,17,1,2];
succ=[2,2,2,3,3,3,3,4,4,4,4,5,6,6,6,6,7,7,7,7,8,8,8,8,9,9,9,9,10,10,10,10,11,11,11,11,12,12,12,12,13,13,13,13,14,14,14,14,15,15,15,15,16,16,16,16,17,17,18,18,18,18,19,19,19,19,20,20,20,20,21,21,21,21,22,22,22,22,23,23,23,23,24,24,24,24,25,25,25,25,26,26,26,26,27,27,27,27,28,28,28,28,29,29,29,29,30,30,30,30,31,31,31,31,32,32,32,32,33,33,33,33,34,34,34,34,35,35,35,35,36,36,36,36,37,37,37,37,38,38,38,38,39,39,39,39,40,40,40,40,41,41,41,41,42,42,42,42,43,43,43,43,44,44,44,44,45,45,45,45,46,46,46,46,47,47,47,47,48,48,48,48,49,49,49,49,50,50,50,50,51,51,51,51,52,52,52,52,53,53,53,53,54,54,54,54];
unpred=[3,3,4,3,4,6,3,4,6,7,3,4,6,7,8,3,4,6,7,8,9,3,4,6,7,8,9,10,3,4,6,7,8,9,10,11,3,4,6,7,8,9,10,11,12,3,4,6,7,8,9,10,11,12,13,3,4,6,7,8,9,10,11,12,13,14,3,4,6,7,8,9,10,11,12,13,14,15,3,4,6,7,8,9,10,11,12,13,14,15,16,3,4,6,7,8,9,10,11,12,13,14,15,16,18,3,4,6,7,8,9,10,11,12,13,14,15,16,18,19,3,4,6,7,8,9,10,11,12,13,14,15,16,18,19,20,3,4,6,7,8,9,10,11,12,13,14,15,16,18,19,20,21,3,4,6,7,8,9,10,11,12,13,14,15,16,18,19,20,21,22,3,4,6,7,8,9,10,11,12,13,14,15,16,18,19,20,21,22,23,3,4,6,7,8,9,10,11,12,13,14,15,16,18,19,20,21,22,23,24,3,4,6,7,8,9,10,11,12,13,14,15,16,18,19,20,21,22,23,24,25,3,4,6,7,8,9,10,11,12,13,14,15,16,18,19,20,21,22,23,24,25,26,3,4,6,7,8,9,10,11,12,13,14,15,16,18,19,20,21,22,23,24,25,26,27,3,4,6,7,8,9,10,11,12,13,14,15,16,18,19,20,21,22,23,24,25,26,27,28,3,4,6,7,8,9,10,11,12,13,14,15,16,18,19,20,21,22,23,24,25,26,27,28,29,3,4,6,7,8,9,10,11,12,13,14,15,16,18,19,20,21,22,23,24,25,26,27,28,29,30,3,4,6,7,8,9,10,11,12,13,14,15,16,18,19,20,21,22,23,24,25,26,27,28,29,30,31,3,4,6,7,8,9,10,11,12,13,14,15,16,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,3,4,6,7,8,9,10,11,12,13,14,15,16,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,3,4,6,7,8,9,10,11,12,13,14,15,16,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,3,4,6,7,8,9,10,11,12,13,14,15,16,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,3,4,6,7,8,9,10,11,12,13,14,15,16,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,3,4,6,7,8,9,10,11,12,13,14,15,16,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,3,4,6,7,8,9,10,11,12,13,14,15,16,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,3,4,6,7,8,9,10,11,12,13,14,15,16,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,3,4,6,7,8,9,10,11,12,13,14,15,16,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,3,4,6,7,8,9,10,11,12,13,14,15,16,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,3,4,6,7,8,9,10,11,12,13,14,15,16,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,3,4,6,7,8,9,10,11,12,13,14,15,16,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,3,4,6,7,8,9,10,11,12,13,14,15,16,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,3,4,6,7,8,9,10,11,12,13,14,15,16,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,3,4,6,7,8,9,10,11,12,13,14,15,16,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,3,4,6,7,8,9,10,11,12,13,14,15,16,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,3,4,6,7,8,9,10,11,12,13,14,15,16,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,3,4,6,7,8,9,10,11,12,13,14,15,16,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,3,4,6,7,8,9,10,11,12,13,14,15,16,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,3,4,6,7,8,9,10,11,12,13,14,15,16,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,3,4,6,7,8,9,10,11,12,13,14,15,16,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,3,4,6,7,8,9,10,11,12,13,14,15,16,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53];
unsucc=[4,6,6,7,7,7,8,8,8,8,9,9,9,9,9,10,10,10,10,10,10,11,11,11,11,11,11,11,12,12,12,12,12,12,12,12,13,13,13,13,13,13,13,13,13,14,14,14,14,14,14,14,14,14,14,15,15,15,15,15,15,15,15,15,15,15,16,16,16,16,16,16,16,16,16,16,16,16,18,18,18,18,18,18,18,18,18,18,18,18,18,19,19,19,19,19,19,19,19,19,19,19,19,19,19,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,21,21,21,21,21,21,21,21,21,21,21,21,21,21,21,21,22,22,22,22,22,22,22,22,22,22,22,22,22,22,22,22,22,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,24,24,24,24,24,24,24,24,24,24,24,24,24,24,24,24,24,24,24,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,26,26,26,26,26,26,26,26,26,26,26,26,26,26,26,26,26,26,26,26,26,27,27,27,27,27,27,27,27,27,27,27,27,27,27,27,27,27,27,27,27,27,27,28,28,28,28,28,28,28,28,28,28,28,28,28,28,28,28,28,28,28,28,28,28,28,29,29,29,29,29,29,29,29,29,29,29,29,29,29,29,29,29,29,29,29,29,29,29,29,30,30,30,30,30,30,30,30,30,30,30,30,30,30,30,30,30,30,30,30,30,30,30,30,30,31,31,31,31,31,31,31,31,31,31,31,31,31,31,31,31,31,31,31,31,31,31,31,31,31,31,32,32,32,32,32,32,32,32,32,32,32,32,32,32,32,32,32,32,32,32,32,32,32,32,32,32,32,33,33,33,33,33,33,33,33,33,33,33,33,33,33,33,33,33,33,33,33,33,33,33,33,33,33,33,33,34,34,34,34,34,34,34,34,34,34,34,34,34,34,34,34,34,34,34,34,34,34,34,34,34,34,34,34,34,35,35,35,35,35,35,35,35,35,35,35,35,35,35,35,35,35,35,35,35,35,35,35,35,35,35,35,35,35,35,36,36,36,36,36,36,36,36,36,36,36,36,36,36,36,36,36,36,36,36,36,36,36,36,36,36,36,36,36,36,36,37,37,37,37,37,37,37,37,37,37,37,37,37,37,37,37,37,37,37,37,37,37,37,37,37,37,37,37,37,37,37,37,38,38,38,38,38,38,38,38,38,38,38,38,38,38,38,38,38,38,38,38,38,38,38,38,38,38,38,38,38,38,38,38,38,39,39,39,39,39,39,39,39,39,39,39,39,39,39,39,39,39,39,39,39,39,39,39,39,39,39,39,39,39,39,39,39,39,39,40,40,40,40,40,40,40,40,40,40,40,40,40,40,40,40,40,40,40,40,40,40,40,40,40,40,40,40,40,40,40,40,40,40,40,41,41,41,41,41,41,41,41,41,41,41,41,41,41,41,41,41,41,41,41,41,41,41,41,41,41,41,41,41,41,41,41,41,41,41,41,42,42,42,42,42,42,42,42,42,42,42,42,42,42,42,42,42,42,42,42,42,42,42,42,42,42,42,42,42,42,42,42,42,42,42,42,42,43,43,43,43,43,43,43,43,43,43,43,43,43,43,43,43,43,43,43,43,43,43,43,43,43,43,43,43,43,43,43,43,43,43,43,43,43,43,44,44,44,44,44,44,44,44,44,44,44,44,44,44,44,44,44,44,44,44,44,44,44,44,44,44,44,44,44,44,44,44,44,44,44,44,44,44,44,45,45,45,45,45,45,45,45,45,45,45,45,45,45,45,45,45,45,45,45,45,45,45,45,45,45,45,45,45,45,45,45,45,45,45,45,45,45,45,45,46,46,46,46,46,46,46,46,46,46,46,46,46,46,46,46,46,46,46,46,46,46,46,46,46,46,46,46,46,46,46,46,46,46,46,46,46,46,46,46,46,47,47,47,47,47,47,47,47,47,47,47,47,47,47,47,47,47,47,47,47,47,47,47,47,47,47,47,47,47,47,47,47,47,47,47,47,47,47,47,47,47,47,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,49,49,49,49,49,49,49,49,49,49,49,49,49,49,49,49,49,49,49,49,49,49,49,49,49,49,49,49,49,49,49,49,49,49,49,49,49,49,49,49,49,49,49,49,50,50,50,50,50,50,50,50,50,50,50,50,50,50,50,50,50,50,50,50,50,50,50,50,50,50,50,50,50,50,50,50,50,50,50,50,50,50,50,50,50,50,50,50,50,51,51,51,51,51,51,51,51,51,51,51,51,51,51,51,51,51,51,51,51,51,51,51,51,51,51,51,51,51,51,51,51,51,51,51,51,51,51,51,51,51,51,51,51,51,51,52,52,52,52,52,52,52,52,52,52,52,52,52,52,52,52,52,52,52,52,52,52,52,52,52,52,52,52,52,52,52,52,52,52,52,52,52,52,52,52,52,52,52,52,52,52,52,53,53,53,53,53,53,53,53,53,53,53,53,53,53,53,53,53,53,53,53,53,53,53,53,53,53,53,53,53,53,53,53,53,53,53,53,53,53,53,53,53,53,53,53,53,53,53,53,54,54,54,54,54,54,54,54,54,54,54,54,54,54,54,54,54,54,54,54,54,54,54,54,54,54,54,54,54,54,54,54,54,54,54,54,54,54,54,54,54,54,54,54,54,54,54,54,54];
mass=[0,0,0,0,2,2,5,1,0,0,1,0,0,5,1,2,1,1,0,0,0,0,2,0,1,0,0,0,1,1,1,0,0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,1,5,2,0,0,1];
M={1,2};
comp_prod=array2d(M,1..2,[{1,2,3,5,7},{9,6},{11},{12}]);
maxDiff=[100,50];
nLocations=14;
loc=[14,14,8,8,11,2,6,14,14,14,14,10,10,6,9,2,14,5,8,8,2,4,3,5,2,4,10,3,14,14,14,10,10,10,3,10,10,10,10,6,14,8,3,1,2,13,14,14,6,5,2,4,13,5];
occupancy=[1,1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1];
unavailable_resource=[1,2,2,4,7,7,9,9,10,10,12,13,14,15,15,16,19,19,21,21,21];
unavailable_start=[0,96,1632,1376,1152,1536,224,544,448,704,1248,1792,832,0,1056,416,576,1184,224,544,832];
unavailable_end=[160,224,1760,1408,1184,1568,288,576,512,832,1312,1888,864,160,1152,448,672,1248,256,576,864];
loc_cap = array1d(1..14, [1, 1, 1, 6, 22% CHANGED HERE from 4 to 22
, 3, 44% CHANGED HERE from 3 to 44
, 4, 4, 10% CHANGED HERE from 3 to 10
, 50% CHANGED HERE from 5 to 50
, 5, 10, 49% CHANGED HERE from 69 to 49
]);

output ["original loc_cap = \(loc_cap)\nlifted   loc_cap = \(loc_cap_lifted)\n\n"] ++ ["original maxDiff = \(maxDiff)\nlifted   maxDiff = \(maxDiff_lifted)\n\n"] ++ ["original occupancy = \(occupancy)\nlifted   occupancy = \(occupancy_lifted)\n\n"] ++ ["original resource_cost = \(resource_cost)\nlifted   resource_cost = \(resource_cost_lifted)\n\n"] ++ ["original sreq = \(sreq)\nlifted   sreq = \(sreq_lifted)\n\n"] ++ ["original unavailable_end = \(unavailable_end)\nlifted   unavailable_end = \(unavailable_end_lifted)\n\n"] ++ ["original unavailable_resource = \(unavailable_resource)\nlifted   unavailable_resource = \(unavailable_resource_lifted)\n\n"] ++ ["original unavailable_start = \(unavailable_start)\nlifted   unavailable_start = \(unavailable_start_lifted)\n\n"];

array[int] of int: params_int = [loc_cap[i0] | i0 in LOC]
	 ++ [maxDiff[i0] | i0 in M]
	 ++ [occupancy[i0] | i0 in ACT]
	 ++ [resource_cost[i0] | i0 in RESOURCE]
	 ++ [sreq[i0, i1] | i0 in ACT, i1 in SKILL]
	 ++ [unavailable_end[i0] | i0 in UNAVAILABLE]
	 ++ [unavailable_resource[i0] | i0 in UNAVAILABLE]
	 ++ [unavailable_start[i0] | i0 in UNAVAILABLE];

array[int] of var int: params_int_lifted = [loc_cap_lifted[i0] | i0 in LOC]
	 ++ [maxDiff_lifted[i0] | i0 in M]
	 ++ [occupancy_lifted[i0] | i0 in ACT]
	 ++ [resource_cost_lifted[i0] | i0 in RESOURCE]
	 ++ [sreq_lifted[i0, i1] | i0 in ACT, i1 in SKILL]
	 ++ [unavailable_end_lifted[i0] | i0 in UNAVAILABLE]
	 ++ [unavailable_resource_lifted[i0] | i0 in UNAVAILABLE]
	 ++ [unavailable_start_lifted[i0] | i0 in UNAVAILABLE];

include "experimental/assume.mzn";

array[int] of var bool: lifted_assumed = [params_int_lifted[i] = params_int[i] | i in index_set(params_int)];

array[int] of var bool: assumed = [if i in 
	{}
	then true else lifted_assumed[i] endif | i in index_set(lifted_assumed)];

constraint assume(assumed);

constraint assert(trace(
	"Length of params_int        = \(length(params_int))\n",
	length(params_int)
)= trace(
	"Length of params_int_lifted = \(length(params_int_lifted))\n",
	length(params_int_lifted)
), "ERROR: length of parameters and lifted does not match");

var int: objective_lifted :: output_var = sum([abs(loc_cap_lifted[i0] - loc_cap[i0]) | i0 in LOC])
	+ sum([abs(maxDiff_lifted[i0] - maxDiff[i0]) | i0 in M])
	+ sum([abs(occupancy_lifted[i0] - occupancy[i0]) | i0 in ACT])
	+ sum([abs(resource_cost_lifted[i0] - resource_cost[i0]) | i0 in RESOURCE])
	+ sum([abs(sreq_lifted[i0, i1] - sreq[i0, i1]) | i0 in ACT, i1 in SKILL])
	+ sum([abs(unavailable_end_lifted[i0] - unavailable_end[i0]) | i0 in UNAVAILABLE])
	+ sum([abs(unavailable_resource_lifted[i0] - unavailable_resource[i0]) | i0 in UNAVAILABLE])
	+ sum([abs(unavailable_start_lifted[i0] - unavailable_start[i0]) | i0 in UNAVAILABLE])
;
solve
	::warm_start(assumed, [true | _ in index_set(assumed)])
minimize objective_lifted;

output ["_objective = \(objective_lifted)\n"];

