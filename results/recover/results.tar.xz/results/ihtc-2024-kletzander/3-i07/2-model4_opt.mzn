predicate global_cardinality(
    array [$X] of var $$E: x,
    array [int] of var $$E: cover,
    array [int] of var int: lbound,
    array [int] of var int: ubound
) = forall(i in 1..length(cover))(
    sum([e = cover[i] | e in x]) in lbound[i]..ubound[i]
);

predicate cumulative(
    array[$$E] of var opt int: s,
    array[$$E] of var opt int: d,
    array[$$E] of var opt int: r,
    var int: b
) = assert(
    % They all must have same length
    index_set(s) == index_set(d) /\ index_set(s) == index_set(r),
    "cumulative redefinition: arrays must have identical index sets",

    let {
        array[index_set(s)] of var 0..ub(max(d)): d_deopt;
        array[index_set(s)] of var 0..ub(max(r)): r_deopt;
    } in
    % If s occurs than also d and r must occur (d and r may be non-optional,
    % so an absent task must not force them to be absent)
    forall(i in index_set(s))(occurs(s[i]) -> (occurs(d[i]) /\ occurs(r[i])))
    /\
    % "channeling" from d to define d_deopt
    forall(i in index_set(s))(
        if occurs(d[i]) then d_deopt[i] = deopt(d[i]) else d_deopt[i] = 0 endif)
    /\
    % "channeling" from r to define r_deopt
    forall(i in index_set(s))(
        if occurs(r[i]) then r_deopt[i] = deopt(r[i]) else r_deopt[i] = 0 endif)
    /\
    % Nonnegativity only when present
    forall(i in index_set(s))((occurs(d[i]) -> d[i] >= 0) /\ (occurs(r[i]) -> r[i] >= 0))
    /\
    cumulative(s, d_deopt, r_deopt, b)
);

% Taken from https://github.com/MiniZinc/mzn-challenge/blob/develop/2025/ihtc-2024-kletzander/model4_opt.mzn

% Copyright 2025 Lucas Kletzander
%
%Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the %“Software”), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, %distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the %following conditions:
%
%The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
%
%THE SOFTWARE IS PROVIDED “AS IS”, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF %MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY %CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE %OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

% Modifications by MiniZinc Challenge Organizers:
% - Add search annotation

include "globals.mzn";

int: num_occupants;
set of int: C = 1..num_occupants;
int: num_patients;
set of int: P = 1..num_patients;
int: horizon;
set of int: D = 0..horizon-1;
int: num_rooms;
set of int: R = 1..num_rooms;
int: num_ot;
set of int: O = 1..num_ot;
int: max_incompatible;
set of int: MI = 1..max_incompatible;
int: num_surgeons;
set of int: S = 1..num_surgeons;
int: weight_selection;
int: weight_delay;

array[C] of int: oc_length_of_stay;
array[C] of int: oc_gender;
array[C] of int: oc_room;
array[P] of int: length_of_stay;
array[P] of int: gender;
array[P,MI] of int: incompatible_rooms;
array[P] of bool: mandatory;
array[P] of int: surgery_duration;
array[P] of int: surgeon;
array[P] of int: release_day;
array[P] of var min(release_day)..max(release_day): release_day_lifted :: doc_comment("release_day_lifted");
array[P] of int: due_day;
array[P] of var min(due_day)..max(due_day): due_day_lifted :: doc_comment("due_day_lifted");
array[S,D] of int: max_surgery;
array[S, D] of var min(max_surgery)..max(max_surgery): max_surgery_lifted :: doc_comment("max_surgery_lifted");
array[O,D] of int: max_ot;
array[O, D] of var min(max_ot)..max(max_ot): max_ot_lifted :: doc_comment("max_ot_lifted");
array[R] of int: capacity;
array[R] of var min(capacity)..max(capacity): capacity_lifted :: doc_comment("capacity_lifted");

array[P] of var bool: selection;
array[P] of var D: admission;
array[P] of var R: room;
array[P] of var O: ot;

% H1 No gender mix
constraint forall (c in C, p in P where oc_gender[c] != gender[p] /\ selection[p]) (oc_room[c] != room[p] \/ admission[p] >= oc_length_of_stay[c]);
constraint forall (p1 in P, p2 in P where gender[p1] != gender[p2] /\ selection[p1] /\ selection[p2]) (room[p1] != room[p2] \/ admission[p1] >= admission[p2] + length_of_stay[p2] \/ admission[p2] >= admission[p1] + length_of_stay[p1]);

% H2 Compatible rooms
constraint forall (p in P, i in MI where incompatible_rooms[p,i] > 0) (room[p] != incompatible_rooms[p,i]);

% H3 Surgeon overtime
constraint forall (s in S, d in D) (sum([surgery_duration[p] | p in P where selection[p] /\ admission[p] == d /\ surgeon[p] == s]) <= max_surgery_lifted[s,d]);

% H4 OT overtime
constraint forall (o in O, d in D) (sum([surgery_duration[p] | p in P where selection[p] /\ admission[p] == d /\ ot[p] == o]) <= max_ot_lifted[o,d]);

% H5 Mandatory patients
constraint forall (p in P) (mandatory[p] -> selection[p]);

% H6 Admission day
array[P] of var D: admission_delay = [if selection[p] then admission[p] - release_day_lifted[p] else 0 endif | p in P];
constraint forall (p in P) (admission[p] <= due_day_lifted[p]);

% H7 Room capacity
array[R,P] of var 0..max(length_of_stay)*num_patients: room_admission;
constraint forall (p in P where selection[p]) (room_admission[room[p],p] == admission[p]);
constraint forall (r in R) (cumulative([0 | c in C where oc_room[c] == r] ++ row(room_admission, r), [oc_length_of_stay[c] | c in C where oc_room[c] == r] ++ length_of_stay, [1 | c in C where oc_room[c] == r] ++ [1 | p in P], capacity_lifted[r]));

var int: objective = count(selection, false) * weight_selection + sum(admission_delay) * weight_delay;


num_occupants=20;
num_patients=79;
horizon=14;
num_rooms=13;
oc_length_of_stay=[1,6,1,3,6,2,1,8,3,2,2,5,3,1,3,6,1,6,3,1];
oc_gender=[2,1,2,2,2,2,2,2,2,2,2,2,2,2,2,1,2,1,2,2];
oc_room=[9,8,3,3,6,11,2,11,2,1,12,10,2,1,2,8,6,8,4,6];
length_of_stay=[3,6,3,4,6,3,4,5,7,3,4,7,3,3,4,4,3,4,6,2,4,3,2,3,8,4,2,4,5,3,5,3,2,4,3,3,8,2,3,3,4,6,3,3,5,2,3,4,4,3,3,3,8,2,2,5,4,7,3,3,4,2,11,2,4,3,2,6,2,3,2,8,3,5,5,3,3,3,4];
gender=[2,1,2,2,2,1,2,1,1,1,1,1,2,1,1,2,2,1,1,2,2,2,2,2,2,1,1,2,2,1,2,2,2,2,1,2,2,1,1,1,1,1,1,2,2,1,1,2,1,1,2,2,1,2,1,1,1,1,1,1,1,1,2,2,2,2,1,1,1,2,1,2,1,2,1,1,1,1,2];
max_incompatible=5;
incompatible_rooms=[|2,6,0,0,0|2,0,0,0,0|3,6,7,0,0|4,0,0,0,0|4,6,13,0,0|4,0,0,0,0|5,9,0,0,0|6,7,0,0,0|0,0,0,0,0|1,0,0,0,0|2,11,0,0,0|3,5,0,0,0|8,0,0,0,0|1,0,0,0,0|1,4,0,0,0|2,12,0,0,0|0,0,0,0,0|0,0,0,0,0|2,8,0,0,0|1,2,4,5,0|3,0,0,0,0|0,0,0,0,0|4,0,0,0,0|0,0,0,0,0|11,13,0,0,0|1,0,0,0,0|10,0,0,0,0|0,0,0,0,0|4,9,0,0,0|0,0,0,0,0|1,9,0,0,0|8,0,0,0,0|5,6,8,12,0|0,0,0,0,0|4,0,0,0,0|0,0,0,0,0|0,0,0,0,0|4,5,0,0,0|2,0,0,0,0|0,0,0,0,0|0,0,0,0,0|3,0,0,0,0|0,0,0,0,0|0,0,0,0,0|0,0,0,0,0|0,0,0,0,0|10,0,0,0,0|7,9,0,0,0|2,4,5,10,0|7,9,11,0,0|0,0,0,0,0|1,5,8,12,0|7,10,0,0,0|13,0,0,0,0|3,11,0,0,0|3,0,0,0,0|4,7,10,0,0|10,0,0,0,0|2,4,0,0,0|1,0,0,0,0|2,7,8,9,12|3,0,0,0,0|1,3,11,0,0|9,0,0,0,0|4,0,0,0,0|13,0,0,0,0|4,0,0,0,0|5,0,0,0,0|11,0,0,0,0|0,0,0,0,0|8,0,0,0,0|4,9,11,0,0|4,0,0,0,0|4,0,0,0,0|2,5,0,0,0|4,0,0,0,0|7,0,0,0,0|4,0,0,0,0|0,0,0,0,0|];
mandatory=[true,false,false,false,false,true,true,false,true,false,false,true,false,true,true,false,true,false,false,false,true,false,false,true,true,false,false,true,false,false,false,false,false,false,false,true,true,false,false,false,true,true,false,false,true,false,false,false,false,false,false,false,false,false,false,false,true,false,false,true,false,false,false,false,false,false,false,false,true,true,false,true,false,true,true,true,false,false,false];
surgery_duration=[180,120,90,60,60,90,120,120,120,120,60,90,180,120,120,90,180,240,120,120,120,90,90,60,120,120,60,90,120,60,60,180,90,120,120,120,60,60,180,180,90,60,90,120,60,90,120,180,90,180,90,180,180,60,90,180,90,60,90,90,90,60,180,90,90,180,60,120,60,90,120,60,90,300,90,90,90,180,120];
surgeon=[1,2,2,1,1,1,3,1,3,2,2,3,3,2,3,2,2,3,3,1,3,1,2,2,1,1,2,2,1,1,2,1,1,1,2,2,2,1,1,3,2,1,1,2,2,2,3,1,2,2,2,3,2,1,2,3,2,2,2,1,3,1,3,2,2,1,2,1,1,1,1,1,2,3,1,2,1,1,1];
num_surgeons=3;
max_surgery=array2d(1..3,0..13,[|0,480,0,480,360,0,0,480,480,360,0,360,0,480|0,0,360,480,480,0,360,360,360,480,360,480,360,0|0,0,0,480,360,0,0,360,480,480,0,480,0,480|]);
release_day=[1,4,12,1,3,4,4,7,3,7,4,3,9,2,3,3,9,4,3,1,4,1,2,3,1,1,3,4,3,1,3,1,7,1,4,4,3,1,1,7,8,3,4,9,3,2,4,1,3,2,4,13,2,1,2,7,2,4,4,7,8,3,8,2,8,1,2,3,13,1,3,4,10,7,7,3,1,11,4];
num_ot=4;
max_ot=array2d(1..4,0..13,[|600,600,600,600,720,0,720,600,600,720,720,720,600,0|720,720,600,480,600,480,480,480,600,720,0,720,480,600|600,600,720,600,600,720,0,480,720,480,600,720,720,600|720,480,0,720,480,0,0,720,600,600,720,600,600,720|]);
weight_selection=450;
weight_delay=10;
due_day = array1d(1..79, [13, 14, 14, 6% CHANGED HERE from 14 to 6
, 14, 9, 0, 14, 13, 14, 14, 8, 14, 11, 3, 14, 10, 14, 9% CHANGED HERE from 14 to 9
, 14, 13, 14, 14, 11, 13, 14, 14, 10, 14, 14, 14, 14, 14, 14, 14, 12, 12, 14, 3% CHANGED HERE from 14 to 3
, 14, 12, 13, 14, 14, 11, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 3, 6% CHANGED HERE from 14 to 6
, 8% CHANGED HERE from 14 to 8
, 13, 14, 14, 14, 14, 14, 14, 14, 14, 13, 13, 14, 11, 14, 11, 13, 9, 14, 14, 14]);
capacity = array1d(1..13, [4, 4, 2, 4% CHANGED HERE from 2 to 4
, 3, 4, 4, 3, 4, 2, 2, 4% CHANGED HERE from 2 to 4
, 2% CHANGED HERE from 4 to 2
]);

output ["original capacity = \(capacity)\nlifted   capacity = \(capacity_lifted)\n\n"] ++ ["original due_day = \(due_day)\nlifted   due_day = \(due_day_lifted)\n\n"] ++ ["original max_ot = \(max_ot)\nlifted   max_ot = \(max_ot_lifted)\n\n"] ++ ["original max_surgery = \(max_surgery)\nlifted   max_surgery = \(max_surgery_lifted)\n\n"] ++ ["original release_day = \(release_day)\nlifted   release_day = \(release_day_lifted)\n\n"];

array[int] of int: params_int = [capacity[i0] | i0 in R]
	 ++ [due_day[i0] | i0 in P]
	 ++ [max_ot[i0, i1] | i0 in O, i1 in D]
	 ++ [max_surgery[i0, i1] | i0 in S, i1 in D]
	 ++ [release_day[i0] | i0 in P];

array[int] of var int: params_int_lifted = [capacity_lifted[i0] | i0 in R]
	 ++ [due_day_lifted[i0] | i0 in P]
	 ++ [max_ot_lifted[i0, i1] | i0 in O, i1 in D]
	 ++ [max_surgery_lifted[i0, i1] | i0 in S, i1 in D]
	 ++ [release_day_lifted[i0] | i0 in P];

include "experimental/assume.mzn";

array[int] of var bool: lifted_assumed = [params_int_lifted[i] = params_int[i] | i in index_set(params_int)];

array[int] of var bool: assumed = [if i in 
	{20}
	then true else lifted_assumed[i] endif | i in index_set(lifted_assumed)];

constraint assume(assumed);

constraint assert(trace(
	"Length of params_int        = \(length(params_int))\n",
	length(params_int)
)= trace(
	"Length of params_int_lifted = \(length(params_int_lifted))\n",
	length(params_int_lifted)
), "ERROR: length of parameters and lifted does not match");

var int: objective_lifted :: output_var = sum([abs(capacity_lifted[i0] - capacity[i0]) | i0 in R])
	+ sum([abs(due_day_lifted[i0] - due_day[i0]) | i0 in P])
	+ sum([abs(max_ot_lifted[i0, i1] - max_ot[i0, i1]) | i0 in O, i1 in D])
	+ sum([abs(max_surgery_lifted[i0, i1] - max_surgery[i0, i1]) | i0 in S, i1 in D])
	+ sum([abs(release_day_lifted[i0] - release_day[i0]) | i0 in P])
;
solve
	::warm_start(assumed, [true | _ in index_set(assumed)])
minimize objective_lifted;

output ["_objective = \(objective_lifted)\n"];

